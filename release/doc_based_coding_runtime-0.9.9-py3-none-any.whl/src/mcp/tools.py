"""MCP tool definitions for doc-based-coding governance platform.

Exposes Pipeline capabilities as MCP tools that any compatible MCP client
can call for structural constraint enforcement.
"""

from __future__ import annotations

import logging
import json
from pathlib import Path
from typing import Any

from ..pack.manifest_loader import PackManifest
from ..workflow.external_skill_interaction import (
    build_external_skill_interaction_contract,
)
from ..workflow.agent_output import FileSink, write_agent_output
from ..workflow.safe_stop_writeback import build_safe_stop_writeback_bundle
from ..workflow.temporary_override import (
    OVERRIDABLE_CONSTRAINTS,
    OverrideError,
    get_active_overrides,
    revoke_override as _revoke_override,
    save_override as _save_override,
)
from ..workflow.pipeline import (
    ConstraintResult,
    ErrorInfo,
    Pipeline,
    PipelineResult,
    _read_checklist_hot_state,
)

_log = logging.getLogger(__name__)


HOST_EVIDENCE_BUNDLE_RESOURCE_URI = "dbc://host-evidence/bundle"
HOST_EVIDENCE_PRESENTATION_RESOURCE_URI = "dbc://host-evidence/presentation"
EXCHANGE_ARTIFACTS_BUNDLE_RESOURCE_URI = "dbc://exchange-artifacts/bundle"
AGENT_EXCHANGE_HISTORY_RESOURCE_URI = "dbc://agent-exchange/history"
AGENT_EXCHANGE_ACTION_CANDIDATES_RESOURCE_URI = "dbc://agent-exchange/action-candidates"

_SCHEDULER_SUBMISSION_KEY_ALIASES = {
    "artifactId": "artifact_id",
    "artifactVersion": "artifact_version",
    "batchId": "batch_id",
    "productType": "product_type",
    "taskId": "task_id",
    "contextScope": "context_scope",
    "editLease": "edit_lease",
    "sandboxProfile": "sandbox_profile",
    "inputArtifactRefs": "input_artifact_refs",
    "outputArtifactId": "output_artifact_id",
    "agentId": "agent_id",
    "runtimeProvider": "runtime_provider",
    "displayName": "display_name",
    "maxTurns": "max_turns",
    "contextId": "context_id",
    "laneId": "lane_id",
    "requiredRefs": "required_refs",
    "visibleArtifacts": "visible_artifacts",
    "sessionPolicy": "session_policy",
    "redactionPolicy": "redaction_policy",
    "leaseId": "lease_id",
    "allowedArtifacts": "allowed_artifacts",
    "deniedArtifacts": "denied_artifacts",
    "leaseMode": "lease_mode",
    "conflictPolicy": "conflict_policy",
    "expiresAt": "expires_at",
    "profileId": "profile_id",
    "profileKind": "profile_kind",
    "networkPolicy": "network_policy",
    "secretPolicy": "secret_policy",
    "mountPolicy": "mount_policy",
    "refKind": "ref_kind",
    "refId": "ref_id",
    "dependencyId": "dependency_id",
    "sourceTaskId": "source_task_id",
    "targetTaskId": "target_task_id",
    "dependencyKind": "dependency_kind",
    "requiredState": "required_state",
}


def _normalize_scheduler_submission_keys(value: Any) -> Any:
    """Normalize MCP camelCase scheduler submission payload keys."""

    if isinstance(value, dict):
        return {
            _SCHEDULER_SUBMISSION_KEY_ALIASES.get(str(key), str(key)): _normalize_scheduler_submission_keys(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_normalize_scheduler_submission_keys(item) for item in value]
    return value


def _guide_worker_planning_request_from_mcp(
    *,
    guide_task: dict[str, Any] | None,
    planner_lane_specs: list[dict[str, Any]] | tuple[dict[str, Any], ...] | None,
    lane_spec_type,
    planning_request_type,
):
    """Build a guide-worker planning request from MCP payload fields."""

    task_title = ""
    task_summary = ""
    if guide_task not in (None, ""):
        if not isinstance(guide_task, dict):
            raise ValueError("guideTask must be an object when provided")
        raw_title = guide_task.get("title", "")
        raw_summary = guide_task.get("summary", "")
        if raw_title not in (None, "") and not isinstance(raw_title, str):
            raise ValueError("guideTask.title must be a string when provided")
        if raw_summary not in (None, "") and not isinstance(raw_summary, str):
            raise ValueError("guideTask.summary must be a string when provided")
        task_title = (raw_title or "").strip()
        task_summary = (raw_summary or "").strip()

    lane_specs = ()
    if planner_lane_specs not in (None, ""):
        if not isinstance(planner_lane_specs, (list, tuple)):
            raise ValueError("plannerLaneSpecs must be a list of objects")
        lane_specs = tuple(
            _guide_worker_planner_lane_spec_from_mcp(
                item,
                index=index,
                lane_spec_type=lane_spec_type,
            )
            for index, item in enumerate(planner_lane_specs)
        )

    return planning_request_type(
        task_title=task_title,
        task_summary=task_summary,
        lane_specs=lane_specs,
    )


def _guide_worker_planner_lane_spec_from_mcp(
    value: dict[str, Any],
    *,
    index: int,
    lane_spec_type,
):
    if not isinstance(value, dict):
        raise ValueError(f"plannerLaneSpecs[{index}] must be an object")
    prefix = f"plannerLaneSpecs[{index}]"

    def require_string(field: str) -> str:
        raw = value.get(field, "")
        if not isinstance(raw, str) or not raw.strip():
            raise ValueError(f"{prefix}.{field} must be a non-empty string")
        return raw.strip()

    def optional_strings(field: str) -> tuple[str, ...]:
        raw = value.get(field, ())
        if raw in (None, ""):
            return ()
        if not isinstance(raw, (list, tuple)):
            raise ValueError(f"{prefix}.{field} must be a list of strings")
        items: list[str] = []
        for item_index, item in enumerate(raw):
            if not isinstance(item, str) or not item.strip():
                raise ValueError(
                    f"{prefix}.{field}[{item_index}] must be a non-empty string"
                )
            items.append(item.strip())
        return tuple(items)

    worker_agent_id = value.get("workerAgentId", "")
    worker_runtime_provider = value.get("workerRuntimeProvider", "")
    if worker_agent_id not in (None, "") and not isinstance(worker_agent_id, str):
        raise ValueError(f"{prefix}.workerAgentId must be a string when provided")
    if worker_runtime_provider not in (None, "") and not isinstance(
        worker_runtime_provider,
        str,
    ):
        raise ValueError(
            f"{prefix}.workerRuntimeProvider must be a string when provided"
        )

    return lane_spec_type(
        lane_id=require_string("laneId"),
        label=require_string("label"),
        focus=require_string("focus"),
        allowed_artifacts=optional_strings("allowedArtifacts"),
        acceptance=optional_strings("acceptance"),
        depends_on_lane_ids=optional_strings("dependsOnLaneIds"),
        worker_agent_id=(worker_agent_id or "").strip(),
        worker_runtime_provider=(worker_runtime_provider or "").strip(),
        sandbox_profile=_guide_worker_sandbox_profile_from_mcp(
            value.get("sandboxProfile"),
            prefix=f"{prefix}.sandboxProfile",
        ),
    )


def _guide_worker_sandbox_profile_from_mcp(value: Any, *, prefix: str):
    from ..runtime.orchestration import SandboxProfile

    if value in (None, ""):
        return SandboxProfile(profile_id="shared-process", profile_kind="shared-process")
    if not isinstance(value, dict):
        raise ValueError(f"{prefix} must be an object when provided")
    profile_kind = value.get("profileKind", value.get("profile_kind", "shared-process"))
    if not isinstance(profile_kind, str) or not profile_kind.strip():
        raise ValueError(f"{prefix}.profileKind must be a non-empty string")
    normalized_kind = profile_kind.strip()
    if normalized_kind not in {"none", "shared-process", "git-worktree", "docker", "remote-vm"}:
        raise ValueError(
            f"{prefix}.profileKind must be one of none, shared-process, git-worktree, "
            f"docker, or remote-vm"
        )
    profile_id = value.get("profileId", value.get("profile_id", ""))
    network_policy = value.get("networkPolicy", value.get("network_policy", "disabled"))
    secret_policy = value.get("secretPolicy", value.get("secret_policy", "deny"))
    mount_policy = value.get("mountPolicy", value.get("mount_policy", "lease-scoped"))
    for field, raw in (
        ("profileId", profile_id),
        ("networkPolicy", network_policy),
        ("secretPolicy", secret_policy),
        ("mountPolicy", mount_policy),
    ):
        if raw not in (None, "") and not isinstance(raw, str):
            raise ValueError(f"{prefix}.{field} must be a string when provided")
    return SandboxProfile(
        profile_id=(profile_id or normalized_kind).strip(),
        profile_kind=normalized_kind,  # type: ignore[arg-type]
        network_policy=(network_policy or "disabled").strip(),
        secret_policy=(secret_policy or "deny").strip(),
        mount_policy=(mount_policy or "lease-scoped").strip(),
    )


def _exchange_log_to_dict(log: Any) -> dict[str, Any]:
    if log is None:
        return {}
    return {
        "timestamp": log.timestamp,
        "actor": log.actor,
        "action": log.action,
        "channel": log.channel,
        "summary": log.summary,
        "related_artifact_ids": list(log.related_artifact_ids),
        "related_event_ids": list(log.related_event_ids),
        "related_run_ids": list(log.related_run_ids),
        "sequence": log.sequence,
        "clock": log.clock,
    }


class GovernanceTools:
    """Workspace-aware wrapper around Pipeline for MCP tool invocations.

    Rebuilds Pipeline state on public tool calls so long-lived MCP
    sessions keep seeing current pack manifests and derived context.
    """

    def __init__(
        self,
        project_root: str | Path,
        *,
        dry_run: bool = True,
        include_site_packages: bool = True,
    ) -> None:
        self._project_root = Path(project_root).resolve()
        self._dry_run = dry_run
        self._include_site_packages = include_site_packages
        self._pipeline: Pipeline | None = None
        self._init_error: ErrorInfo | None = None
        self._agent_output_sink = FileSink(self._project_root)
        self._refresh_pipeline()

    def _set_init_error(self, exc: Exception) -> None:
        self._pipeline = None
        self._init_error = ErrorInfo(
            category="init_failed",
            message=f"Pipeline failed to initialize: {exc}",
            source="mcp",
            suggestion="Check pack manifests and project structure, then retry or restart the MCP host if source code changed.",
            detail=str(exc),
        )
        _log.error("Pipeline initialization failed: %s", exc)

    def _refresh_pipeline(self) -> None:
        """Reload Pipeline from current workspace state."""
        try:
            self._pipeline = Pipeline.from_project(
                self._project_root,
                dry_run=self._dry_run,
                audit=True,
                include_site_packages=self._include_site_packages,
            )
            self._init_error = None
        except Exception as exc:
            self._set_init_error(exc)

    def _require_pipeline(self, *, refresh: bool = True) -> dict | None:
        """Return an error dict if pipeline is unavailable, else None."""
        if refresh:
            self._refresh_pipeline()
        if self._pipeline is not None:
            return None
        if self._init_error is not None:
            return self._init_error.to_dict()
        return ErrorInfo(
            category="init_failed",
            message="Pipeline is not available.",
            source="mcp",
        ).to_dict()

    def workspace_dbc_command(
        self,
        argv: list[str] | tuple[str, ...] | None,
        *,
        mode: str = "read",
        timeout_seconds: int = 30,
    ) -> dict:
        """Run a DBC CLI argv through this workspace's MCP package instance."""
        from ..runtime.orchestration import (
            WorkspaceDbcCommandRelayRequest,
            run_workspace_dbc_command_relay,
        )

        clean_argv = tuple(str(item) for item in (argv or ()))
        clean_mode = str(mode or "read").strip() or "read"
        try:
            clean_timeout = int(timeout_seconds)
        except (TypeError, ValueError):
            clean_timeout = 30
        result = run_workspace_dbc_command_relay(
            WorkspaceDbcCommandRelayRequest(
                project_root=self._project_root,
                argv=clean_argv,
                mode=clean_mode,  # type: ignore[arg-type]
                timeout_seconds=clean_timeout,
            )
        )
        return result.to_json_dict()

    def readback_inspect(
        self,
        *,
        kind: str,
        path: str = "",
        artifact_id: str = "",
        version: str = "",
        source_kind: str = "",
        latest_limit: int = 20,
        actor: str = "readback-inspection-mcp",
        timestamp: str = "",
    ) -> dict[str, Any]:
        """Inspect an existing record family as readback envelopes."""

        from ..runtime.orchestration import ReadbackInspectionRequest, inspect_readback

        result = inspect_readback(
            ReadbackInspectionRequest(
                project_root=self._project_root,
                kind=kind,
                path=path,
                artifact_id=artifact_id,
                version=version,
                source_kind=source_kind,
                latest_limit=int(latest_limit),
                actor=actor,
                timestamp=timestamp,
            )
        )
        return result.to_json_dict()

    def readback_timeline_inspect(
        self,
        *,
        sources: list[dict[str, Any]] | tuple[dict[str, Any], ...],
    ) -> dict[str, Any]:
        """Project explicit readback sources into one timeline."""

        from ..runtime.orchestration import (
            ReadbackTimelineInspectionRequest,
            ReadbackTimelineSource,
            inspect_readback_timeline,
        )

        timeline_sources = tuple(
            _readback_timeline_source_from_mapping(source, index=index)
            for index, source in enumerate(sources or ())
        )
        result = inspect_readback_timeline(
            ReadbackTimelineInspectionRequest(
                project_root=self._project_root,
                sources=timeline_sources,
            )
        )
        return result.to_json_dict()

    def write_output(self, content: str, *, title: str = "") -> str:
        """Write agent analysis to a visible surface and return the file path.

        Use this to surface analysis, tables, or summaries that the user
        needs to see. In MCP clients where chat text is invisible (e.g.
        VS Code Copilot Chat), this writes to .dbc/agent-output/latest.md.
        """
        return self._agent_output_sink.write(content, title=title)

    def _interaction_contract(self) -> dict[str, Any]:
        """Return the structured conversation progression contract."""
        default_contract: dict[str, Any] = {
            "termination_requires_user_permission": True,
            "final_reply_requires_forward_question": True,
            "question_must_include_analysis": True,
            "structured_confirmation_required_for": [
                "choice",
                "approval",
                "direction confirmation",
                "phase progression",
            ],
            "phase_completion_requires_next_direction": True,
            "allowed_non_question_endings": [
                "user explicitly allows ending",
                "user explicitly allows pausing",
                "user explicitly requests no follow-up question this turn",
            ],
        }

        if self._pipeline is None:
            return default_contract

        merged_rules = getattr(self._pipeline.pack_context, "merged_rules", {})
        contract = merged_rules.get("conversation_progression")
        if isinstance(contract, dict) and contract:
            return dict(contract)
        return default_contract

    @staticmethod
    def _question_instruction() -> str:
        return (
            "Provide your analysis or recommendation first, then continue with a forward question. "
            "When the user needs a structured choice, approval, direction confirmation, or phase progression decision, use the host's available confirmation surface when one exists; otherwise use a clear textual forward question."
        )

    # ── Hardcoded git remote guard (not overridable) ──────────────
    import re as _re

    _GIT_REMOTE_BLOCKED = ("push",)
    _GIT_REMOTE_RE = _re.compile(
        r"(?:^|[;&|]|\|\||&&|&)\s*"
        r'(?:"[^"]*[\\/])?'
        r"(?:[\w:/\\.-]*[\\/])?"
        r"git(?:\.exe)?\"?\s+"
        r"(?:" + "|".join(_GIT_REMOTE_BLOCKED) + r")"
        r"(?:\s|$|[;&|])",
        _re.IGNORECASE,
    )

    def _check_git_remote_guard(self, input_text: str) -> dict | None:
        """Return a BLOCK dict if input contains a remote git command."""
        # Only check terminal-command inputs
        lower = input_text.lower()
        if not lower.startswith("terminal-command:") and not lower.startswith("terminal:"):
            return None
        # Extract the command part after the prefix
        _, _, cmd = input_text.partition(":")
        cmd = cmd.strip()
        if not cmd:
            return None
        m = self._GIT_REMOTE_RE.search(cmd)
        if m is None:
            return None
        # Identify which subcommand matched
        matched = ""
        for sub in self._GIT_REMOTE_BLOCKED:
            if sub in m.group(0).lower():
                matched = sub
                break
        return {
            "decision": "BLOCK",
            "reason": f"Remote git operation '{matched}' is permanently blocked in this workspace.",
            "constraint_violated": ["C-HARDCODED-GIT-PUSH"],
            "required_action": "git push is disabled to prevent unintended remote modifications. Read-only operations (pull/fetch/clone) are allowed.",
            "hardcoded": True,
        }

    def _external_skill_interaction_contract(self) -> dict[str, Any]:
        merged_rules: dict[str, Any] | None = None
        if self._pipeline is not None:
            merged_rules = getattr(self._pipeline.pack_context, "merged_rules", {})
        return build_external_skill_interaction_contract(
            self._project_root,
            merged_rules,
        )

    def local_trajectory(
        self,
        action: str,
        *,
        lane_label: str = "",
        first_event_title: str = "",
        title: str = "",
        event_kind: str = "",
        summary: str = "",
        guide_context: str = "",
        current_event_id: str = "",
        reason: str = "",
        lane_id: str = "",
        lanes: list[dict[str, str]] | str | None = None,
        source_event_id: str = "",
        target_lane_id: str = "",
        target_event_id: str = "",
        source_lane_id: str = "",
        relation_kind: str = "",
        first_child_event_title: str = "",
        child_lane_label: str = "",
        range_start_event_id: str = "",
        range_end_event_id: str = "",
        pack_ranges: list[dict[str, str]] | str | None = None,
        anchor_lane_id: str = "",
        parent_event_id: str = "",
        child_trajectory_id: str = "",
        source_endpoint_trajectory_id: str = "",
        source_endpoint_event_id: str = "",
        source_endpoint_parent_event_id: str = "",
        source_endpoint_compound_path: str = "",
        target_endpoint_trajectory_id: str = "",
        target_endpoint_event_id: str = "",
        target_endpoint_parent_event_id: str = "",
        target_endpoint_compound_path: str = "",
        source_graph_id: str = "",
        source_node_id: str = "",
        caller_role: str = "",
    ) -> dict[str, Any]:
        """Mutate the agent-owned Local Work Trajectory artifact.

        This is intentionally narrower than general file editing: it only writes
        `.dbc/progress-graph/local-work-trajectory.json` through the progress
        graph lifecycle API so MCP hosts such as Codex can track work without a
        human-maintained UI button path.
        """

        allowed_event_kinds = {
            "start",
            "task",
            "decision",
            "review",
            "wait",
            "validation",
            "writeback",
            "handoff",
            "compound",
            "merge",
            "close",
        }

        from tools.progress_graph import (
            add_local_work_compound,
            add_local_work_lane,
            add_local_work_lanes,
            add_local_work_relation,
            advance_local_work_child_event,
            advance_single_line_event,
            append_local_work_child_event,
            append_single_line_event,
            block_single_line_event,
            close_local_work_child_trajectory,
            close_single_line_trajectory,
            load_local_work_trajectory,
            merge_local_work_lane,
            pack_local_work_range,
            pack_local_work_subgraph,
            resume_single_line_event,
            set_local_work_trajectory_anchor,
            start_single_line_trajectory,
            trajectory_json_path,
            update_single_line_event,
        )

        normalized_caller_role = caller_role.strip().lower().replace("-", "_")
        denied_caller_roles = {
            "worker",
            "subagent",
            "sub_agent",
            "lane_worker",
            "bounded_worker",
            "child_worker",
        }
        if normalized_caller_role in denied_caller_roles:
            return {
                "ok": False,
                "error": (
                    "localTrajectory is leader/main/supervisor authority. "
                    "Workers and subagents must report trajectory changes through "
                    "Subagent Report.trajectory_update for leader consumption. "
                    "Write the update in the worker report using docs/worker-trajectory-update-reporting.md."
                ),
                "action": action,
                "callerRole": caller_role,
                "trajectory_path": str(trajectory_json_path(self._project_root)),
            }

        normalized_action = action.strip()
        allowed_actions = {"start", "append", "advance", "update", "block", "wait", "resume", "close", "addLane", "addLanes", "addCompound", "packRange", "packSubgraph", "appendChild", "advanceChild", "closeChild", "merge", "relate", "setAnchor"}
        if normalized_action not in allowed_actions:
            return {
                "ok": False,
                "error": (
                    "localTrajectory action must be start, append, advance, "
                    "update, block, wait, resume, close, addLane, addLanes, addCompound, "
                    "packRange, packSubgraph, appendChild, advanceChild, closeChild, merge, relate, or setAnchor."
                ),
                "action": action,
            }

        allowed_relation_kinds = {
            "depends_on",
            "waits_for",
            "unblocks",
            "hands_off",
            "syncs_from",
            "merges_into",
            "proposes_new_line",
            "approves_new_line",
        }
        normalized_relation_kind = relation_kind.strip()
        if normalized_action == "relate":
            if not source_event_id:
                return {
                    "ok": False,
                    "error": "localTrajectory relate requires sourceEventId.",
                    "action": normalized_action,
                }
            if not target_event_id:
                return {
                    "ok": False,
                    "error": "localTrajectory relate requires targetEventId.",
                    "action": normalized_action,
                }
            if normalized_relation_kind not in allowed_relation_kinds:
                return {
                    "ok": False,
                    "error": (
                        "localTrajectory relationKind must be one of: "
                        f"{', '.join(sorted(allowed_relation_kinds))}."
                    ),
                    "action": normalized_action,
                    "relationKind": relation_kind,
                }

        normalized_event_kind = event_kind.strip()
        if normalized_event_kind and normalized_event_kind not in allowed_event_kinds:
            return {
                "ok": False,
                "error": (
                    "localTrajectory eventKind must be one of: "
                    f"{', '.join(sorted(allowed_event_kinds))}."
                ),
                "action": normalized_action,
                "eventKind": event_kind,
            }

        try:
            if normalized_action == "start":
                if not first_event_title and not title:
                    return {
                        "ok": False,
                        "error": "localTrajectory start requires firstEventTitle or title.",
                        "action": normalized_action,
                    }
                path = start_single_line_trajectory(
                    self._project_root,
                    title=title or "Local Work Trajectory",
                    lane_label=lane_label or "当前工作",
                    first_event_title=first_event_title or title,
                    first_event_kind=normalized_event_kind or "start",
                    guide_context=guide_context or "codex-mcp-agent",
                    source_graph_id=source_graph_id,
                    source_node_id=source_node_id,
                )
            elif normalized_action == "append":
                if not title:
                    return {
                        "ok": False,
                        "error": "localTrajectory append requires title.",
                        "action": normalized_action,
                    }
                path = append_single_line_event(
                    self._project_root,
                    title=title,
                    kind=normalized_event_kind or "task",
                    summary=summary,
                    lane_id=lane_id,
                )
            else:
                if normalized_action == "advance":
                    path = advance_single_line_event(
                        self._project_root,
                        current_event_id=current_event_id or None,
                    )
                elif normalized_action == "update":
                    path = update_single_line_event(
                        self._project_root,
                        current_event_id=current_event_id or None,
                        title=title,
                        summary=summary,
                    )
                elif normalized_action in {"block", "wait"}:
                    path = block_single_line_event(
                        self._project_root,
                        current_event_id=current_event_id or None,
                        reason=reason or summary,
                        waiting=normalized_action == "wait",
                    )
                elif normalized_action == "resume":
                    path = resume_single_line_event(
                        self._project_root,
                        current_event_id=current_event_id or None,
                        summary=summary,
                    )
                elif normalized_action == "addLane":
                    if not lane_label:
                        return {
                            "ok": False,
                            "error": "localTrajectory addLane requires laneLabel.",
                            "action": normalized_action,
                        }
                    if not first_event_title and not title:
                        return {
                            "ok": False,
                            "error": "localTrajectory addLane requires firstEventTitle or title.",
                            "action": normalized_action,
                        }
                    path = add_local_work_lane(
                        self._project_root,
                        lane_label=lane_label,
                        first_event_title=first_event_title or title,
                        first_event_kind=normalized_event_kind or "task",
                        first_event_summary=summary,
                        source_event_id=source_event_id or current_event_id or None,
                        lane_id=lane_id,
                    )
                elif normalized_action == "addLanes":
                    if not lanes:
                        return {
                            "ok": False,
                            "error": "localTrajectory addLanes requires lanes.",
                            "action": normalized_action,
                        }
                    path = add_local_work_lanes(
                        self._project_root,
                        lanes=lanes,
                        source_event_id=source_event_id or current_event_id or None,
                    )
                elif normalized_action == "addCompound":
                    if not title:
                        return {
                            "ok": False,
                            "error": "localTrajectory addCompound requires title.",
                            "action": normalized_action,
                        }
                    path = add_local_work_compound(
                        self._project_root,
                        title=title,
                        summary=summary,
                        lane_id=lane_id,
                        first_child_event_title=first_child_event_title or first_event_title,
                        first_child_event_kind=normalized_event_kind or "task",
                        first_child_event_summary=summary if (first_child_event_title or first_event_title) else "",
                        child_lane_label=child_lane_label or lane_label or title,
                    )
                elif normalized_action == "packRange":
                    pack_start_event_id = range_start_event_id or source_event_id
                    pack_end_event_id = range_end_event_id or target_event_id
                    if not title:
                        return {
                            "ok": False,
                            "error": "localTrajectory packRange requires title.",
                            "action": normalized_action,
                        }
                    if not pack_start_event_id:
                        return {
                            "ok": False,
                            "error": "localTrajectory packRange requires rangeStartEventId or sourceEventId.",
                            "action": normalized_action,
                        }
                    if not pack_end_event_id:
                        return {
                            "ok": False,
                            "error": "localTrajectory packRange requires rangeEndEventId or targetEventId.",
                            "action": normalized_action,
                        }
                    path = pack_local_work_range(
                        self._project_root,
                        title=title,
                        range_start_event_id=pack_start_event_id,
                        range_end_event_id=pack_end_event_id,
                        summary=summary,
                        child_lane_label=child_lane_label or lane_label or title,
                    )
                elif normalized_action == "packSubgraph":
                    if not title:
                        return {
                            "ok": False,
                            "error": "localTrajectory packSubgraph requires title.",
                            "action": normalized_action,
                        }
                    if not pack_ranges:
                        return {
                            "ok": False,
                            "error": "localTrajectory packSubgraph requires packRanges.",
                            "action": normalized_action,
                        }
                    path = pack_local_work_subgraph(
                        self._project_root,
                        title=title,
                        ranges=pack_ranges,
                        anchor_lane_id=anchor_lane_id or lane_id,
                        summary=summary,
                    )
                elif normalized_action == "appendChild":
                    if not title:
                        return {
                            "ok": False,
                            "error": "localTrajectory appendChild requires title.",
                            "action": normalized_action,
                        }
                    path = append_local_work_child_event(
                        self._project_root,
                        title=title,
                        child_trajectory_id=child_trajectory_id,
                        parent_event_id=parent_event_id or target_event_id or current_event_id,
                        kind=normalized_event_kind or "task",
                        summary=summary,
                        lane_id=lane_id,
                        child_lane_label=child_lane_label or lane_label or title,
                    )
                elif normalized_action == "advanceChild":
                    path = advance_local_work_child_event(
                        self._project_root,
                        child_trajectory_id=child_trajectory_id,
                        parent_event_id=parent_event_id or target_event_id,
                        current_event_id=current_event_id or None,
                    )
                elif normalized_action == "closeChild":
                    path = close_local_work_child_trajectory(
                        self._project_root,
                        child_trajectory_id=child_trajectory_id,
                        parent_event_id=parent_event_id or target_event_id,
                        current_event_id=current_event_id or None,
                        summary=summary,
                    )
                elif normalized_action == "merge":
                    merge_source_lane_id = source_lane_id or lane_id
                    if not merge_source_lane_id:
                        return {
                            "ok": False,
                            "error": "localTrajectory merge requires sourceLaneId or laneId.",
                            "action": normalized_action,
                        }
                    path = merge_local_work_lane(
                        self._project_root,
                        source_lane_id=merge_source_lane_id,
                        target_lane_id=target_lane_id or "lane:main",
                        title=title or "merge",
                        summary=summary,
                        source_event_id=source_event_id or current_event_id or None,
                        target_event_id=target_event_id or None,
                    )
                elif normalized_action == "relate":
                    source_endpoint = None
                    target_endpoint = None
                    if source_endpoint_trajectory_id or source_endpoint_event_id:
                        source_endpoint = {
                            "trajectory_id": source_endpoint_trajectory_id,
                            "event_id": source_endpoint_event_id,
                            "parent_event_id": source_endpoint_parent_event_id,
                            "compound_path": source_endpoint_compound_path,
                        }
                    if target_endpoint_trajectory_id or target_endpoint_event_id:
                        target_endpoint = {
                            "trajectory_id": target_endpoint_trajectory_id,
                            "event_id": target_endpoint_event_id,
                            "parent_event_id": target_endpoint_parent_event_id,
                            "compound_path": target_endpoint_compound_path,
                        }
                    path = add_local_work_relation(
                        self._project_root,
                        source_event_id=source_event_id,
                        target_event_id=target_event_id,
                        relation_kind=normalized_relation_kind,
                        summary=summary,
                        source_endpoint=source_endpoint,
                        target_endpoint=target_endpoint,
                    )
                elif normalized_action == "setAnchor":
                    path = set_local_work_trajectory_anchor(
                        self._project_root,
                        source_graph_id=source_graph_id,
                        source_node_id=source_node_id,
                        summary=summary,
                        reason=reason,
                    )
                else:
                    path = close_single_line_trajectory(
                        self._project_root,
                        current_event_id=current_event_id or None,
                        summary=summary,
                    )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "action": normalized_action,
                "trajectory_path": str(trajectory_json_path(self._project_root)),
            }

        trajectory = load_local_work_trajectory(self._project_root)
        active_event_id = None
        active_event_ids = []
        for event_id, event in sorted(
            trajectory.events.items(),
            key=lambda item: (item[1].order, item[0]),
        ):
            if event.status == "in_progress":
                active_event_ids.append(event_id)
                if active_event_id is None:
                    active_event_id = event_id

        return {
            "ok": True,
            "action": normalized_action,
            "trajectory_path": str(path),
            "trajectory_id": trajectory.trajectory_id,
            "event_count": len(trajectory.events),
            "relation_count": len(trajectory.relations),
            "child_trajectory_count": len(trajectory.child_trajectories),
            "active_event_id": active_event_id,
            "active_event_ids": active_event_ids,
            "lane_count": len(trajectory.lanes),
            "metadata": dict(trajectory.metadata),
        }

    def consume_worker_trajectory_report(
        self,
        *,
        report_path: str,
        caller_role: str = "leader",
        actor: str = "leader",
        current_event_id: str = "",
        title: str = "",
        event_kind: str = "task",
        start_if_missing: bool = True,
        trajectory_title: str = "Local Work Trajectory",
        guide_context: str = "worker-trajectory-report-consumer",
    ) -> dict[str, Any]:
        """Consume Subagent Report.trajectory_update as leader-owned mutation."""

        from ..runtime.orchestration import (
            WorkerTrajectoryReportConsumerRequest,
            consume_worker_trajectory_report,
        )

        if not report_path:
            from tools.progress_graph import trajectory_json_path

            return {
                "ok": False,
                "status": "validation_failed",
                "error": "consumeWorkerTrajectoryReport requires reportPath.",
                "report_path": "",
                "trajectory_path": str(trajectory_json_path(self._project_root)),
                "authority_split": {
                    "source": "Subagent Report.trajectory_update",
                    "leader_review_required": True,
                    "worker_report_read": False,
                    "schema_validated": False,
                    "local_work_trajectory_mutated": False,
                    "worker_direct_mutation_allowed": False,
                    "provider_executed": False,
                    "scheduler_state_mutated": False,
                    "exchange_store_mutated": False,
                },
                "worker_report_procedure": "docs/worker-trajectory-update-reporting.md",
            }

        request = WorkerTrajectoryReportConsumerRequest(
            project_root=self._project_root,
            report_path=report_path,
            caller_role=caller_role,
            actor=actor,
            current_event_id=current_event_id,
            title=title,
            event_kind=event_kind,
            start_if_missing=start_if_missing,
            trajectory_title=trajectory_title,
            guide_context=guide_context,
        )
        return consume_worker_trajectory_report(request).to_json_dict()

    def trajectory_team_continuity(
        self,
        *,
        action: str,
        caller_role: str = "leader",
        trajectory_id: str = "",
        lane_id: str = "",
        leader_id: str = "agent:guide",
        worker_id: str = "",
        runtime_provider: str = "opencode",
        binding_id: str = "",
        ownership_id: str = "",
        replacement_binding_id: str = "",
        new_binding_id: str = "",
        source_binding_id: str = "",
        no_continuity_reason: str = "",
        task_id: str = "",
        delivery_id: str = "",
        timestamp: str = "",
        reason: str = "",
        binding_ledger_path: str = "",
        binding_event_log_path: str = "",
        ownership_ledger_path: str = "",
        ownership_event_log_path: str = "",
        lease_ledger_path: str = "",
        team_event_log_path: str = "",
        scheduler_event_log_path: str = "",
        attach_url: str = "",
        session_id: str = "",
        continue_session: bool = False,
        fork_session: bool = False,
        compact_context_ref: str = "",
        mailbox_cursor_ref: str = "",
        worker_report_refs: list[str] | tuple[str, ...] | None = None,
        audit_refs: list[str] | tuple[str, ...] | None = None,
        include_inactive: bool = True,
    ) -> dict[str, Any]:
        """Run trajectory team continuity through the shared runtime dispatcher."""

        from ..runtime.orchestration import (
            DEFAULT_CONTINUOUS_WORKER_BINDING_EVENT_LOG_RELATIVE_PATH,
            DEFAULT_CONTINUOUS_WORKER_BINDING_LEDGER_RELATIVE_PATH,
            DEFAULT_CONTINUOUS_WORKER_DELIVERY_LEASE_LEDGER_RELATIVE_PATH,
            DEFAULT_CONTINUOUS_WORKER_LANE_OWNERSHIP_EVENT_LOG_RELATIVE_PATH,
            DEFAULT_CONTINUOUS_WORKER_LANE_OWNERSHIP_LEDGER_RELATIVE_PATH,
            DEFAULT_TRAJECTORY_TEAM_CONTINUITY_EVENT_LOG_RELATIVE_PATH,
            TrajectoryTeamContinuitySurfaceRequest,
            run_trajectory_team_continuity_surface,
        )

        request = TrajectoryTeamContinuitySurfaceRequest(
            action=action,  # type: ignore[arg-type]
            project_root=self._project_root,
            caller_role=caller_role,
            trajectory_id=trajectory_id,
            lane_id=lane_id,
            leader_id=leader_id or "agent:guide",
            worker_id=worker_id,
            runtime_provider=runtime_provider or "opencode",
            binding_id=binding_id,
            ownership_id=ownership_id,
            replacement_binding_id=replacement_binding_id,
            new_binding_id=new_binding_id,
            source_binding_id=source_binding_id,
            no_continuity_reason=no_continuity_reason,
            task_id=task_id,
            delivery_id=delivery_id,
            timestamp=timestamp,
            reason=reason,
            binding_ledger_path=(
                binding_ledger_path
                or DEFAULT_CONTINUOUS_WORKER_BINDING_LEDGER_RELATIVE_PATH
            ),
            binding_event_log_path=(
                binding_event_log_path
                or DEFAULT_CONTINUOUS_WORKER_BINDING_EVENT_LOG_RELATIVE_PATH
            ),
            ownership_ledger_path=(
                ownership_ledger_path
                or DEFAULT_CONTINUOUS_WORKER_LANE_OWNERSHIP_LEDGER_RELATIVE_PATH
            ),
            ownership_event_log_path=(
                ownership_event_log_path
                or DEFAULT_CONTINUOUS_WORKER_LANE_OWNERSHIP_EVENT_LOG_RELATIVE_PATH
            ),
            lease_ledger_path=(
                lease_ledger_path
                or DEFAULT_CONTINUOUS_WORKER_DELIVERY_LEASE_LEDGER_RELATIVE_PATH
            ),
            team_event_log_path=(
                team_event_log_path
                or DEFAULT_TRAJECTORY_TEAM_CONTINUITY_EVENT_LOG_RELATIVE_PATH
            ),
            scheduler_event_log_path=scheduler_event_log_path,
            attach_url=attach_url,
            session_id=session_id,
            continue_session=continue_session,
            fork_session=fork_session,
            compact_context_ref=compact_context_ref,
            mailbox_cursor_ref=mailbox_cursor_ref,
            worker_report_refs=tuple(worker_report_refs or ()),
            audit_refs=tuple(audit_refs or ()),
            include_inactive=include_inactive,
        )
        return run_trajectory_team_continuity_surface(request).to_json_dict()

    def scheduler_submit_tasks(
        self,
        *,
        snapshot_path: str,
        event_log_path: str,
        batch: dict[str, Any] | None = None,
        batch_id: str = "",
        tasks: list[dict[str, Any]] | None = None,
        title: str = "",
        summary: str = "",
        artifact_id: str = "",
        artifact_version: str = "v1",
        producer: str = "schedulerSubmitTasks",
        timestamp: str = "",
        replace_existing: bool = False,
    ) -> dict[str, Any]:
        """Submit scheduler task contracts into snapshot/event-log persistence."""

        if not snapshot_path:
            return {
                "ok": False,
                "error": "schedulerSubmitTasks requires snapshotPath.",
            }
        if not event_log_path:
            return {
                "ok": False,
                "error": "schedulerSubmitTasks requires eventLogPath.",
            }

        from ..runtime.orchestration import (
            ExchangeArtifact,
            ExchangePayloadPart,
            SchedulerState,
            read_scheduler_state_snapshot,
            submit_scheduler_task_batch_with_persistence,
        )
        from ..runtime.orchestration.scheduler_submission import (
            TASK_BATCH_SUBMISSION_PRODUCT_TYPE,
            scheduler_task_batch_submission_from_artifact,
            scheduler_task_batch_submission_to_artifact,
        )

        def resolve_path(value: str) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        snapshot = resolve_path(snapshot_path)
        event_log = resolve_path(event_log_path)
        normalized_batch = _normalize_scheduler_submission_keys(batch or {})
        if normalized_batch and not isinstance(normalized_batch, dict):
            return {
                "ok": False,
                "error": "schedulerSubmitTasks field batch must be an object when provided.",
                "snapshot_path": str(snapshot),
                "event_log_path": str(event_log),
            }
        normalized_tasks = _normalize_scheduler_submission_keys(tasks) if tasks is not None else None
        if normalized_tasks is not None and not isinstance(normalized_tasks, list):
            return {
                "ok": False,
                "error": "schedulerSubmitTasks field tasks must be a list when provided.",
                "snapshot_path": str(snapshot),
                "event_log_path": str(event_log),
            }

        payload: dict[str, Any] = dict(normalized_batch)
        payload.setdefault("product_type", TASK_BATCH_SUBMISSION_PRODUCT_TYPE)
        if normalized_tasks is not None:
            payload["tasks"] = normalized_tasks
        if batch_id:
            payload["batch_id"] = batch_id
        if title:
            payload["title"] = title
        if summary:
            payload["summary"] = summary

        source_batch_id = str(payload.get("batch_id", "") or "")
        if not source_batch_id:
            return {
                "ok": False,
                "error": "schedulerSubmitTasks requires batch.batch_id or batchId.",
                "snapshot_path": str(snapshot),
                "event_log_path": str(event_log),
            }

        source_artifact_id = artifact_id or f"scheduler-task-batch-submission:{source_batch_id}"
        source_artifact_version = artifact_version or str(payload.get("artifact_version", "") or "v1")
        seed_artifact = ExchangeArtifact(
            artifact_id=source_artifact_id,
            kind="request",
            intent="propose",
            producer=producer,
            created_at=timestamp,
            version=source_artifact_version,
            parts=(
                ExchangePayloadPart(part_type="structured", data=payload),
            ),
        )

        try:
            snapshot_existed = snapshot.exists()
            state = read_scheduler_state_snapshot(snapshot) if snapshot_existed else SchedulerState()
            parsed_batch = scheduler_task_batch_submission_from_artifact(seed_artifact)
            artifact = scheduler_task_batch_submission_to_artifact(
                parsed_batch,
                artifact_id=source_artifact_id,
                producer=producer,
                created_at=timestamp,
                version=source_artifact_version,
            )
            persisted = submit_scheduler_task_batch_with_persistence(
                state,
                artifact,
                snapshot_path=snapshot,
                event_log_path=event_log,
                replace_existing=replace_existing,
                timestamp=artifact.created_at,
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "snapshot_path": str(snapshot),
                "event_log_path": str(event_log),
                "source_artifact_id": source_artifact_id,
                "source_artifact_version": source_artifact_version,
            }

        submitted_tasks = persisted.submission.tasks
        dependencies = persisted.submission.dependencies_added
        state_after = persisted.submission.state
        return {
            "ok": True,
            "snapshot_path": str(persisted.snapshot_path),
            "event_log_path": str(persisted.event_log_path),
            "snapshot_existed": snapshot_existed,
            "source_artifact_id": persisted.submission.source_artifact_id,
            "source_artifact_version": persisted.submission.source_artifact_version,
            "submitted_task_ids": [task.task_id for task in submitted_tasks],
            "submission_event_ids": list(persisted.submission_event_ids),
            "dependencies_added": [dependency.dependency_id for dependency in dependencies],
            "task_count": len(submitted_tasks),
            "dependency_count": len(dependencies),
            "state_task_count": len(state_after.tasks),
            "state_dependency_count": len(state_after.dependencies),
            "ran_tasks": False,
            "refreshed_projection": False,
            "local_trajectory_mutated": False,
            "source_log": _exchange_log_to_dict(artifact.parts[1].log) if len(artifact.parts) > 1 else {},
        }

    def admit_exchange_artifact(
        self,
        *,
        artifact_id: str,
        version: str,
        snapshot_path: str,
        event_log_path: str,
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        allow_duplicate_admission: bool = False,
        replace_existing: bool = False,
        mark_consumed_on_success: bool = False,
        actor: str = "mcp",
        timestamp: str = "",
    ) -> dict[str, Any]:
        """Admit one exact stored ExchangeArtifact version into scheduler state."""

        if not artifact_id:
            return {
                "ok": False,
                "error": "admitExchangeArtifact requires artifactId.",
            }
        if not version:
            return {
                "ok": False,
                "error": "admitExchangeArtifact requires version.",
            }
        if not snapshot_path:
            return {
                "ok": False,
                "error": "admitExchangeArtifact requires snapshotPath.",
            }
        if not event_log_path:
            return {
                "ok": False,
                "error": "admitExchangeArtifact requires eventLogPath.",
            }

        from ..runtime.orchestration import (
            admit_exchange_artifact_version_with_ledger,
            default_exchange_artifact_admission_ledger_path,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        ledger = (
            resolve_path(admission_ledger_path)
            if admission_ledger_path
            else default_exchange_artifact_admission_ledger_path(self._project_root)
        )

        return admit_exchange_artifact_version_with_ledger(
            artifact_store_path=store,
            artifact_id=artifact_id,
            version=version,
            snapshot_path=resolve_path(snapshot_path),
            event_log_path=resolve_path(event_log_path),
            admission_ledger_path=ledger,
            allow_duplicate_admission=allow_duplicate_admission,
            replace_existing=replace_existing,
            mark_consumed_on_success=mark_consumed_on_success,
            actor=actor or "mcp",
            surface="mcp:admitExchangeArtifact",
            timestamp=timestamp,
        )

    def scheduler_binding_reference_inspect(
        self,
        *,
        artifact_id: str,
        version: str,
        artifact_store_path: str = "",
    ) -> dict[str, Any]:
        """Read supervisor storage binding refs in one stored scheduler submission."""

        if not artifact_id:
            return {
                "ok": False,
                "error": "schedulerBindingReferenceInspect requires artifactId.",
            }
        if not version:
            return {
                "ok": False,
                "error": "schedulerBindingReferenceInspect requires version.",
            }

        from ..runtime.orchestration import (
            default_exchange_artifact_store_path,
            inspect_supervisor_storage_binding_artifact_refs_for_submission,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )

        inspection = inspect_supervisor_storage_binding_artifact_refs_for_submission(
            artifact_store_path=store,
            artifact_id=artifact_id,
            version=version,
        )
        return inspection.to_json_dict()

    def agent_exchange_mailbox(
        self,
        *,
        agent_id: str,
        artifact_store_path: str = "",
        include_archived: bool = False,
    ) -> dict[str, Any]:
        """Read one agent's ExchangeArtifact mailbox without mutation."""

        if not agent_id:
            return {
                "ok": False,
                "error": "agentExchangeMailbox requires agentId.",
            }

        from ..runtime.orchestration import (
            default_exchange_artifact_store_path,
            inspect_agent_exchange_mailbox,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )

        mailbox = inspect_agent_exchange_mailbox(
            store,
            agent_id=agent_id,
            include_archived=include_archived,
        )
        payload = {"ok": not mailbox.errors}
        payload.update(mailbox.to_json_dict())
        return payload

    def agent_exchange_history(
        self,
        *,
        agent_id: str = "",
        correlation_id: str = "",
        artifact_store_path: str = "",
        include_archived: bool = False,
    ) -> dict[str, Any]:
        """Read compact ExchangeArtifact communication history without mutation."""

        from ..runtime.orchestration import (
            default_exchange_artifact_store_path,
            inspect_agent_exchange_history_summary,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        summary = inspect_agent_exchange_history_summary(
            store,
            agent_id=agent_id,
            correlation_id=correlation_id,
            include_archived=include_archived,
        )
        payload = {"ok": not summary.errors}
        payload.update(summary.to_json_dict())
        return payload

    def agent_exchange_action_candidates(
        self,
        *,
        agent_id: str = "",
        candidate_type: str = "",
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        include_archived: bool = False,
    ) -> dict[str, Any]:
        """Read ExchangeArtifact action candidates without mutation."""

        from ..runtime.orchestration import (
            default_exchange_artifact_admission_ledger_path,
            default_exchange_artifact_store_path,
            inspect_agent_exchange_action_candidates,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        ledger = (
            resolve_path(admission_ledger_path)
            if admission_ledger_path
            else default_exchange_artifact_admission_ledger_path(self._project_root)
        )
        summary = inspect_agent_exchange_action_candidates(
            store,
            agent_id=agent_id,
            candidate_type=candidate_type,
            include_archived=include_archived,
            admission_ledger_path=ledger,
        )
        payload = {"ok": not summary.errors}
        payload.update(summary.to_json_dict())
        return payload

    def agent_exchange_action_candidate_decide(
        self,
        *,
        candidate_id: str,
        disposition_artifact_id: str,
        actor: str,
        disposition: str,
        artifact_store_path: str = "",
        disposition_version: str = "v1",
        reason: str = "",
        target_surface: str = "",
        replacement_artifact_id: str = "",
        replacement_version: str = "",
        timestamp: str = "",
        replace_existing: bool = False,
    ) -> dict[str, Any]:
        """Write one action-candidate disposition ExchangeArtifact."""

        if not candidate_id:
            return {"ok": False, "error": "agentExchangeActionCandidateDecide requires candidateId."}
        if not disposition_artifact_id:
            return {
                "ok": False,
                "error": "agentExchangeActionCandidateDecide requires dispositionArtifactId.",
            }
        if not actor:
            return {"ok": False, "error": "agentExchangeActionCandidateDecide requires actor."}
        if not disposition:
            return {"ok": False, "error": "agentExchangeActionCandidateDecide requires disposition."}

        from ..runtime.orchestration import (
            decide_agent_exchange_action_candidate,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        try:
            result = decide_agent_exchange_action_candidate(
                store_path=store,
                candidate_id=candidate_id,
                disposition_artifact_id=disposition_artifact_id,
                disposition_version=disposition_version,
                actor=actor,
                disposition=disposition,  # type: ignore[arg-type]
                reason=reason,
                target_surface=target_surface,
                replacement_artifact_id=replacement_artifact_id,
                replacement_version=replacement_version,
                timestamp=timestamp,
                replace_existing=replace_existing,
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        return result.to_json_dict()

    def agent_exchange_accepted_scheduler_candidate_consume(
        self,
        *,
        disposition_artifact_id: str,
        disposition_version: str,
        snapshot_path: str,
        event_log_path: str,
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        allow_duplicate_admission: bool = False,
        replace_existing: bool = False,
        validate_binding_artifact_refs: bool = False,
        mark_consumed_on_success: bool = False,
        actor: str = "mcp",
        timestamp: str = "",
    ) -> dict[str, Any]:
        """Consume accepted scheduler candidate disposition via exact admission."""

        if not disposition_artifact_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedSchedulerCandidateConsume requires dispositionArtifactId.",
            }
        if not disposition_version:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedSchedulerCandidateConsume requires dispositionVersion.",
            }
        if not snapshot_path:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedSchedulerCandidateConsume requires snapshotPath.",
            }
        if not event_log_path:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedSchedulerCandidateConsume requires eventLogPath.",
            }

        from ..runtime.orchestration import (
            consume_accepted_scheduler_action_candidate,
            default_exchange_artifact_admission_ledger_path,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        ledger = (
            resolve_path(admission_ledger_path)
            if admission_ledger_path
            else default_exchange_artifact_admission_ledger_path(self._project_root)
        )
        try:
            result = consume_accepted_scheduler_action_candidate(
                artifact_store_path=store,
                disposition_artifact_id=disposition_artifact_id,
                disposition_version=disposition_version,
                snapshot_path=resolve_path(snapshot_path),
                event_log_path=resolve_path(event_log_path),
                admission_ledger_path=ledger,
                allow_duplicate_admission=allow_duplicate_admission,
                replace_existing=replace_existing,
                validate_binding_artifact_refs=validate_binding_artifact_refs,
                mark_consumed_on_success=mark_consumed_on_success,
                actor=actor or "mcp",
                timestamp=timestamp,
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        return result.to_json_dict()

    def agent_exchange_accepted_review_candidate_consume(
        self,
        *,
        disposition_artifact_id: str,
        disposition_version: str,
        artifact_store_path: str = "",
        actor: str = "mcp",
    ) -> dict[str, Any]:
        """Consume accepted review candidate disposition via review intake."""

        if not disposition_artifact_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedReviewCandidateConsume requires dispositionArtifactId.",
            }
        if not disposition_version:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedReviewCandidateConsume requires dispositionVersion.",
            }

        from ..pep.executor import Executor
        from ..review.feedback_api import FeedbackAPI
        from ..runtime.orchestration import (
            FeedbackAPIReviewIntakeConsumer,
            consume_accepted_review_action_candidate,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        feedback_api = FeedbackAPI(Executor(dry_run=True))
        try:
            result = consume_accepted_review_action_candidate(
                artifact_store_path=store,
                disposition_artifact_id=disposition_artifact_id,
                disposition_version=disposition_version,
                review_intake_consumer=FeedbackAPIReviewIntakeConsumer(feedback_api),
                actor=actor or "mcp",
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        payload = result.to_json_dict()
        payload["review_pending"] = feedback_api.list_pending()
        return payload

    def agent_exchange_accepted_handoff_candidate_consume(
        self,
        *,
        disposition_artifact_id: str,
        disposition_version: str,
        handoff_dir: str,
        artifact_store_path: str = "",
        actor: str = "mcp",
    ) -> dict[str, Any]:
        """Consume accepted handoff candidate disposition via handoff delivery."""

        if not disposition_artifact_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedHandoffCandidateConsume requires dispositionArtifactId.",
            }
        if not disposition_version:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedHandoffCandidateConsume requires dispositionVersion.",
            }
        if not handoff_dir:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedHandoffCandidateConsume requires handoffDir.",
            }

        from ..runtime.orchestration import (
            FileHandoffConsumer,
            consume_accepted_handoff_action_candidate,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        try:
            result = consume_accepted_handoff_action_candidate(
                artifact_store_path=store,
                disposition_artifact_id=disposition_artifact_id,
                disposition_version=disposition_version,
                handoff_consumer=FileHandoffConsumer(resolve_path(handoff_dir)),
                actor=actor or "mcp",
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        return result.to_json_dict()

    def agent_exchange_accepted_merge_candidate_consume(
        self,
        *,
        disposition_artifact_id: str,
        disposition_version: str,
        snapshot_path: str,
        gate_id: str,
        approved: bool | None,
        artifact_store_path: str = "",
        merge_gate_event_log_path: str = "",
        reason: str = "",
        actor: str = "mcp",
        resolved_at: str = "",
        timestamp: str = "",
    ) -> dict[str, Any]:
        """Consume accepted merge candidate disposition via explicit merge gate resolution."""

        if not disposition_artifact_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedMergeCandidateConsume requires dispositionArtifactId.",
            }
        if not disposition_version:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedMergeCandidateConsume requires dispositionVersion.",
            }
        if not snapshot_path:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedMergeCandidateConsume requires snapshotPath.",
            }
        if not gate_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedMergeCandidateConsume requires gateId.",
            }
        if approved is None:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedMergeCandidateConsume requires approved.",
            }

        from ..runtime.orchestration import (
            consume_accepted_merge_action_candidate,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        try:
            result = consume_accepted_merge_action_candidate(
                artifact_store_path=store,
                disposition_artifact_id=disposition_artifact_id,
                disposition_version=disposition_version,
                snapshot_path=resolve_path(snapshot_path),
                gate_id=gate_id,
                approved=bool(approved),
                reason=reason,
                merge_gate_event_log_path=(
                    resolve_path(merge_gate_event_log_path)
                    if merge_gate_event_log_path
                    else None
                ),
                actor=actor or "mcp",
                resolved_at=resolved_at,
                timestamp=timestamp,
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        return result.to_json_dict()

    def agent_exchange_accepted_blocker_candidate_consume(
        self,
        *,
        disposition_artifact_id: str,
        disposition_version: str,
        snapshot_path: str,
        task_id: str,
        reason: str,
        artifact_store_path: str = "",
        event_log_path: str = "",
        actor: str = "mcp",
        timestamp: str = "",
    ) -> dict[str, Any]:
        """Consume accepted blocker candidate disposition via explicit task blocking."""

        if not disposition_artifact_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedBlockerCandidateConsume requires dispositionArtifactId.",
            }
        if not disposition_version:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedBlockerCandidateConsume requires dispositionVersion.",
            }
        if not snapshot_path:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedBlockerCandidateConsume requires snapshotPath.",
            }
        if not task_id:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedBlockerCandidateConsume requires taskId.",
            }
        if not reason:
            return {
                "ok": False,
                "error": "agentExchangeAcceptedBlockerCandidateConsume requires reason.",
            }

        from ..runtime.orchestration import (
            consume_accepted_blocker_action_candidate,
            default_exchange_artifact_store_path,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        try:
            result = consume_accepted_blocker_action_candidate(
                artifact_store_path=store,
                disposition_artifact_id=disposition_artifact_id,
                disposition_version=disposition_version,
                snapshot_path=resolve_path(snapshot_path),
                task_id=task_id,
                reason=reason,
                event_log_path=resolve_path(event_log_path) if event_log_path else None,
                actor=actor or "mcp",
                timestamp=timestamp,
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        return result.to_json_dict()

    def agent_exchange_reply(
        self,
        *,
        source_artifact_id: str,
        source_version: str,
        reply_artifact_id: str,
        producer: str,
        text: str = "",
        structured: dict[str, Any] | None = None,
        reply_version: str = "v1",
        artifact_store_path: str = "",
        kind: str = "message",
        intent: str = "inform",
        audience: tuple[str, ...] = (),
        created_at: str = "",
        replace_existing: bool = False,
    ) -> dict[str, Any]:
        """Create one reply ExchangeArtifact in the local store."""

        if not source_artifact_id:
            return {"ok": False, "error": "agentExchangeReply requires sourceArtifactId."}
        if not source_version:
            return {"ok": False, "error": "agentExchangeReply requires sourceVersion."}
        if not reply_artifact_id:
            return {"ok": False, "error": "agentExchangeReply requires replyArtifactId."}
        if not producer:
            return {"ok": False, "error": "agentExchangeReply requires producer."}
        if not text and not structured:
            return {"ok": False, "error": "agentExchangeReply requires text or structured."}

        from ..runtime.orchestration import (
            default_exchange_artifact_store_path,
            reply_to_exchange_artifact,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )

        result = reply_to_exchange_artifact(
            store_path=store,
            source_artifact_id=source_artifact_id,
            source_version=source_version,
            reply_artifact_id=reply_artifact_id,
            reply_version=reply_version,
            producer=producer,
            text=text,
            structured=structured or {},
            kind=kind,  # type: ignore[arg-type]
            intent=intent,  # type: ignore[arg-type]
            audience=audience,
            created_at=created_at,
            replace_existing=replace_existing,
        )
        return result.to_json_dict()

    def agent_exchange_transition(
        self,
        *,
        artifact_id: str,
        version: str,
        target_state: str,
        actor: str,
        artifact_store_path: str = "",
        reason: str = "",
        timestamp: str = "",
    ) -> dict[str, Any]:
        """Transition one exact ExchangeArtifact lifecycle state."""

        if not artifact_id:
            return {"ok": False, "error": "agentExchangeTransition requires artifactId."}
        if not version:
            return {"ok": False, "error": "agentExchangeTransition requires version."}
        if not target_state:
            return {"ok": False, "error": "agentExchangeTransition requires targetState."}
        if not actor:
            return {"ok": False, "error": "agentExchangeTransition requires actor."}

        from ..runtime.orchestration import (
            default_exchange_artifact_store_path,
            transition_exchange_artifact_lifecycle,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )
        try:
            result = transition_exchange_artifact_lifecycle(
                store_path=store,
                artifact_id=artifact_id,
                version=version,
                target_state=target_state,  # type: ignore[arg-type]
                actor=actor,
                reason=reason,
                timestamp=timestamp,
            )
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        return result.to_json_dict()

    def scheduler_storage_binding_artifact_publish(
        self,
        *,
        evidence_path: str,
        artifact_store_path: str = "",
        artifact_id: str = "",
        version: str = "v1",
        producer: str = "",
        audience: tuple[str, ...] = ("scheduler", "workspace-registration"),
        created_at: str = "",
        replace_existing: bool = False,
    ) -> dict[str, Any]:
        """Publish compact supervisor storage binding evidence to exchange."""

        if not evidence_path:
            return {
                "ok": False,
                "error": "schedulerStorageBindingArtifactPublish requires evidencePath.",
            }
        if not version:
            return {
                "ok": False,
                "error": "schedulerStorageBindingArtifactPublish requires version.",
            }

        from ..runtime.orchestration import (
            default_exchange_artifact_store_path,
            publish_supervisor_storage_binding_artifact_from_evidence,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        store = (
            resolve_path(artifact_store_path)
            if artifact_store_path
            else default_exchange_artifact_store_path(self._project_root)
        )

        result = publish_supervisor_storage_binding_artifact_from_evidence(
            evidence_path=resolve_path(evidence_path),
            artifact_store_path=store,
            artifact_id=artifact_id,
            version=version,
            producer=producer,
            audience=audience,
            created_at=created_at,
            replace_existing=replace_existing,
        )
        return result.to_json_dict()

    def scheduler_projection(
        self,
        *,
        snapshot_path: str,
        scheduler_event_log_path: str = "",
        merge_gate_event_log_path: str = "",
        output_path: str = "",
        trajectory_id: str = "",
        title: str = "",
        guide_context: str = "",
        source_graph_id: str = "",
        source_node_id: str = "",
    ) -> dict[str, Any]:
        """Write a scheduler-derived trajectory projection artifact."""

        if not snapshot_path:
            return {
                "ok": False,
                "error": "schedulerProjection requires snapshotPath.",
            }

        from ..runtime.orchestration import read_scheduler_state_snapshot
        from tools.progress_graph import (
            LocalWorkTrajectory,
            scheduler_work_trajectory_json_path,
            write_scheduler_work_trajectory_artifact,
        )

        def resolve_path(value: str) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        snapshot = resolve_path(snapshot_path)
        scheduler_log = resolve_path(scheduler_event_log_path) if scheduler_event_log_path else None
        merge_gate_log = resolve_path(merge_gate_event_log_path) if merge_gate_event_log_path else None
        target = resolve_path(output_path) if output_path else None

        try:
            state = read_scheduler_state_snapshot(snapshot)
            written = write_scheduler_work_trajectory_artifact(
                self._project_root,
                state,
                scheduler_event_log_path=scheduler_log,
                merge_gate_event_log_path=merge_gate_log,
                output_path=target,
                trajectory_id=trajectory_id or "local-work:scheduler-projection",
                title=title or "Scheduler Local Work Trajectory",
                guide_context=guide_context,
                source_graph_id=source_graph_id,
                source_node_id=source_node_id,
            )
            trajectory = LocalWorkTrajectory.from_json(written.read_text(encoding="utf-8"))
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "snapshot_path": str(snapshot),
                "scheduler_projection_path": str(
                    target if target is not None else scheduler_work_trajectory_json_path(self._project_root)
                ),
            }

        return {
            "ok": True,
            "snapshot_path": str(snapshot),
            "scheduler_event_log_path": "" if scheduler_log is None else str(scheduler_log),
            "merge_gate_event_log_path": "" if merge_gate_log is None else str(merge_gate_log),
            "scheduler_projection_path": str(written),
            "trajectory_id": trajectory.trajectory_id,
            "title": trajectory.title,
            "event_count": len(trajectory.events),
            "lane_count": len(trajectory.lanes),
            "relation_count": len(trajectory.relations),
            "metadata": dict(trajectory.metadata),
        }

    def scheduler_authorization_readback(
        self,
        *,
        snapshot_path: str,
        scheduler_event_log_path: str = "",
        strict: bool = True,
        workspace_root: str = "",
        scratch_root: str = ".dbc/scratch",
    ) -> dict[str, Any]:
        """Read scheduler lease/sandbox authorization diagnostics."""

        if not snapshot_path:
            return {
                "ok": False,
                "error": "schedulerAuthorizationReadback requires snapshotPath.",
            }

        from ..runtime.orchestration import inspect_scheduler_authorization_snapshot

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        snapshot = resolve_path(snapshot_path)
        event_log = resolve_path(scheduler_event_log_path) if scheduler_event_log_path else None
        try:
            readback = inspect_scheduler_authorization_snapshot(
                snapshot,
                scheduler_event_log_path=event_log,
                strict=strict,
                workspace_root=workspace_root or str(self._project_root),
                scratch_root=scratch_root or ".dbc/scratch",
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "snapshot_path": str(snapshot),
                "scheduler_event_log_path": "" if event_log is None else str(event_log),
                "authority_split": {
                    "scheduler_state_read": False,
                    "scheduler_event_log_read": event_log is not None,
                    "scheduler_state_mutated": False,
                    "scheduler_projection_refreshed": False,
                    "runtime_provider_executed": False,
                    "sandbox_metadata_evaluated": False,
                    "real_sandbox_provider_executed": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "local_work_trajectory_mutated": False,
                },
            }

        payload = readback.to_json_dict()
        payload["ok"] = True
        return payload

    def scheduler_cleanup_receipts(
        self,
        *,
        input_evidence_path: str,
        output_evidence_path: str = "",
        output_evidence_id: str = "",
        timestamp: str = "",
        git_executable: str = "git",
    ) -> dict[str, Any]:
        """Explicitly clean git-worktree sandboxes from durable receipt evidence."""

        if not input_evidence_path:
            return {
                "ok": False,
                "error": "schedulerCleanupReceipts requires inputEvidencePath.",
            }

        from ..runtime.orchestration import run_sandbox_allocation_cleanup_over_receipts

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        input_path = resolve_path(input_evidence_path)
        output_path = resolve_path(output_evidence_path) if output_evidence_path else None
        try:
            result = run_sandbox_allocation_cleanup_over_receipts(
                input_path,
                output_evidence_path=output_path,
                output_evidence_id=output_evidence_id,
                timestamp=timestamp,
                git_executable=git_executable or "git",
                metadata={"surface": "mcp:schedulerCleanupReceipts"},
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "input_evidence_path": str(input_path),
                "output_evidence_path": "" if output_path is None else str(output_path),
                "authority_split": {
                    "scheduler_state_read": False,
                    "scheduler_state_mutated": False,
                    "runtime_provider_executed": False,
                    "sandbox_provider_executed": False,
                    "cleanup_executed": False,
                    "evidence_written": False,
                    "local_work_trajectory_mutated": False,
                },
            }

        return result.to_json_dict()

    def scheduler_sandbox_receipt_workflow(
        self,
        *,
        mode: str,
        snapshot_path: str,
        event_log_path: str,
        workspace_root: str,
        git_worktree_sandbox_root: str,
        allocation_evidence_id: str,
        allocation_evidence_path: str = "",
        cleanup: bool = False,
        cleanup_evidence_id: str = "",
        cleanup_evidence_path: str = "",
        runtime_provider: str = "fake",
        max_runs: int | None = 1,
        max_ticks: int = 1,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
        timestamp: str = "",
        git_executable: str = "git",
    ) -> dict[str, Any]:
        """Run host sandbox receipt allocate/read/cleanup/read workflow."""

        normalized_mode = (mode or "").replace("_", "-")
        missing = [
            name
            for name, value in (
                ("mode", normalized_mode),
                ("snapshotPath", snapshot_path),
                ("eventLogPath", event_log_path),
                ("workspaceRoot", workspace_root),
                ("gitWorktreeSandboxRoot", git_worktree_sandbox_root),
                ("allocationEvidenceId", allocation_evidence_id),
            )
            if not value
        ]
        if missing:
            return {
                "ok": False,
                "error": "schedulerSandboxReceiptWorkflow requires " + ", ".join(missing) + ".",
            }
        if normalized_mode not in {"run-once", "daemon-loop"}:
            return {
                "ok": False,
                "error": "schedulerSandboxReceiptWorkflow mode must be run-once or daemon-loop.",
                "mode": mode,
            }
        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "error": (
                    "schedulerSandboxReceiptWorkflow currently supports only runtimeProvider='fake'; "
                    "real providers require host-owned injected runtime wiring."
                ),
                "runtime_provider": normalized_runtime_provider,
            }

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        snapshot = resolve_path(snapshot_path)
        event_log = resolve_path(event_log_path)
        source_repo = resolve_path(workspace_root)
        sandbox_root = resolve_path(git_worktree_sandbox_root)
        allocation_path = resolve_path(allocation_evidence_path) if allocation_evidence_path else None
        cleanup_path = resolve_path(cleanup_evidence_path) if cleanup_evidence_path else None

        from ..runtime.orchestration import (
            HostSchedulerDaemonLoopRequest,
            HostSchedulerRunRequest,
            RuntimeHostInvocation,
            RuntimeRegistryWiringConfig,
            SchedulerDaemonLoopStopPolicy,
        )
        from tools.progress_graph import (
            HostSandboxReceiptWorkflowRequest,
            run_host_sandbox_receipt_workflow,
        )

        runtime_config = RuntimeRegistryWiringConfig(
            providers=("fake",),
            timestamp=timestamp,
            host_invocation=RuntimeHostInvocation(
                surface="host-authorized-adapter",
                invocation_id=f"mcp:schedulerSandboxReceiptWorkflow:{normalized_mode}",
                requested_providers=("fake",),
                requested_by="mcp",
                reason="scheduler sandbox receipt workflow",
            ),
        )
        workflow_mode = "run_once" if normalized_mode == "run-once" else "daemon_loop"
        run_once_request = None
        daemon_loop_request = None
        if workflow_mode == "run_once":
            run_once_request = HostSchedulerRunRequest(
                snapshot_path=snapshot,
                event_log_path=event_log,
                runtime_config=runtime_config,
                max_runs=max_runs,
                workspace_root=str(source_repo),
                git_worktree_sandbox_root=sandbox_root,
                sandbox_allocation_evidence_id=allocation_evidence_id,
                sandbox_allocation_evidence_path=allocation_path,
                timestamp=timestamp,
            )
        else:
            daemon_loop_request = HostSchedulerDaemonLoopRequest(
                snapshot_path=snapshot,
                event_log_path=event_log,
                runtime_config=runtime_config,
                stop_policy=SchedulerDaemonLoopStopPolicy(
                    max_ticks=max_ticks,
                    max_runs_per_tick=max_runs_per_tick,
                    max_runtime_failures=max_runtime_failures,
                ),
                workspace_root=str(source_repo),
                git_worktree_sandbox_root=sandbox_root,
                sandbox_allocation_evidence_id=allocation_evidence_id,
                sandbox_allocation_evidence_path=allocation_path,
                timestamp=timestamp,
                metadata={"surface": "mcp:schedulerSandboxReceiptWorkflow"},
            )
        try:
            result = run_host_sandbox_receipt_workflow(
                HostSandboxReceiptWorkflowRequest(
                    project_root=self._project_root,
                    mode=workflow_mode,
                    run_once_request=run_once_request,
                    daemon_loop_request=daemon_loop_request,
                    cleanup=cleanup,
                    cleanup_evidence_id=cleanup_evidence_id,
                    cleanup_evidence_path=cleanup_path,
                    timestamp=timestamp,
                    git_executable=git_executable or "git",
                    cleanup_metadata={"surface": "mcp:schedulerSandboxReceiptWorkflow"},
                )
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "workflow_mode": workflow_mode,
                "snapshot_path": str(snapshot),
                "event_log_path": str(event_log),
                "authority_split": {
                    "scheduler_state_read": True,
                    "scheduler_state_mutated": False,
                    "runtime_provider_executed": False,
                    "sandbox_provider_executed": False,
                    "cleanup_requested": cleanup,
                    "cleanup_executed": False,
                    "local_work_trajectory_mutated": False,
                },
            }

        return result.to_json_dict()

    def scheduler_run_once_and_project(
        self,
        *,
        snapshot_path: str,
        event_log_path: str,
        merge_gate_event_log_path: str = "",
        output_path: str = "",
        max_runs: int | None = None,
        timestamp: str = "",
        runtime_provider: str = "fake",
        guide_context: str = "",
        source_graph_id: str = "",
        source_node_id: str = "",
    ) -> dict[str, Any]:
        """Run one persisted scheduler drain and refresh scheduler projection."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "error": (
                    "schedulerRunOnceAndProject currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "explicit host permission and adapter registry configuration."
                ),
                "runtime_provider": normalized_runtime_provider,
            }
        if not snapshot_path:
            return {
                "ok": False,
                "error": "schedulerRunOnceAndProject requires snapshotPath.",
                "runtime_provider": normalized_runtime_provider,
            }
        if not event_log_path:
            return {
                "ok": False,
                "error": "schedulerRunOnceAndProject requires eventLogPath.",
                "runtime_provider": normalized_runtime_provider,
            }

        from ..runtime.orchestration import (
            InMemoryArtifactVersionStore,
            RuntimeHostInvocation,
            RuntimeRegistryWiringConfig,
            SandboxProviderRegistry,
            SharedProcessSandboxProvider,
            build_runtime_registry_from_config,
        )
        from tools.progress_graph import (
            scheduler_work_trajectory_json_path,
            run_persisted_scheduler_once_and_refresh_projection,
        )

        def resolve_path(value: str) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        snapshot = resolve_path(snapshot_path)
        event_log = resolve_path(event_log_path)
        merge_gate_log = resolve_path(merge_gate_event_log_path) if merge_gate_event_log_path else None
        target = resolve_path(output_path) if output_path else None
        sandbox_registry = SandboxProviderRegistry()
        sandbox_registry.register(SharedProcessSandboxProvider())
        runtime_wiring = build_runtime_registry_from_config(
            RuntimeRegistryWiringConfig(
                providers=("fake",),
                timestamp=timestamp,
                host_invocation=RuntimeHostInvocation(
                    surface="mcp-scheduler-run-once",
                    invocation_id=f"schedulerRunOnceAndProject:{snapshot}",
                    requested_providers=("fake",),
                    requested_by="mcp",
                    reason="scheduler fake-runtime smoke path",
                ),
            ),
            artifact_store=InMemoryArtifactVersionStore(),
        )

        try:
            result = run_persisted_scheduler_once_and_refresh_projection(
                self._project_root,
                snapshot_path=snapshot,
                event_log_path=event_log,
                sandbox_registry=sandbox_registry,
                runtime_registry=runtime_wiring.registry,
                merge_gate_event_log_path=merge_gate_log,
                projection_output_path=target,
                max_runs=max_runs,
                timestamp=timestamp,
                guide_context=guide_context,
                source_graph_id=source_graph_id,
                source_node_id=source_node_id,
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "snapshot_path": str(snapshot),
                "event_log_path": str(event_log),
                "runtime_provider": normalized_runtime_provider,
                "scheduler_projection_path": str(
                    target if target is not None else scheduler_work_trajectory_json_path(self._project_root)
                ),
            }

        return {
            "ok": True,
            "snapshot_path": str(result.run.snapshot_path),
            "event_log_path": str(result.run.event_log_path),
            "runtime_provider": normalized_runtime_provider,
            "runtime_registry_providers": list(runtime_wiring.registered_providers),
            "scheduler_projection_path": str(result.projection_path),
            "state_written": result.run.state_written,
            "stop_reason": result.run.drain.stop_reason,
            "run_count": len(result.run.drain.preflight_results),
            "trajectory_id": result.projection.trajectory_id,
            "title": result.projection.title,
            "event_count": len(result.projection.events),
            "lane_count": len(result.projection.lanes),
            "relation_count": len(result.projection.relations),
            "metadata": dict(result.projection.metadata),
        }

    def scheduler_lifecycle_control(
        self,
        *,
        action: str,
        control_path: str,
        snapshot_path: str = "",
        event_log_path: str = "",
        daemon_id: str = "",
        run_id: str = "",
        timestamp: str = "",
        stale_after_seconds: int | None = None,
        now_epoch_seconds: int | None = None,
    ) -> dict[str, Any]:
        """Read or mutate scheduler daemon lifecycle control state."""

        if not action:
            return {
                "ok": False,
                "error": "schedulerLifecycleControl requires action.",
            }
        normalized_action = action.strip()
        if normalized_action not in {
            "inspect",
            "start",
            "heartbeat",
            "pause",
            "resume",
            "cancel",
            "shutdown",
            "mark_stale",
        }:
            return {
                "ok": False,
                "error": (
                    "schedulerLifecycleControl action must be one of: "
                    "inspect, start, heartbeat, pause, resume, cancel, shutdown, mark_stale."
                ),
                "action": normalized_action,
            }
        if not control_path:
            return {
                "ok": False,
                "error": "schedulerLifecycleControl requires controlPath.",
                "action": normalized_action,
            }
        if normalized_action == "start":
            missing = [
                name
                for name, value in (
                    ("snapshotPath", snapshot_path),
                    ("eventLogPath", event_log_path),
                    ("daemonId", daemon_id),
                )
                if not value
            ]
            if missing:
                return {
                    "ok": False,
                    "error": (
                        "schedulerLifecycleControl start requires "
                        + ", ".join(missing)
                        + "."
                    ),
                    "action": normalized_action,
                }

        from ..runtime.orchestration import (
            SchedulerDaemonLifecycleRequest,
            apply_scheduler_daemon_lifecycle_action,
            inspect_scheduler_daemon_lifecycle_control,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        control = resolve_path(control_path)
        try:
            if normalized_action == "inspect":
                result = inspect_scheduler_daemon_lifecycle_control(
                    control,
                    now_epoch_seconds=now_epoch_seconds,
                    stale_after_seconds=stale_after_seconds,
                )
            else:
                result = apply_scheduler_daemon_lifecycle_action(
                    SchedulerDaemonLifecycleRequest(
                        control_path=control,
                        action=normalized_action,  # type: ignore[arg-type]
                        daemon_id=daemon_id,
                        snapshot_path=resolve_path(snapshot_path) if snapshot_path else None,
                        event_log_path=resolve_path(event_log_path) if event_log_path else None,
                        run_id=run_id,
                        timestamp=timestamp,
                        stale_after_seconds=stale_after_seconds,
                        now_epoch_seconds=now_epoch_seconds,
                    )
                )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "action": normalized_action,
                "control_path": str(control),
                "authority_split": {
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }

        return result.to_json_dict()

    def scheduler_lifecycle_run_once(
        self,
        *,
        control_path: str,
        runtime_provider: str = "fake",
        timestamp: str = "",
        max_ticks: int = 1,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
    ) -> dict[str, Any]:
        """Run one lifecycle-gated bounded scheduler loop."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "error": (
                    "schedulerLifecycleRunOnce currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "explicit host permission and adapter registry configuration."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }
        if not control_path:
            return {
                "ok": False,
                "error": "schedulerLifecycleRunOnce requires controlPath.",
                "runtime_provider": normalized_runtime_provider,
            }

        from ..runtime.orchestration import (
            SchedulerDaemonLifecycleRunOnceRequest,
            SchedulerDaemonLoopStopPolicy,
            run_scheduler_daemon_lifecycle_once,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        control = resolve_path(control_path)
        try:
            result = run_scheduler_daemon_lifecycle_once(
                SchedulerDaemonLifecycleRunOnceRequest(
                    control_path=control,
                    stop_policy=SchedulerDaemonLoopStopPolicy(
                        max_ticks=max_ticks,
                        max_runs_per_tick=max_runs_per_tick,
                        max_runtime_failures=max_runtime_failures,
                    ),
                    runtime_provider=normalized_runtime_provider,
                    timestamp=timestamp,
                    workspace_root=str(self._project_root),
                )
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "control_path": str(control),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }

        payload = result.to_json_dict()
        payload["runtime_provider"] = normalized_runtime_provider
        return payload

    def scheduler_lifecycle_harness(
        self,
        *,
        control_path: str,
        runtime_provider: str = "fake",
        timestamp: str = "",
        max_cycles: int = 1,
        max_loop_failures: int | None = 1,
        max_ticks: int = 1,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
        stale_after_seconds: int | None = None,
        now_epoch_seconds: int | None = None,
        policy_cancelled: bool = False,
        deadline_epoch_seconds: int | None = None,
        max_attempts: int = 1,
        retry_stop_reasons: list[str] | tuple[str, ...] | None = None,
    ) -> dict[str, Any]:
        """Run the policy-controlled bounded scheduler lifecycle harness."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "error": (
                    "schedulerLifecycleHarness currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "explicit host permission and adapter registry configuration."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "policy_authority": "host-owned-harness-policy",
                    "harness_authority": "host-owned-bounded-process-harness",
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }
        if not control_path:
            return {
                "ok": False,
                "error": "schedulerLifecycleHarness requires controlPath.",
                "runtime_provider": normalized_runtime_provider,
            }

        from ..runtime.orchestration import (
            SchedulerDaemonHarnessPolicy,
            SchedulerDaemonHarnessRequest,
            SchedulerDaemonLoopStopPolicy,
            run_scheduler_daemon_harness_with_policy,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        control = resolve_path(control_path)
        try:
            result = run_scheduler_daemon_harness_with_policy(
                SchedulerDaemonHarnessRequest(
                    control_path=control,
                    max_cycles=max_cycles,
                    stop_policy=SchedulerDaemonLoopStopPolicy(
                        max_ticks=max_ticks,
                        max_runs_per_tick=max_runs_per_tick,
                        max_runtime_failures=max_runtime_failures,
                    ),
                    runtime_provider=normalized_runtime_provider,
                    timestamp=timestamp,
                    workspace_root=str(self._project_root),
                    stale_now_epoch_seconds=now_epoch_seconds,
                    stale_after_seconds=stale_after_seconds,
                    max_loop_failures=max_loop_failures,
                ),
                SchedulerDaemonHarnessPolicy(
                    cancelled=policy_cancelled,
                    deadline_epoch_seconds=deadline_epoch_seconds,
                    now_epoch_seconds=now_epoch_seconds,
                    max_attempts=max_attempts,
                    retry_stop_reasons=tuple(retry_stop_reasons or ()),
                ),
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "control_path": str(control),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "policy_authority": "host-owned-harness-policy",
                    "harness_authority": "host-owned-bounded-process-harness",
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }

        payload = result.to_json_dict()
        payload["runtime_provider"] = normalized_runtime_provider
        return payload

    def scheduler_daemon_supervisor_step(
        self,
        *,
        supervisor_id: str,
        control_path: str,
        runtime_provider: str = "fake",
        timestamp: str = "",
        session_id: str = "",
        run_id: str = "",
        host_id: str = "",
        requested_by: str = "",
        status_readback_at: str = "",
        cancellation_source: str = "",
        cancellation_reason: str = "",
        max_cycles: int = 1,
        max_loop_failures: int | None = 1,
        max_ticks: int = 1,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
        stale_after_seconds: int | None = None,
        now_epoch_seconds: int | None = None,
        policy_cancelled: bool = False,
        deadline_epoch_seconds: int | None = None,
        max_attempts: int = 1,
        retry_stop_reasons: list[str] | tuple[str, ...] | None = None,
    ) -> dict[str, Any]:
        """Run one host-managed daemon supervisor step."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "error": (
                    "schedulerDaemonSupervisorStep currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "explicit host permission and adapter registry configuration."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "supervisor_authority": "host-owned-daemon-supervisor-contract",
                    "policy_authority": "host-owned-harness-policy",
                    "harness_authority": "host-owned-bounded-process-harness",
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }
        if not supervisor_id:
            return {
                "ok": False,
                "error": "schedulerDaemonSupervisorStep requires supervisorId.",
                "runtime_provider": normalized_runtime_provider,
            }
        if not control_path:
            return {
                "ok": False,
                "error": "schedulerDaemonSupervisorStep requires controlPath.",
                "runtime_provider": normalized_runtime_provider,
            }

        from ..runtime.orchestration import (
            SchedulerDaemonHarnessPolicy,
            SchedulerDaemonHarnessRequest,
            SchedulerDaemonLoopStopPolicy,
            SchedulerDaemonSupervisorRequest,
            run_scheduler_daemon_supervisor_step,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        control = resolve_path(control_path)
        try:
            result = run_scheduler_daemon_supervisor_step(
                SchedulerDaemonSupervisorRequest(
                    supervisor_id=supervisor_id,
                    session_id=session_id,
                    run_id=run_id,
                    host_id=host_id,
                    requested_by=requested_by,
                    status_readback_at=status_readback_at,
                    cancellation_source=cancellation_source,
                    cancellation_reason=cancellation_reason,
                    harness_request=SchedulerDaemonHarnessRequest(
                        control_path=control,
                        max_cycles=max_cycles,
                        stop_policy=SchedulerDaemonLoopStopPolicy(
                            max_ticks=max_ticks,
                            max_runs_per_tick=max_runs_per_tick,
                            max_runtime_failures=max_runtime_failures,
                        ),
                        runtime_provider=normalized_runtime_provider,
                        timestamp=timestamp,
                        workspace_root=str(self._project_root),
                        stale_now_epoch_seconds=now_epoch_seconds,
                        stale_after_seconds=stale_after_seconds,
                        max_loop_failures=max_loop_failures,
                    ),
                    policy=SchedulerDaemonHarnessPolicy(
                        cancelled=policy_cancelled,
                        deadline_epoch_seconds=deadline_epoch_seconds,
                        now_epoch_seconds=now_epoch_seconds,
                        max_attempts=max_attempts,
                        retry_stop_reasons=tuple(retry_stop_reasons or ()),
                    ),
                )
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc),
                "control_path": str(control),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "supervisor_authority": "host-owned-daemon-supervisor-contract",
                    "policy_authority": "host-owned-harness-policy",
                    "harness_authority": "host-owned-bounded-process-harness",
                    "lifecycle_authority": "scheduler_daemon_lifecycle_control_file",
                    "lifecycle_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "exchange_artifact_store_mutated": False,
                    "admission_ledger_mutated": False,
                },
            }

        payload = result.to_json_dict()
        payload["runtime_provider"] = normalized_runtime_provider
        return payload

    def scheduler_supervisor_dogfood_workflow(
        self,
        *,
        fixture: str = "simple",
        artifact_id: str = "",
        version: str = "",
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        snapshot_path: str = "",
        event_log_path: str = "",
        control_path: str = "",
        runtime_provider: str = "fake",
        max_cycles: int = 1,
        max_loop_failures: int | None = 1,
        max_ticks: int = 3,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
        max_attempts: int = 1,
        retry_stop_reasons: list[str] | tuple[str, ...] | None = None,
        allow_duplicate_admission: bool = False,
        replace_existing: bool = False,
        actor: str = "mcp",
        timestamp: str = "",
        created_at: str = "",
        daemon_id: str = "",
        lifecycle_run_id: str = "",
        supervisor_id: str = "",
        session_id: str = "",
        run_id: str = "",
        host_id: str = "",
        requested_by: str = "",
        status_readback_at: str = "",
    ) -> dict[str, Any]:
        """Run the deterministic fake-runtime supervisor dogfood workflow."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "error": (
                    "schedulerSupervisorDogfoodWorkflow currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "explicit host permission and adapter registry configuration."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "workflow_surface": "scheduler-supervisor-dogfood-workflow",
                    "fixture_seeded": False,
                    "exchange_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "lifecycle_control_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "supervisor_step_executed": False,
                    "scheduler_projection_refreshed": False,
                    "cleanup_executed": False,
                    "local_work_trajectory_mutated": False,
                },
            }
        if fixture not in {"simple", "multilane"}:
            return {
                "ok": False,
                "error": "schedulerSupervisorDogfoodWorkflow fixture must be simple or multilane.",
                "runtime_provider": normalized_runtime_provider,
            }

        from tools.progress_graph import (
            SchedulerSupervisorDogfoodWorkflowRequest,
            run_scheduler_supervisor_dogfood_workflow,
        )

        result = run_scheduler_supervisor_dogfood_workflow(
            SchedulerSupervisorDogfoodWorkflowRequest(
                project_root=self._project_root,
                fixture=fixture,  # type: ignore[arg-type]
                artifact_id=artifact_id,
                version=version,
                artifact_store_path=artifact_store_path or None,
                admission_ledger_path=admission_ledger_path or None,
                snapshot_path=snapshot_path or None,
                event_log_path=event_log_path or None,
                control_path=control_path or None,
                runtime_provider=normalized_runtime_provider,
                max_cycles=max_cycles,
                max_loop_failures=max_loop_failures,
                max_ticks=max_ticks,
                max_runs_per_tick=max_runs_per_tick,
                max_runtime_failures=max_runtime_failures,
                max_attempts=max_attempts,
                retry_stop_reasons=tuple(retry_stop_reasons or ()),
                allow_duplicate_admission=allow_duplicate_admission,
                replace_existing=replace_existing,
                actor=actor or "mcp",
                timestamp=timestamp,
                created_at=created_at,
                daemon_id=daemon_id or "daemon:supervisor-dogfood",
                lifecycle_run_id=lifecycle_run_id or "lifecycle-run:supervisor-dogfood",
                supervisor_id=supervisor_id or "supervisor:dogfood",
                session_id=session_id,
                run_id=run_id or "supervisor-run:dogfood",
                host_id=host_id,
                requested_by=requested_by,
                status_readback_at=status_readback_at,
            )
        )
        payload = result.to_json_dict()
        payload["runtime_provider"] = normalized_runtime_provider
        return payload

    def scheduler_operator_workflow(
        self,
        *,
        artifact_id: str = "",
        version: str = "",
        admit: bool = False,
        run_loop: bool = False,
        refresh_projection: bool = False,
        inspect_binding_refs: bool = False,
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        snapshot_path: str = "",
        event_log_path: str = "",
        merge_gate_event_log_path: str = "",
        projection_output_path: str = "",
        evidence_id: str = "",
        evidence_path: str = "",
        runtime_provider: str = "fake",
        max_ticks: int = 3,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
        allow_duplicate_admission: bool = False,
        replace_existing: bool = False,
        mark_consumed_on_success: bool = False,
        actor: str = "mcp",
        timestamp: str = "",
        guide_context: str = "",
        source_graph_id: str = "",
        source_node_id: str = "",
    ) -> dict[str, Any]:
        """Run the shared explicit scheduler operator workflow."""

        from tools.progress_graph import (
            SchedulerOperatorWorkflowRequest,
            run_scheduler_operator_workflow,
        )

        request = SchedulerOperatorWorkflowRequest(
            project_root=self._project_root,
            artifact_id=artifact_id,
            version=version,
            admit=admit,
            run_loop=run_loop,
            refresh_projection=refresh_projection,
            inspect_binding_refs=inspect_binding_refs,
            artifact_store_path=artifact_store_path or None,
            admission_ledger_path=admission_ledger_path or None,
            snapshot_path=snapshot_path or None,
            event_log_path=event_log_path or None,
            merge_gate_event_log_path=merge_gate_event_log_path or None,
            projection_output_path=projection_output_path or None,
            evidence_id=evidence_id,
            evidence_path=evidence_path or None,
            runtime_provider=runtime_provider or "fake",
            max_ticks=max_ticks,
            max_runs_per_tick=max_runs_per_tick,
            max_runtime_failures=max_runtime_failures,
            allow_duplicate_admission=allow_duplicate_admission,
            replace_existing=replace_existing,
            mark_consumed_on_success=mark_consumed_on_success,
            actor=actor or "mcp",
            timestamp=timestamp,
            guide_context=guide_context,
            source_graph_id=source_graph_id,
            source_node_id=source_node_id,
        )
        return run_scheduler_operator_workflow(request).to_json_dict()

    def scheduler_operator_dogfood_closure(
        self,
        *,
        fixture: str = "binding-consumer",
        artifact_id: str = "",
        version: str = "",
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        snapshot_path: str = "",
        event_log_path: str = "",
        merge_gate_event_log_path: str = "",
        projection_output_path: str = "",
        evidence_id: str = "",
        evidence_path: str = "",
        runtime_provider: str = "fake",
        max_ticks: int = 3,
        max_runs_per_tick: int | None = 1,
        max_runtime_failures: int | None = 1,
        replace_existing: bool = False,
        inspect_binding_refs: bool = True,
        mark_consumed_on_success: bool = True,
        actor: str = "mcp",
        timestamp: str = "",
        created_at: str = "",
        guide_context: str = "",
        source_graph_id: str = "",
        source_node_id: str = "",
    ) -> dict[str, Any]:
        """Run the deterministic fake-runtime operator dogfood closure."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "workflow_surface": "scheduler-operator-dogfood-closure",
                "error": (
                    "schedulerOperatorDogfoodClosure currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "a separate live-runtime planning gate."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "workflow_surface": "scheduler-operator-dogfood-closure",
                    "fixture_seeded": False,
                    "exchange_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "evidence_written": False,
                    "scheduler_projection_refreshed": False,
                    "host_evidence_read": False,
                    "starts_os_service": False,
                    "starts_background_process": False,
                    "uses_timers_or_watchers": False,
                    "cleanup_executed": False,
                    "agent_home_directory_created": False,
                    "scratch_directories_created": False,
                    "local_work_trajectory_mutated": False,
                },
            }
        if fixture not in {"binding-consumer", "simple", "multilane"}:
            return {
                "ok": False,
                "workflow_surface": "scheduler-operator-dogfood-closure",
                "error": (
                    "schedulerOperatorDogfoodClosure fixture must be "
                    "binding-consumer, simple, or multilane."
                ),
                "runtime_provider": normalized_runtime_provider,
            }

        from tools.progress_graph import (
            DEFAULT_OPERATOR_DOGFOOD_CLOSURE_EVIDENCE_ID,
            SchedulerOperatorDogfoodClosureRequest,
            run_scheduler_operator_dogfood_closure,
        )

        request = SchedulerOperatorDogfoodClosureRequest(
            project_root=self._project_root,
            fixture=fixture,  # type: ignore[arg-type]
            artifact_id=artifact_id,
            version=version,
            artifact_store_path=artifact_store_path or None,
            admission_ledger_path=admission_ledger_path or None,
            snapshot_path=snapshot_path or None,
            event_log_path=event_log_path or None,
            merge_gate_event_log_path=merge_gate_event_log_path or None,
            projection_output_path=projection_output_path or None,
            evidence_id=evidence_id or DEFAULT_OPERATOR_DOGFOOD_CLOSURE_EVIDENCE_ID,
            evidence_path=evidence_path or None,
            runtime_provider=normalized_runtime_provider,
            max_ticks=max_ticks,
            max_runs_per_tick=max_runs_per_tick,
            max_runtime_failures=max_runtime_failures,
            replace_existing=replace_existing,
            inspect_binding_refs=inspect_binding_refs,
            mark_consumed_on_success=mark_consumed_on_success,
            actor=actor or "mcp",
            timestamp=timestamp,
            created_at=created_at,
            guide_context=guide_context,
            source_graph_id=source_graph_id,
            source_node_id=source_node_id,
        )
        return run_scheduler_operator_dogfood_closure(request).to_json_dict()

    def scheduler_guide_worker_local_orchestration(
        self,
        *,
        artifact_store_path: str = "",
        admission_ledger_path: str = "",
        snapshot_path: str = "",
        event_log_path: str = "",
        trajectory_id: str = "local-work:current",
        guide_agent_id: str = "agent:guide",
        worker_agent_id: str = "agent:worker",
        artifact_id_prefix: str = "",
        worker_instructions: list[dict[str, Any]] | tuple[dict[str, Any], ...] | None = None,
        guide_task: dict[str, Any] | None = None,
        planner_lane_specs: list[dict[str, Any]] | tuple[dict[str, Any], ...] | None = None,
        max_parallel_lanes: int = 2,
        max_waves: int = 1,
        replace_existing: bool = False,
        allow_duplicate_admission: bool = False,
        timestamp: str = "",
        runtime_provider: str = "fake",
        workspace_root: str = "",
        scratch_root: str = ".dbc/scratch",
        wave_execution_mode: str = "serial",
    ) -> dict[str, Any]:
        """Run guide-worker local trajectory orchestration through MCP."""

        normalized_runtime_provider = (runtime_provider or "fake").strip().lower()
        if normalized_runtime_provider != "fake":
            return {
                "ok": False,
                "workflow_surface": "scheduler-guide-worker-local-orchestration",
                "error": (
                    "schedulerGuideWorkerLocalOrchestration currently supports "
                    "runtimeProvider='fake' only; requested "
                    f"{runtime_provider!r}. Real runtime providers require "
                    "a separate provider-parallel execution planning gate."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "workflow_surface": "scheduler-guide-worker-local-orchestration",
                    "exchange_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "true_process_parallelism": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "raw_transcript_persisted": False,
                },
            }

        from ..runtime.orchestration import (
            DEFAULT_EXCHANGE_ARTIFACT_ADMISSION_LEDGER_RELATIVE_PATH,
            DEFAULT_EXCHANGE_ARTIFACT_STORE_RELATIVE_PATH,
            DEFAULT_GUIDE_WORKER_LOCAL_ORCHESTRATION_EVENT_LOG_RELATIVE_PATH,
            DEFAULT_GUIDE_WORKER_LOCAL_ORCHESTRATION_PREFIX,
            DEFAULT_GUIDE_WORKER_LOCAL_ORCHESTRATION_SNAPSHOT_RELATIVE_PATH,
            GuideWorkerLocalOrchestrationRequest,
            GuideWorkerPlannerLaneSpec,
            GuideWorkerPlanningRequest,
            guide_worker_instructions_from_sequence,
            run_guide_worker_local_trajectory_orchestration,
        )

        def resolve_path(value: str | Path) -> Path:
            path = Path(value)
            if path.is_absolute():
                return path
            return self._project_root / path

        try:
            instructions = guide_worker_instructions_from_sequence(worker_instructions)
            planning_request = _guide_worker_planning_request_from_mcp(
                guide_task=guide_task,
                planner_lane_specs=planner_lane_specs,
                lane_spec_type=GuideWorkerPlannerLaneSpec,
                planning_request_type=GuideWorkerPlanningRequest,
            )
        except ValueError as exc:
            return {
                "ok": False,
                "workflow_surface": "scheduler-guide-worker-local-orchestration",
                "error": str(exc),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "workflow_surface": "scheduler-guide-worker-local-orchestration",
                    "exchange_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "true_process_parallelism": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "raw_transcript_persisted": False,
                },
            }
        live_worker_providers = {
            instruction.worker_runtime_provider
            for instruction in instructions
            if instruction.worker_runtime_provider
            and instruction.worker_runtime_provider != "fake"
        }
        if not instructions:
            live_worker_providers.update(
                lane_spec.worker_runtime_provider
                for lane_spec in planning_request.lane_specs
                if lane_spec.worker_runtime_provider
                and lane_spec.worker_runtime_provider != "fake"
            )
        live_worker_providers = sorted(live_worker_providers)
        if live_worker_providers:
            return {
                "ok": False,
                "workflow_surface": "scheduler-guide-worker-local-orchestration",
                "error": (
                    "schedulerGuideWorkerLocalOrchestration MCP accepts only "
                    "fake workerRuntimeProvider values; requested "
                    f"{', '.join(live_worker_providers)}. Use a host-authorized "
                    "runtime registry wrapper for provider-backed workers."
                ),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "workflow_surface": "scheduler-guide-worker-local-orchestration",
                    "exchange_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "true_process_parallelism": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "raw_transcript_persisted": False,
                },
            }

        try:
            normalized_wave_execution_mode = (wave_execution_mode or "serial").strip().lower()
            if normalized_wave_execution_mode not in {"serial", "threaded"}:
                raise ValueError(
                    "schedulerGuideWorkerLocalOrchestration waveExecutionMode "
                    "must be 'serial' or 'threaded'"
                )
            request = GuideWorkerLocalOrchestrationRequest(
                artifact_store_path=resolve_path(
                    artifact_store_path or DEFAULT_EXCHANGE_ARTIFACT_STORE_RELATIVE_PATH
                ),
                admission_ledger_path=resolve_path(
                    admission_ledger_path
                    or DEFAULT_EXCHANGE_ARTIFACT_ADMISSION_LEDGER_RELATIVE_PATH
                ),
                snapshot_path=resolve_path(
                    snapshot_path
                    or DEFAULT_GUIDE_WORKER_LOCAL_ORCHESTRATION_SNAPSHOT_RELATIVE_PATH
                ),
                event_log_path=resolve_path(
                    event_log_path
                    or DEFAULT_GUIDE_WORKER_LOCAL_ORCHESTRATION_EVENT_LOG_RELATIVE_PATH
                ),
                trajectory_id=trajectory_id or "local-work:current",
                guide_agent_id=guide_agent_id or "agent:guide",
                worker_agent_id=worker_agent_id or "agent:worker",
                artifact_id_prefix=(
                    artifact_id_prefix
                    or DEFAULT_GUIDE_WORKER_LOCAL_ORCHESTRATION_PREFIX
                ),
                timestamp=timestamp or "2026-06-24T00:00:00Z",
                planning_request=planning_request,
                worker_instructions=instructions,
                max_parallel_lanes=max_parallel_lanes,
                max_waves=max_waves,
                replace_existing=replace_existing,
                allow_duplicate_admission=allow_duplicate_admission,
                workspace_root=str(resolve_path(workspace_root)) if workspace_root else "",
                scratch_root=scratch_root or ".dbc/scratch",
                wave_execution_mode=normalized_wave_execution_mode,  # type: ignore[arg-type]
            )
            payload = run_guide_worker_local_trajectory_orchestration(request).to_json_dict()
        except ValueError as exc:
            return {
                "ok": False,
                "workflow_surface": "scheduler-guide-worker-local-orchestration",
                "error": str(exc),
                "runtime_provider": normalized_runtime_provider,
                "authority_split": {
                    "workflow_surface": "scheduler-guide-worker-local-orchestration",
                    "exchange_store_mutated": False,
                    "admission_ledger_mutated": False,
                    "scheduler_state_mutated": False,
                    "provider_executed": False,
                    "true_process_parallelism": False,
                    "scheduler_projection_refreshed": False,
                    "local_work_trajectory_mutated": False,
                    "raw_transcript_persisted": False,
                },
            }

        payload["workflow_surface"] = "scheduler-guide-worker-local-orchestration"
        payload["runtime_provider"] = normalized_runtime_provider
        return payload

    def governance_decide(self, input_text: str, scope_path: str = "", action_type: str = "") -> dict:
        """Run PDP → PEP governance chain on input text.

        Returns structured result with envelope, execution result,
        and constraint check.

        When *scope_path* is provided, pack resolution uses only the
        matching branch of the pack tree (hierarchical scope-aware mode).

        When *action_type* is provided, tool-level permission policies
        (from pack rules.tool_permissions) are evaluated first.

        MCP tool behavior:
        - Always returns a ``decision`` field: "ALLOW" or "BLOCK"
        - On BLOCK: includes ``constraint_violated`` and ``required_action``
        - On ALLOW: includes full envelope and execution result
        """
        # ── Hardcoded guard: remote git operations ──
        git_block = self._check_git_remote_guard(input_text)
        if git_block is not None:
            return git_block

        err = self._require_pipeline()
        if err is not None:
            return err

        # ── Tool permission policy check (B-REF-4) ──
        if action_type:
            from ..pdp.tool_permission_resolver import resolve as _resolve_perm
            rule_config = self._pipeline.rule_config
            perm_result = _resolve_perm(action_type, rule_config.tool_permissions)
            if perm_result.permission == "deny":
                return {
                    "decision": "BLOCK",
                    "reason": perm_result.deny_message or f"Action '{action_type}' denied by tool permission policy.",
                    "constraint_violated": ["TOOL_PERMISSION_DENY"],
                    "required_action": "This action type is not permitted in the current pack configuration.",
                    "policy_source": perm_result.policy_source,
                }

        # Pre-check constraints
        constraints = self._pipeline.check_constraints()
        if constraints.has_violations:
            blocking = [
                v for v in constraints.violations if v.severity == "block"
            ]
            return {
                "decision": "BLOCK",
                "reason": "; ".join(v.message for v in blocking),
                "constraint_violated": [v.constraint for v in blocking],
                "required_action": "Resolve blocking constraints before proceeding.",
                "constraints": constraints.to_dict(),
            }

        # Run governance chain (scoped or global)
        if scope_path:
            result = self._pipeline.process_scoped(input_text, scope_path)
        else:
            result = self._pipeline.process(input_text)
        # Slim pack_info summary (full details via get_pack_info tool)
        full_info = result.pack_info
        pack_info_summary: dict[str, Any] = {
            "packs": [
                {"name": p["name"], "version": p.get("version", ""), "kind": p.get("kind", "")}
                for p in full_info.get("packs", [])
            ],
            "merged_intents": full_info.get("merged_intents", []),
            "merged_gates": full_info.get("merged_gates", []),
        }
        # For scoped calls, include pack_tree resolution chain
        if "pack_tree" in full_info:
            pack_info_summary["pack_tree"] = full_info["pack_tree"]
        response: dict[str, Any] = {
            "decision": "ALLOW",
            "envelope": result.envelope,
            "execution": {
                k: v for k, v in result.execution.items() if k != "_rsm"
            },
            "intent": result.envelope.get("intent_result", {}).get("intent", "unknown"),
            "gate": result.envelope.get("gate_decision", {}).get("gate_level", "review"),
            "audit_event_count": len(result.audit_events),
            "pack_info": pack_info_summary,
            "decision_log_entry": result.decision_log_entry,
        }

        # Annotate with tool permission "ask" if applicable
        if action_type:
            from ..pdp.tool_permission_resolver import resolve as _resolve_perm
            rule_config = self._pipeline.rule_config
            perm_result = _resolve_perm(action_type, rule_config.tool_permissions)
            if perm_result.permission == "ask":
                response["tool_permission"] = {
                    "requires_confirmation": True,
                    "action_type": action_type,
                    "policy_source": perm_result.policy_source,
                }

        return response

    def check_constraints(self) -> dict:
        """Report project-level constraints and runtime enforcement coverage.

        Returns current constraint status, files to re-read for
        context recovery, project phase info, and which constraints are
        machine-checked versus still instruction-layer.
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        result = self._pipeline.check_constraints()
        return result.to_dict()

    def governance_override(self, action: str, **kwargs: Any) -> dict:
        """Register, revoke, or list temporary rule overrides.

        Actions:
          - ``register``: requires ``constraint``, ``reason``, optional ``scope``
          - ``revoke``: requires ``override_id``
          - ``list``: no extra args

        Non-overridable constraints (C4, C5, C8) are rejected.
        """
        if action == "list":
            try:
                active = get_active_overrides(self._project_root)
                return {
                    "overrides": [o.to_dict() for o in active],
                    "overridable_constraints": sorted(OVERRIDABLE_CONSTRAINTS),
                }
            except Exception as exc:
                return {"error": f"Failed to list overrides: {exc}"}

        if action == "register":
            constraint = kwargs.get("constraint", "")
            reason = kwargs.get("reason", "")
            scope = kwargs.get("scope", "session")
            if not constraint or not reason:
                return {"error": "register requires 'constraint' and 'reason'."}
            try:
                override = _save_override(
                    self._project_root,
                    constraint=constraint,
                    reason=reason,
                    scope=scope,
                )
                return {
                    "registered": True,
                    "override": override.to_dict(),
                }
            except OverrideError as exc:
                return {"error": str(exc), "registered": False}

        if action == "revoke":
            override_id = kwargs.get("override_id", "")
            if not override_id:
                return {"error": "revoke requires 'override_id'."}
            found = _revoke_override(self._project_root, override_id)
            return {
                "revoked": found,
                "override_id": override_id,
            }

        return {"error": f"Unknown action: {action!r}. Use 'register', 'revoke', or 'list'."}

    def query_decision_logs(
        self,
        trace_id: str = "",
        decision: str = "",
        intent: str = "",
        has_merge_conflicts: bool | None = None,
        limit: int = 50,
    ) -> dict:
        """Query persisted decision log entries.

        Supports filtering by trace_id, decision (ALLOW/BLOCK), intent,
        and whether merge conflicts were recorded.
        Returns the most recent entries first, up to *limit*.
        """
        from ..audit.decision_log import (
            DecisionLogStore,
            default_decision_log_dir,
            legacy_decision_log_dir,
        )

        query_kwargs = {
            "trace_id": trace_id or None,
            "decision": decision or None,
            "intent": intent or None,
            "has_merge_conflicts": has_merge_conflicts,
        }
        entries = DecisionLogStore(default_decision_log_dir(self._project_root)).query(
            **query_kwargs,
            limit=limit,
        )
        if len(entries) < limit:
            legacy_entries = DecisionLogStore(legacy_decision_log_dir(self._project_root)).query(
                **query_kwargs,
                limit=limit - len(entries),
            )
            entries.extend(legacy_entries)
        filters: dict = {
            k: v for k, v in
            {"trace_id": trace_id, "decision": decision, "intent": intent}.items()
            if v
        }
        if has_merge_conflicts is not None:
            filters["has_merge_conflicts"] = has_merge_conflicts
        return {
            "entries": entries,
            "count": len(entries),
            "filters": filters,
        }

    def workflow_interrupt(self, reason: str, discovered_item: str, current_scope_ref: str = "") -> dict:
        """Signal a workflow interrupt when an out-of-scope item is discovered.

        This primitive implements the project rule:
        "若发现新问题超出当前切片，先写回 planning-gate，而不是就地扩 scope"

        Returns structured guidance directing the agent to write the
        discovered item to a planning-gate document rather than expanding
        scope in-place.
        """
        import uuid
        from datetime import datetime, timezone

        interrupt_id = f"int-{uuid.uuid4().hex[:12]}"
        timestamp = datetime.now(timezone.utc).isoformat()

        # Generate a suggested filename based on the discovered item
        slug = discovered_item[:60].lower()
        slug = "".join(c if c.isalnum() or c in "-_ " else "" for c in slug)
        slug = slug.strip().replace(" ", "-").replace("_", "-")
        slug = "-".join(part for part in slug.split("-") if part)[:40]
        date_prefix = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        suggested_filename = f"design_docs/stages/planning-gate/{date_prefix}-{slug}.md"

        # Record to decision log if pipeline available
        decision_log_entry: dict[str, Any] | None = None
        if self._pipeline is not None:
            entry = {
                "interrupt_id": interrupt_id,
                "timestamp": timestamp,
                "type": "workflow_interrupt",
                "reason": reason,
                "discovered_item": discovered_item,
                "current_scope_ref": current_scope_ref or None,
                "suggested_redirect": suggested_filename,
            }
            try:
                from ..workflow.decision_log import record_entry
                record_entry(self._project_root, entry)
                decision_log_entry = entry
            except Exception:
                decision_log_entry = entry

        return {
            "status": "interrupted",
            "interrupt_id": interrupt_id,
            "timestamp": timestamp,
            "guidance": {
                "action": "write_to_planning_gate",
                "instruction": (
                    "You have signaled a scope interrupt. "
                    "Record the discovered item in a new planning-gate document. "
                    "Do NOT expand the current scope. "
                    "Resume current work only after the new planning-gate is addressed."
                ),
                "discovered_item": discovered_item,
                "reason": reason,
                "current_scope_ref": current_scope_ref or None,
                "suggested_filename": suggested_filename,
            },
            "decision_log_entry": decision_log_entry,
        }

    def get_next_action(self) -> dict:
        """Recommend the next action based on project state.

        Reads checkpoint and planning-gate documents to determine
        what should happen next. Used by MCP clients after context
        compression or restart to recover state.
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        constraints = self._pipeline.check_constraints()

        # Determine next action based on state
        active_planning_gate = constraints.active_planning_gate
        current_phase = constraints.current_phase
        state_source = constraints.state_source

        action: dict[str, Any] = {
            "files_to_reread": constraints.files_to_reread,
            "current_phase": current_phase,
            "active_planning_gate": active_planning_gate,
            "runtime_enforcement_summary": constraints.runtime_enforcement_summary,
            "state_source": state_source,
        }

        if constraints.has_violations:
            blocking = [
                v for v in constraints.violations if v.severity == "block"
            ]
            action["instruction"] = (
                f"BLOCKED: {blocking[0].message} "
                "Resolve this before proceeding."
            )
            action["ask_user"] = False
        elif active_planning_gate:
            action["instruction"] = (
                f"Continue working on the active planning gate: "
                f"{active_planning_gate}. "
                "Read the planning document and proceed with the current slice."
            )
            action["ask_user"] = False
        else:
            action["instruction"] = (
                "No active planning gate found. "
                "Read the Project Master Checklist and Global Phase Map to "
                "determine the next direction. Prepare a direction analysis "
                "document with candidates sourced from: "
                "(1) Checklist todos/risks, "
                "(2) docs/ unimplemented capabilities, "
                "(3) review/research-compass.md insights, "
                "(4) issues discovered during recent phases."
            )
            action["document_refs"] = [
                "design_docs/Project Master Checklist.md",
                "design_docs/Global Phase Map and Current Position.md",
                "review/research-compass.md",
            ]
            action["ask_user"] = True
            action["interaction_contract"] = self._interaction_contract()
            action["question_instruction"] = self._question_instruction()
            action["completion_boundary_reminder"] = (
                "CRITICAL: You are at a completion boundary. "
                "You MUST provide your own analysis of the next direction "
                "and end with a forward question that includes your recommendation. "
                "Do NOT ask the user whether to continue or stop."
            )

        return action

    def writeback_notify(self, phase_description: str) -> dict:
        """Notify that a phase/slice writeback has been completed.

        Returns recommendation for next steps. Used to drive
        automatic phase progression (C3).

        Args:
            phase_description: Description of what was just completed.
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        constraints = self._pipeline.check_constraints()

        # Scan for planning-gate documents that might indicate next steps
        gate_dir = self._project_root / "design_docs" / "stages" / "planning-gate"
        pending_gates: list[str] = []
        if gate_dir.is_dir():
            for f in sorted(gate_dir.iterdir()):
                if f.suffix == ".md" and f.name.lower() != "readme.md":
                    try:
                        head = f.read_text(encoding="utf-8")[:500]
                        # Parse Status line: look for "Status: **XXXX**"
                        status = _extract_gate_status(head)
                        if status in ("draft", "approved", "pending"):
                            pending_gates.append(f.name)
                    except OSError:
                        pass

        if not self._pipeline.is_dry_run:
            from ..workflow.checkpoint import sync_checkpoint_phase

            sync_checkpoint_phase(
                self._project_root,
                phase=phase_description,
                planning_gate="",
            )

        bundle = build_safe_stop_writeback_bundle(self._project_root)

        return {
            "phase_completed": phase_description,
            "auto_next": {
                "action": "prepare_direction_analysis" if not pending_gates else "execute_pending_gate",
                "pending_gates": pending_gates,
                "instruction": (
                    f"Phase '{phase_description}' completed. "
                    + (
                        f"Found {len(pending_gates)} pending planning gate(s): "
                        f"{', '.join(pending_gates)}. "
                        "Continue with the next pending gate."
                        if pending_gates
                        else
                        "No pending gates found. "
                        "Write back status to Checklist and Phase Map, then "
                        "prepare a direction analysis document for the next phase. "
                        "Use a forward question to confirm direction with the user."
                    )
                ),
                "files_to_update": [
                    *bundle["files_to_update"],
                ],
            },
            "ask_user": True,
            "interaction_contract": self._interaction_contract(),
            "question_instruction": self._question_instruction(),
            "safe_stop_writeback_bundle": bundle,
        }

    def get_info(self, scope_path: str = "", level: str = "manifest") -> dict:
        """Return loaded pack info with optional scope filtering and detail level."""
        err = self._require_pipeline()
        if err is not None:
            return err
        from ..pack.manifest_loader import LoadLevel
        level_map = {"metadata": LoadLevel.METADATA, "manifest": LoadLevel.MANIFEST, "full": LoadLevel.FULL}
        load_level = level_map.get(level.lower(), LoadLevel.MANIFEST)
        result = dict(self._pipeline.info(scope_path=scope_path, level=load_level))
        result["external_skill_interaction_contract"] = (
            self._external_skill_interaction_contract()
        )
        return result

    # ── Dependency Graph Tools ─────────────────────────────────────────

    def impact_analysis(
        self,
        changed_files: list[str] | None = None,
        changed_symbols: list[str] | None = None,
        max_depth: int = 2,
    ) -> dict:
        """Analyze change impact through the dependency graph.

        Uses the baseline graph snapshot to propagate changes and
        identify directly and transitively affected nodes.
        """
        graph_path = self._project_root / "tools" / "dependency_graph" / "baseline_graph.json"
        if not graph_path.exists():
            return {
                "error": "baseline_graph.json not found",
                "suggestion": (
                    "Dependency impact propagation is unavailable until this "
                    "workspace creates a reproducible dependency baseline. Use "
                    "the doc-loop dependency-baseline prompt or a project-specific "
                    "baseline generator; do not fabricate baseline_graph.json."
                ),
            }
        try:
            from tools.dependency_graph.query import query_impact

            graph_text = graph_path.read_text(encoding="utf-8")
            from tools.dependency_graph.model import DependencyGraph

            graph = DependencyGraph.from_json(graph_text)
            return query_impact(
                graph,
                changed_files=changed_files or [],
                changed_symbols=changed_symbols or [],
                max_depth=max_depth,
            )
        except Exception as exc:
            _log.error("impact_analysis failed: %s", exc)
            return {"error": str(exc)}

    def coupling_check(
        self,
        changed_files: list[str] | None = None,
        changed_symbols: list[str] | None = None,
    ) -> dict:
        """Check coupling annotations against changes.

        Uses coupling_annotations.json to find semantic coupling
        alerts triggered by the given changes.
        """
        coupling_path = (
            self._project_root / "tools" / "dependency_graph" / "coupling_annotations.json"
        )
        if not coupling_path.exists():
            return {"alerts": [], "note": "No coupling_annotations.json found."}
        try:
            from tools.dependency_graph.query import query_coupling

            alerts = query_coupling(
                coupling_path,
                changed_files=changed_files or [],
                changed_symbols=changed_symbols or [],
            )
            return {"alerts": alerts}
        except Exception as exc:
            _log.error("coupling_check failed: %s", exc)
            return {"error": str(exc)}

    def analyze_changes(
        self,
        changed_files: list[str] | None = None,
        changed_symbols: list[str] | None = None,
        max_depth: int = 2,
    ) -> dict:
        """Unified change analysis combining impact propagation and coupling checks.

        Merges the results of ``impact_analysis`` and ``coupling_check``
        into a single response so the caller only needs one tool call.
        """
        impact = self.impact_analysis(
            changed_files=changed_files,
            changed_symbols=changed_symbols,
            max_depth=max_depth,
        )
        coupling = self.coupling_check(
            changed_files=changed_files,
            changed_symbols=changed_symbols,
        )
        return {
            "impact": impact,
            "coupling": coupling,
        }

    # ── Dogfood pipeline ───────────────────────────────────────────────

    def promote_dogfood_evidence(
        self,
        symptoms: list[dict],
        existing_issue_ids: list[str] | None = None,
        date: str = "",
        judgment: str = "",
        next_step_implication: str = "",
        confidence: str = "medium",
        non_goals: list[str] | None = None,
        supersedes: str | None = None,
        auto_writeback: bool = False,
        active_gate_path: str | None = None,
    ) -> dict:
        """Run the full dogfood pipeline: evaluate → build → assemble → dispatch.

        Returns decisions, promoted issues, feedback packet, and consumer payloads.
        If *auto_writeback* is True, also writes consumer payloads to target documents.
        """
        try:
            from ..dogfood import run_full_pipeline

            result = run_full_pipeline(
                symptoms=symptoms,
                existing_issue_ids=existing_issue_ids,
                date=date,
                judgment=judgment,
                next_step_implication=next_step_implication,
                confidence=confidence,
                non_goals=tuple(non_goals) if non_goals else (),
                supersedes=supersedes,
            )

            if auto_writeback and result.get("consumer_payloads") and result.get("packet"):
                from ..dogfood.writeback import write_consumer_payloads

                wb_results = write_consumer_payloads(
                    project_root=self._project_root,
                    consumer_payloads=result["consumer_payloads"],
                    packet_id=result["packet"]["packet_id"],
                    active_gate_path=active_gate_path,
                    dry_run=self._dry_run,
                )
                result["writeback_results"] = wb_results

            return result
        except Exception as exc:
            _log.error("promote_dogfood_evidence failed: %s", exc)
            return {"error": str(exc)}

    # ── Pack Integrity ─────────────────────────────────────────────────

    def pack_lock(self, pack_name: str = "") -> dict:
        """Lock one or all packs by recording content hash in pack-lock.json."""
        from ..pack.pack_integrity import load_lock, save_lock, compute_pack_hash

        err = self._require_pipeline()
        if err is not None:
            return err

        lock = load_lock(self._project_root)
        pipeline = self._pipeline
        manifest_dir_pairs = [
            (m, d)
            for m, d in getattr(pipeline, "_manifest_dir_pairs", [])
        ]

        # Fallback: rediscover packs if _manifest_dir_pairs not available
        if not manifest_dir_pairs:
            from ..pack.pack_discovery import discover_packs
            discovered = discover_packs(self._project_root)
            from ..pack import manifest_loader
            for manifest_path, base_dir in discovered:
                try:
                    m = manifest_loader.load(manifest_path)
                    manifest_dir_pairs.append((m, base_dir))
                except Exception:
                    continue

        locked: list[dict] = []
        for manifest, base_dir in manifest_dir_pairs:
            if pack_name and manifest.name != pack_name:
                continue
            entry = lock.lock_pack(
                name=manifest.name,
                version=manifest.version,
                kind=manifest.kind,
                base_dir=base_dir,
            )
            locked.append(entry.to_dict())

        if pack_name and not locked:
            return {"error": f"Pack '{pack_name}' not found"}

        save_lock(self._project_root, lock)
        return {"locked": locked, "total_entries": len(lock.entries)}

    def pack_unlock(self, pack_name: str) -> dict:
        """Remove a pack from pack-lock.json."""
        from ..pack.pack_integrity import load_lock, save_lock

        lock = load_lock(self._project_root)
        if lock.unlock_pack(pack_name):
            save_lock(self._project_root, lock)
            return {"unlocked": pack_name, "total_entries": len(lock.entries)}
        return {"error": f"Pack '{pack_name}' not found in lock file"}

    def pack_verify(self, pack_name: str = "") -> dict:
        """Verify pack integrity against pack-lock.json."""
        from ..pack.pack_integrity import load_lock, verify_pack

        err = self._require_pipeline()
        if err is not None:
            return err

        lock = load_lock(self._project_root)
        if not lock.entries:
            return {"status": "no_lock", "message": "No pack-lock.json entries found"}

        pipeline = self._pipeline
        manifest_dir_pairs = getattr(pipeline, "_manifest_dir_pairs", [])

        if not manifest_dir_pairs:
            from ..pack.pack_discovery import discover_packs
            from ..pack import manifest_loader
            discovered = discover_packs(self._project_root)
            manifest_dir_pairs = []
            for manifest_path, base_dir in discovered:
                try:
                    m = manifest_loader.load(manifest_path)
                    manifest_dir_pairs.append((m, base_dir))
                except Exception:
                    continue

        results: list[dict] = []
        for manifest, base_dir in manifest_dir_pairs:
            if pack_name and manifest.name != pack_name:
                continue
            r = verify_pack(manifest.name, base_dir, lock)
            results.append({
                "name": r.name,
                "status": r.status,
                "expected_hash": r.expected_hash,
                "actual_hash": r.actual_hash,
                "detail": r.detail,
            })

        # Also check locked packs not present in discovered set
        discovered_names = {m.name for m, _ in manifest_dir_pairs}
        for entry_name, entry in lock.entries.items():
            if pack_name and entry_name != pack_name:
                continue
            if entry_name not in discovered_names:
                results.append({
                    "name": entry_name,
                    "status": "missing_pack",
                    "expected_hash": entry.content_hash,
                    "actual_hash": "",
                    "detail": "Locked pack not found in workspace",
                })

        if pack_name and not results:
            return {"error": f"Pack '{pack_name}' not found"}

        summary = {
            "ok": sum(1 for r in results if r["status"] == "ok"),
            "mismatch": sum(1 for r in results if r["status"] == "mismatch"),
            "missing_lock": sum(1 for r in results if r["status"] == "missing_lock"),
            "missing_pack": sum(1 for r in results if r["status"] == "missing_pack"),
        }
        return {"results": results, "summary": summary}

    # ── Prompts ────────────────────────────────────────────────────────

    def list_prompts(self) -> list[dict[str, str]] | dict:
        """Return prompt metadata from loaded packs.

        Each entry has ``name`` (slug) and ``description``.
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        results: list[dict[str, str]] = []
        ctx = self._pipeline.pack_context
        for manifest in ctx.manifests:
            base_dir = self._resolve_pack_base(manifest)
            for rel in getattr(manifest, "prompts", []) or []:
                path = base_dir / rel if base_dir else None
                name = Path(rel).stem
                # Read first non-heading line as description
                desc = f"Pack prompt from {manifest.name}: {rel}"
                if path and path.exists():
                    try:
                        lines = path.read_text(encoding="utf-8").splitlines()
                        for ln in lines:
                            stripped = ln.strip()
                            if stripped and not stripped.startswith("#"):
                                desc = stripped[:120]
                                break
                    except OSError:
                        pass
                results.append({"name": name, "description": desc})
        return results

    def get_prompt(self, name: str) -> str | None | dict:
        """Read a prompt file by slug name.

        Returns the file content as a string, or *None* if not found.
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        ctx = self._pipeline.pack_context
        for manifest in ctx.manifests:
            base_dir = self._resolve_pack_base(manifest)
            for rel in getattr(manifest, "prompts", []) or []:
                if Path(rel).stem == name:
                    path = base_dir / rel if base_dir else None
                    if path and path.exists():
                        try:
                            return path.read_text(encoding="utf-8")
                        except OSError:
                            return None
        return None

    # ── Resources ──────────────────────────────────────────────────────

    def list_resources(self) -> list[dict[str, str]] | dict:
        """Return resource metadata from loaded packs.

        Resources include *always_on* files (already in memory) and
        *on_demand* files (read on access).
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        results: list[dict[str, str]] = []
        ctx = self._pipeline.pack_context

        results.append({
            "uri": HOST_EVIDENCE_BUNDLE_RESOURCE_URI,
            "name": "host-evidence-bundle",
            "description": (
                "Read-only compact host scheduler evidence bundle. "
                "Does not execute providers or mutate scheduler/local trajectory artifacts."
            ),
            "mimeType": "application/json",
        })
        results.append({
            "uri": HOST_EVIDENCE_PRESENTATION_RESOURCE_URI,
            "name": "host-evidence-presentation",
            "description": (
                "Read-only host/UI/operator-facing presentation over host scheduler evidence. "
                "Does not execute providers or mutate scheduler/local trajectory artifacts."
            ),
            "mimeType": "application/json",
        })
        results.append({
            "uri": EXCHANGE_ARTIFACTS_BUNDLE_RESOURCE_URI,
            "name": "exchange-artifacts-bundle",
            "description": (
                "Read-only inspection bundle over the local ExchangeArtifact durable store. "
                "Reports exact versions and scheduler-admission candidates without submitting tasks."
            ),
            "mimeType": "application/json",
        })
        results.append({
            "uri": AGENT_EXCHANGE_HISTORY_RESOURCE_URI,
            "name": "agent-exchange-history",
            "description": (
                "Read-only compact communication history over ExchangeArtifact causality "
                "and log parts. Does not expose raw sensitive payload content or mutate state."
            ),
            "mimeType": "application/json",
        })
        results.append({
            "uri": AGENT_EXCHANGE_ACTION_CANDIDATES_RESOURCE_URI,
            "name": "agent-exchange-action-candidates",
            "description": (
                "Read-only action-candidate bridge over ExchangeArtifacts. "
                "Classifies scheduler, review, handoff, blocker, and merge candidates "
                "without mutating scheduler, review, handoff, exchange, or runtime state."
            ),
            "mimeType": "application/json",
        })

        # always_on — already loaded into memory
        for filename in sorted(ctx.always_on_content.keys()):
            uri = f"pack://always-on/{filename}"
            results.append({
                "uri": uri,
                "name": filename,
                "description": f"Always-on context file (pre-loaded)",
                "mimeType": "text/markdown",
            })

        # on_demand — declared but loaded lazily
        for manifest in ctx.manifests:
            for rel in getattr(manifest, "on_demand", []) or []:
                uri = f"pack://{manifest.name}/on-demand/{rel}"
                results.append({
                    "uri": uri,
                    "name": rel,
                    "description": f"On-demand resource from {manifest.name}",
                    "mimeType": self._guess_mime(rel),
                })

        return results

    def read_resource(self, uri: str) -> str | None | dict:
        """Read a resource by its pack:// URI.

        always_on resources come from memory; on_demand resources are
        lazily loaded via PackContext.load_on_demand().
        """
        err = self._require_pipeline()
        if err is not None:
            return err

        ctx = self._pipeline.pack_context

        if uri == HOST_EVIDENCE_BUNDLE_RESOURCE_URI:
            from tools.progress_graph import read_host_evidence_bundle

            bundle = read_host_evidence_bundle(self._project_root)
            return json.dumps(bundle.to_json_dict(), ensure_ascii=False, indent=2, sort_keys=True)

        if uri == HOST_EVIDENCE_PRESENTATION_RESOURCE_URI:
            from tools.progress_graph import (
                build_host_evidence_presentation,
                read_host_evidence_bundle,
            )

            bundle = read_host_evidence_bundle(self._project_root)
            presentation = build_host_evidence_presentation(bundle)
            return json.dumps(presentation.to_json_dict(), ensure_ascii=False, indent=2, sort_keys=True)

        if uri == EXCHANGE_ARTIFACTS_BUNDLE_RESOURCE_URI:
            from ..runtime.orchestration import (
                default_exchange_artifact_admission_ledger_path,
                default_exchange_artifact_store_path,
                inspect_exchange_artifact_store,
            )

            bundle = inspect_exchange_artifact_store(
                default_exchange_artifact_store_path(self._project_root),
                admission_ledger_path=default_exchange_artifact_admission_ledger_path(
                    self._project_root
                ),
            )
            return json.dumps(bundle.to_json_dict(), ensure_ascii=False, indent=2, sort_keys=True)

        if uri == AGENT_EXCHANGE_HISTORY_RESOURCE_URI:
            from ..runtime.orchestration import (
                default_exchange_artifact_store_path,
                inspect_agent_exchange_history_summary,
            )

            summary = inspect_agent_exchange_history_summary(
                default_exchange_artifact_store_path(self._project_root)
            )
            return json.dumps(summary.to_json_dict(), ensure_ascii=False, indent=2, sort_keys=True)

        if uri == AGENT_EXCHANGE_ACTION_CANDIDATES_RESOURCE_URI:
            from ..runtime.orchestration import (
                default_exchange_artifact_admission_ledger_path,
                default_exchange_artifact_store_path,
                inspect_agent_exchange_action_candidates,
            )

            summary = inspect_agent_exchange_action_candidates(
                default_exchange_artifact_store_path(self._project_root),
                admission_ledger_path=default_exchange_artifact_admission_ledger_path(
                    self._project_root
                ),
            )
            return json.dumps(summary.to_json_dict(), ensure_ascii=False, indent=2, sort_keys=True)

        # always_on — pack://always-on/{filename}
        if uri.startswith("pack://always-on/"):
            filename = uri[len("pack://always-on/"):]
            return ctx.always_on_content.get(filename)

        # on_demand — pack://{pack_name}/on-demand/{rel_path}
        for manifest in ctx.manifests:
            prefix = f"pack://{manifest.name}/on-demand/"
            if uri.startswith(prefix):
                rel = uri[len(prefix):]
                return ctx.load_on_demand(rel)
        return None

    # ── Helpers ────────────────────────────────────────────────────────

    def _resolve_pack_base(self, manifest: PackManifest) -> Path | None:
        """Find the base directory corresponding to a loaded manifest."""
        ctx = self._pipeline.pack_context
        # ContextBuilder stores (manifest, base_dir) during add_pack;
        # we need to find the base_dir from the pack_dirs used by Pipeline.
        # Convention: look in project root and common locations.
        for candidate in [
            self._project_root / manifest.name,
            self._project_root / ".codex" / "packs",
        ]:
            if candidate.is_dir():
                return candidate
        return self._project_root

    @staticmethod
    def _guess_mime(rel: str) -> str:
        ext = Path(rel).suffix.lower()
        return {
            ".md": "text/markdown",
            ".json": "application/json",
            ".py": "text/x-python",
            ".yaml": "text/yaml",
            ".yml": "text/yaml",
            ".txt": "text/plain",
        }.get(ext, "text/plain")


def _extract_gate_status(head: str) -> str:
    """Extract Status value from a planning gate document header.

    Looks for a line like ``- Status: **APPROVED**`` and returns
    the lowercased status string (e.g. "approved", "closed", "draft").
    Returns empty string if no status line found.
    """
    import re

    for line in head.splitlines():
        m = re.match(r"^-\s*Status:\s*\*{0,2}(\w[\w\s-]*\w?)\*{0,2}", line, re.IGNORECASE)
        if m:
            return m.group(1).strip().lower()
    return ""


def _readback_timeline_source_from_mapping(
    source: dict[str, Any],
    *,
    index: int,
):
    """Convert one MCP source mapping into a readback timeline source."""

    from ..runtime.orchestration import ReadbackTimelineSource

    if not isinstance(source, dict):
        raise ValueError(f"sources[{index}] must be an object")
    kind = _timeline_string_field(source, "kind")
    if not kind:
        raise ValueError(f"sources[{index}] requires kind")
    latest_limit_value = source.get("latestLimit", source.get("latest_limit", 20))
    try:
        latest_limit = int(latest_limit_value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"sources[{index}].latestLimit must be an integer") from exc
    return ReadbackTimelineSource(
        kind=kind,
        path=_timeline_string_field(source, "path"),
        artifact_id=_timeline_string_field(source, "artifactId", "artifact_id"),
        version=_timeline_string_field(source, "version"),
        source_kind=_timeline_string_field(source, "sourceKind", "source_kind"),
        latest_limit=latest_limit,
        actor=_timeline_string_field(source, "actor") or "readback-timeline-mcp",
        timestamp=_timeline_string_field(source, "timestamp"),
        label=_timeline_string_field(source, "label"),
    )


def _timeline_string_field(source: dict[str, Any], *names: str) -> str:
    for name in names:
        value = source.get(name)
        if value is not None:
            return str(value)
    return ""
