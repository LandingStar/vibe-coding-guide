"""MCP Server for doc-based-coding governance platform.

Exposes governance tools via the Model Context Protocol so that
compatible MCP clients such as Copilot, Codex, or other stdio-capable hosts
can inspect project constraint status and runtime-enforceable coverage for
the C1-C8 rule set.

Installed entry point:
    doc-based-coding-mcp --project /path/to/project

Module entry point:
    python -m src.mcp.server --project /path/to/project
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    EmbeddedResource,
    GetPromptResult,
    Prompt,
    PromptArgument,
    PromptMessage,
    Resource,
    TextContent,
    TextResourceContents,
    Tool,
)

from .tools import GovernanceTools


def _find_project_root() -> Path:
    """Walk up from CWD to find project root."""
    cwd = Path.cwd().resolve()
    for p in [cwd, *cwd.parents]:
        if (p / "design_docs").is_dir() or (p / ".codex").is_dir():
            return p
    return cwd


def create_server(project_root: Path, *, dry_run: bool = True) -> Server:
    """Create and configure the MCP server with governance tools."""
    server = Server("doc-based-coding-governance")
    tools = GovernanceTools(project_root, dry_run=dry_run)

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="governance_decide",
                description=(
                    "Run the full governance chain (PDP → PEP) on user input. "
                    "Returns BLOCK if project constraints are violated (e.g. no planning-gate), "
                    "or ALLOW with intent classification, gate level, and execution result. "
                    "MUST be called before starting any significant work."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "input_text": {
                            "type": "string",
                            "description": "The user's input text to classify and process through governance.",
                        },
                        "scope_path": {
                            "type": "string",
                            "description": (
                                "Optional file or directory path used to select the "
                                "matching pack-tree branch for scope-aware governance. "
                                "When omitted, global (unscoped) rules apply."
                            ),
                        },
                        "action_type": {
                            "type": "string",
                            "description": (
                                "Optional action type for tool-level permission check "
                                "(e.g. 'terminal_command', 'file_delete', 'git_push'). "
                                "When provided, pack-defined tool_permissions are evaluated "
                                "before the full PDP/PEP chain."
                            ),
                        },
                    },
                    "required": ["input_text"],
                },
            ),
            Tool(
                name="check_constraints",
                description=(
                    "Report project-level constraints (C1-C8), including which ones are "
                    "machine-checked versus still instruction-layer. Returns current violations, "
                    "files to re-read for context recovery, and project phase info. "
                    "Call this after context compression or at the start of a new client session."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            Tool(
                name="get_next_action",
                description=(
                    "Get the recommended next action based on current project state. "
                    "Returns instruction text, document references, and whether to ask the user. "
                    "Call this when unsure what to do next or after recovering from context compression."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            Tool(
                name="workspaceDbcCommand",
                description=(
                    "Per-agent workspace DBC command relay. Runs a doc-based-coding CLI argv "
                    "through the same package/Python instance that hosts this MCP server, with "
                    "the MCP project root as cwd, so agents do not resolve global PATH or venv "
                    "paths themselves. This is not a generic shell. Prefer dedicated structured "
                    "MCP tools when available; use this for CLI-equivalent diagnostics or operator "
                    "surfaces that do not have a dedicated MCP tool."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "argv": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "DBC CLI arguments without the executable name, for example "
                                "['doctor', '--profile', 'codex']."
                            ),
                        },
                        "mode": {
                            "type": "string",
                            "enum": ["read", "mutate"],
                            "description": (
                                "read allows read/diagnostic commands only. mutate is required "
                                "for DBC commands that may write project or scheduler state."
                            ),
                        },
                        "timeoutSeconds": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 300,
                            "description": "Bounded subprocess timeout. Default 30.",
                        },
                    },
                    "required": ["argv"],
                },
            ),
            Tool(
                name="readbackInspect",
                description=(
                    "Unified read-only readback inspection over existing records. "
                    "Supports worker-report, validation-receipt, runtime-invocation-log, "
                    "scheduler-event-log, exchange-artifact, and host-evidence. "
                    "This does not consume worker reports, run validation/doctor, "
                    "execute providers, launch browsers, capture screenshots, mutate "
                    "scheduler/exchange/evidence/config state, or mutate Local Work Trajectory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "kind": {
                            "type": "string",
                            "description": (
                                "Readback kind: worker-report, validation-receipt, "
                                "runtime-invocation-log, scheduler-event-log, "
                                "exchange-artifact, or host-evidence."
                            ),
                        },
                        "path": {
                            "type": "string",
                            "description": (
                                "Optional source file or directory path. Relative paths "
                                "resolve under the MCP project root. Required for most "
                                "file-backed kinds except host-evidence and exchange-artifact."
                            ),
                        },
                        "artifactId": {
                            "type": "string",
                            "description": "ExchangeArtifact id for kind=exchange-artifact.",
                        },
                        "version": {
                            "type": "string",
                            "description": (
                                "Optional ExchangeArtifact version. If omitted, latest "
                                "stored version is inspected."
                            ),
                        },
                        "sourceKind": {
                            "type": "string",
                            "description": (
                                "Optional validation source kind override: "
                                "self_check_report, self_check_result, or constraint_result."
                            ),
                        },
                        "latestLimit": {
                            "type": "integer",
                            "description": (
                                "Latest record limit for log-backed kinds. Default 20; "
                                "negative means all records."
                            ),
                        },
                        "actor": {
                            "type": "string",
                            "description": "Actor label recorded in readback envelopes.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional deterministic timestamp for readback envelopes.",
                        },
                    },
                    "required": ["kind"],
                },
            ),
            Tool(
                name="readbackTimelineInspect",
                description=(
                    "Read-only explicit-source readback timeline inspection. "
                    "Accepts caller-provided source specs, reuses existing readback "
                    "envelope inspection, and returns compact timeline rows with "
                    "ordering confidence. This does not scan the workspace, write "
                    "a persistent manifest, consume worker reports, run validation/"
                    "doctor, execute providers, launch browsers, capture screenshots, "
                    "mutate scheduler/exchange/evidence/config state, or mutate "
                    "Local Work Trajectory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "sources": {
                            "type": "array",
                            "description": (
                                "Explicit readback source specs. Each source supports "
                                "kind, path, artifactId, version, sourceKind, latestLimit, "
                                "actor, timestamp, and label."
                            ),
                            "items": {
                                "type": "object",
                                "properties": {
                                    "kind": {
                                        "type": "string",
                                        "description": (
                                            "Readback kind: worker-report, validation-receipt, "
                                            "runtime-invocation-log, scheduler-event-log, "
                                            "exchange-artifact, or host-evidence."
                                        ),
                                    },
                                    "path": {
                                        "type": "string",
                                        "description": (
                                            "Optional source file or directory path. Relative "
                                            "paths resolve under the MCP project root."
                                        ),
                                    },
                                    "artifactId": {
                                        "type": "string",
                                        "description": "ExchangeArtifact id for kind=exchange-artifact.",
                                    },
                                    "version": {
                                        "type": "string",
                                        "description": "Optional ExchangeArtifact version.",
                                    },
                                    "sourceKind": {
                                        "type": "string",
                                        "description": "Optional validation source kind override.",
                                    },
                                    "latestLimit": {
                                        "type": "integer",
                                        "description": "Latest record limit for log-backed kinds. Default 20.",
                                    },
                                    "actor": {
                                        "type": "string",
                                        "description": "Actor label recorded in readback envelopes.",
                                    },
                                    "timestamp": {
                                        "type": "string",
                                        "description": "Optional deterministic timestamp.",
                                    },
                                    "label": {
                                        "type": "string",
                                        "description": "Compact source label copied to timeline rows.",
                                    },
                                },
                                "required": ["kind"],
                            },
                        },
                    },
                    "required": ["sources"],
                },
            ),
            Tool(
                name="writeback_notify",
                description=(
                    "Notify that a phase or slice writeback has been completed. "
                    "Returns auto-progression recommendation with next steps. "
                    "MUST be called after completing a write-back to drive automatic phase progression."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "phase_description": {
                            "type": "string",
                            "description": "Description of the phase/slice that was just completed.",
                        },
                    },
                    "required": ["phase_description"],
                },
            ),
            Tool(
                name="get_pack_info",
                description=(
                    "Return information about loaded packs, merged intents, gates, and document types. "
                    "Use scope_path to filter by directory scope. Use level to control detail depth: "
                    "'metadata' (name/kind/provides/description only), "
                    "'manifest' (full capability sets, default), "
                    "'full' (manifest + always_on content summary)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "scope_path": {
                            "type": "string",
                            "description": (
                                "Optional file or directory path used to select the matching "
                                "pack-tree branch for scope-aware pack info."
                            ),
                        },
                        "level": {
                            "type": "string",
                            "description": (
                                "Detail level: 'metadata', 'manifest' (default), or 'full'."
                            ),
                            "enum": ["metadata", "manifest", "full"],
                        },
                    },
                },
            ),
            Tool(
                name="governance_override",
                description=(
                    "Register, revoke, or list temporary rule overrides. "
                    "Allows the model to record user-authorised, auditable, auto-expiring "
                    "exemptions from overridable constraints (C1, C2, C3, C6, C7). "
                    "Non-overridable constraints (C4, C5, C8) will be rejected."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["register", "revoke", "list"],
                            "description": "The override action to perform.",
                        },
                        "constraint": {
                            "type": "string",
                            "description": "Constraint identifier (e.g. 'C1'). Required for 'register'.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "User-authorised reason for the override. Required for 'register'.",
                        },
                        "scope": {
                            "type": "string",
                            "enum": ["turn", "session", "until-next-safe-stop"],
                            "description": "Override lifetime scope. Default: 'session'.",
                        },
                        "override_id": {
                            "type": "string",
                            "description": "Override ID to revoke. Required for 'revoke'.",
                        },
                    },
                    "required": ["action"],
                },
            ),
            Tool(
                name="query_decision_logs",
                description=(
                    "Query persisted decision log entries. "
                    "Supports filtering by trace_id, decision (ALLOW/BLOCK), intent, "
                    "and whether merge conflicts were recorded. "
                    "Returns the most recent entries first, up to the specified limit."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "trace_id": {
                            "type": "string",
                            "description": "Filter by trace ID.",
                        },
                        "decision": {
                            "type": "string",
                            "enum": ["ALLOW", "BLOCK"],
                            "description": "Filter by decision outcome.",
                        },
                        "intent": {
                            "type": "string",
                            "description": "Filter by intent classification.",
                        },
                        "has_merge_conflicts": {
                            "type": "boolean",
                            "description": "If true, only entries with merge conflicts; if false, only without.",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum entries to return. Default: 50.",
                        },
                    },
                },
            ),
            Tool(
                name="impact_analysis",
                description=(
                    "Analyze change impact through the dependency graph. "
                    "Given changed files or symbols, propagates through the baseline "
                    "dependency graph to identify directly and transitively affected nodes. "
                    "Use this when modifying a Protocol, class, or module to discover "
                    "what else may need updating."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "changed_files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of changed file paths.",
                        },
                        "changed_symbols": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of changed symbol/node IDs (e.g. 'src.interfaces.WorkerBackend').",
                        },
                        "max_depth": {
                            "type": "integer",
                            "description": "Maximum propagation depth. Default: 2.",
                        },
                    },
                },
            ),
            Tool(
                name="coupling_check",
                description=(
                    "Check coupling annotations against changes. "
                    "Matches changed files or symbols against explicit semantic coupling "
                    "declarations and returns alerts for locations that may need syncing. "
                    "Use this when you've changed a file and want to check if any "
                    "coupled documentation or companion files need updating."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "changed_files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of changed file paths.",
                        },
                        "changed_symbols": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of changed symbol names.",
                        },
                    },
                },
            ),
            Tool(
                name="analyze_changes",
                description=(
                    "Unified change analysis: combines dependency-graph impact "
                    "propagation with coupling annotation checks in a single call. "
                    "Given changed files or symbols, returns both the set of directly/"
                    "transitively affected nodes AND any coupling alerts that need "
                    "syncing. Prefer this over calling impact_analysis and "
                    "coupling_check separately."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "changed_files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of changed file paths.",
                        },
                        "changed_symbols": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of changed symbol/node IDs (e.g. 'src.interfaces.WorkerBackend').",
                        },
                        "max_depth": {
                            "type": "integer",
                            "description": "Maximum propagation depth. Default: 2.",
                        },
                    },
                },
            ),
            Tool(
                name="promote_dogfood_evidence",
                description=(
                    "Run the full dogfood evidence-to-feedback pipeline: "
                    "evaluate symptoms against promotion thresholds (T1-T4/S1-S3), "
                    "build issue candidates for promoted symptoms, assemble a feedback "
                    "packet, and dispatch consumer payloads per the boundary matrix. "
                    "Use when dogfood observations need structured triage and feedback routing."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "symptoms": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "symptom_id": {"type": "string"},
                                    "symptom_summary": {"type": "string"},
                                    "evidence_refs": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "path": {"type": "string"},
                                                "section": {"type": "string"},
                                                "summary": {"type": "string"},
                                            },
                                            "required": ["path"],
                                        },
                                    },
                                    "category": {"type": "string"},
                                    "affects_next_gate": {"type": "boolean"},
                                    "requires_next_slice": {"type": "boolean"},
                                    "occurrence_count": {"type": "integer"},
                                    "impact_layers": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                    "minimal_reproducer": {"type": "string"},
                                    "expected": {"type": "string"},
                                    "actual": {"type": "string"},
                                    "evidence_excerpt": {"type": "string"},
                                    "environment": {"type": "string"},
                                    "non_goals": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                },
                                "required": ["symptom_id", "symptom_summary"],
                            },
                            "description": "Symptom observations to evaluate for promotion.",
                        },
                        "existing_issue_ids": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Previously promoted issue IDs for de-duplication (S2 check).",
                        },
                        "date": {
                            "type": "string",
                            "description": "Date label in YYYY-MM-DD format for packet ID generation.",
                        },
                        "judgment": {
                            "type": "string",
                            "description": "Human/domain judgment summary for the feedback packet.",
                        },
                        "next_step_implication": {
                            "type": "string",
                            "description": "What the next planning step should consider.",
                        },
                        "confidence": {
                            "type": "string",
                            "enum": ["high", "medium", "low"],
                            "description": "Confidence level for the feedback packet. Default: medium.",
                        },
                        "non_goals": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "What this feedback explicitly does NOT address.",
                        },
                        "supersedes": {
                            "type": "string",
                            "description": "Packet ID this feedback replaces, if any.",
                        },
                        "auto_writeback": {
                            "type": "boolean",
                            "description": "If true, write consumer payloads to target documents. Default: false.",
                        },
                        "active_gate_path": {
                            "type": "string",
                            "description": "Relative path to the current active planning-gate file, for planning-gate consumer writeback.",
                        },
                    },
                    "required": ["symptoms"],
                },
            ),
            Tool(
                name="workflow_interrupt",
                description=(
                    "Signal a workflow interrupt when an out-of-scope item is discovered "
                    "during execution. Returns structured guidance directing the agent "
                    "to write the discovered item to a planning-gate document rather than "
                    "expanding scope in-place. Implements the rule: 'if a new problem "
                    "exceeds the current slice, write to planning-gate first.'"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "reason": {
                            "type": "string",
                            "description": "Why the interrupt is triggered (e.g. 'discovered new requirement beyond current scope').",
                        },
                        "discovered_item": {
                            "type": "string",
                            "description": "Description of the out-of-scope item found.",
                        },
                        "current_scope_ref": {
                            "type": "string",
                            "description": "Reference to the current planning-gate or phase doc (optional).",
                        },
                    },
                    "required": ["reason", "discovered_item"],
                },
            ),
            Tool(
                name="update_user_config",
                description=(
                    "Update a single field in the user-global config file "
                    "(~/.doc-based-coding/config.json). Returns the full config "
                    "after the update. Accepted fields: extra_pack_dirs, "
                    "default_model, default_llm_params."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "field": {
                            "type": "string",
                            "description": "The config field to update.",
                            "enum": ["extra_pack_dirs", "default_model", "default_llm_params"],
                        },
                        "value": {
                            "description": "The new value for the field.",
                        },
                    },
                    "required": ["field", "value"],
                },
            ),
            Tool(
                name="pack_lock",
                description=(
                    "Lock one or all packs by recording their content hash in "
                    "pack-lock.json. If no pack_name is given, locks all discovered packs."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pack_name": {
                            "type": "string",
                            "description": "Name of the pack to lock (optional — omit to lock all).",
                        },
                    },
                },
            ),
            Tool(
                name="pack_unlock",
                description=(
                    "Remove a pack from pack-lock.json. The pack will no longer "
                    "be verified on pipeline load."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pack_name": {
                            "type": "string",
                            "description": "Name of the pack to unlock.",
                        },
                    },
                    "required": ["pack_name"],
                },
            ),
            Tool(
                name="pack_verify",
                description=(
                    "Verify pack integrity against pack-lock.json. "
                    "Returns per-pack status (ok/mismatch/missing_lock/missing_pack)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pack_name": {
                            "type": "string",
                            "description": "Name of a specific pack to verify (optional — omit to verify all locked packs).",
                        },
                    },
                },
            ),
            Tool(
                name="check_reply_progression",
                description=(
                    "Check if an AI reply ending conforms to the conversation progression contract. "
                    "Detects forbidden patterns (pure yes/no, passive waiting) and verifies "
                    "presence of AI analysis + forward-driving question at the tail. "
                    "Call before sending a reply to ensure compliance."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "reply_text": {
                            "type": "string",
                            "description": "The full reply text to check for progression compliance.",
                        },
                    },
                    "required": ["reply_text"],
                },
            ),
            Tool(
                name="localTrajectory",
                description=(
                    "Agent-owned Local Work Trajectory mutation. Use start when beginning "
                    "a tracked task, append for planned or observed milestones, and advance "
                    "when the active milestone is complete. Use update to refine the current "
                    "milestone, block/wait for impediments, resume to continue, and close "
                    "when the single-line task is done. Use addLane to create one extra "
                    "lane with its first event. Use addLanes when one decision expands "
                    "several distinct lanes at once; this preserves a shared opening "
                    "source so the UI can render a merged fanout instead of overlapping "
                    "start-line edges. "
                    "Use addCompound to create a planned compound/phase event with its own "
                    "child trajectory; this does not pack or move existing events. "
                    "Use packRange to replace a continuous same-lane event interval with "
                    "a compound event and preserve the interval in its child trajectory. "
                    "Use packSubgraph to pack multiple lane-local continuous ranges into "
                    "one compound child trajectory with anchor/proxy parent projection. "
                    "Use appendChild, advanceChild, and closeChild to mutate the child "
                    "trajectory of an existing compound parent. "
                    "Use merge to add an explicit target-lane merge event and a merges_into "
                    "relation from a source lane event. "
                    "Use relate to record an explicit dependency, wait, unblock, handoff, "
                    "sync, or approval relation between existing events; relate is metadata "
                    "only and does not schedule work or resolve conflicts. "
                    "When starting a trajectory, pass sourceGraphId and sourceNodeId if the "
                    "owning global progress-map node is known, so the trajectory is visible "
                    "from birth. Use setAnchor later to move the current trajectory under a "
                    "specific global progress-map node; pass both sourceGraphId and "
                    "sourceNodeId, or pass neither to clear the anchor. "
                    "After validation or delivery completes, keep advancing until completed "
                    "milestones are not left pending or in_progress. This writes only the "
                    "local trajectory metadata artifact, not source files. Direct mutation is "
                    "leader/main/supervisor authority; bounded workers/subagents must report "
                    "trajectory changes through Subagent Report.trajectory_update; see "
                    "docs/worker-trajectory-update-reporting.md for the worker report path."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "start",
                                "append",
                                "advance",
                                "update",
                                "block",
                                "wait",
                                "resume",
                                "close",
                                "addLane",
                                "addLanes",
                                "addCompound",
                                "packRange",
                                "packSubgraph",
                                "appendChild",
                                "advanceChild",
                                "closeChild",
                                "merge",
                                "relate",
                                "setAnchor",
                            ],
                            "description": "Lifecycle action to perform.",
                        },
                        "laneLabel": {
                            "type": "string",
                            "description": "Short lane label for start.",
                        },
                        "firstEventTitle": {
                            "type": "string",
                            "description": "First active event title for start.",
                        },
                        "title": {
                            "type": "string",
                            "description": "Trajectory title for start or event title for append.",
                        },
                        "eventKind": {
                            "type": "string",
                            "enum": [
                                "start",
                                "task",
                                "decision",
                                "review",
                                "wait",
                                "validation",
                                "writeback",
                                "handoff",
                                "compound",
                                "merge",
                                "close",
                            ],
                            "description": "Event kind for start or append.",
                        },
                        "summary": {
                            "type": "string",
                            "description": "Optional summary for append/update/resume/close.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "Block or wait reason for block/wait.",
                        },
                        "guideContext": {
                            "type": "string",
                            "description": "Agent or document context responsible for this local trajectory.",
                        },
                        "currentEventId": {
                            "type": "string",
                            "description": "Optional active event id to advance.",
                        },
                        "laneId": {
                            "type": "string",
                            "description": "Optional lane id for addLane or append.",
                        },
                        "lanes": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "laneLabel": {"type": "string"},
                                    "lane_label": {"type": "string"},
                                    "firstEventTitle": {"type": "string"},
                                    "first_event_title": {"type": "string"},
                                    "eventKind": {"type": "string"},
                                    "event_kind": {"type": "string"},
                                    "summary": {"type": "string"},
                                    "laneId": {"type": "string"},
                                    "lane_id": {"type": "string"},
                                },
                            },
                            "description": "Lane specs for addLanes. Use when one source event opens multiple work contexts at once.",
                        },
                        "sourceEventId": {
                            "type": "string",
                            "description": "Optional event id that caused addLane, source event for merge/relate, or range start alias for packRange.",
                        },
                        "sourceLaneId": {
                            "type": "string",
                            "description": "Source lane id for merge.",
                        },
                        "targetLaneId": {
                            "type": "string",
                            "description": "Target lane id for merge. Defaults to lane:main.",
                        },
                        "targetEventId": {
                            "type": "string",
                            "description": "Optional target lane event id for merge, target event for relate, or range end alias for packRange.",
                        },
                        "relationKind": {
                            "type": "string",
                            "enum": [
                                "depends_on",
                                "waits_for",
                                "unblocks",
                                "hands_off",
                                "syncs_from",
                                "merges_into",
                                "proposes_new_line",
                                "approves_new_line",
                            ],
                            "description": "Relation kind for relate.",
                        },
                        "firstChildEventTitle": {
                            "type": "string",
                            "description": "Optional first active child event title for addCompound.",
                        },
                        "childLaneLabel": {
                            "type": "string",
                            "description": "Optional child trajectory lane label for addCompound or packRange.",
                        },
                        "parentEventId": {
                            "type": "string",
                            "description": "Compound parent event id for appendChild, advanceChild, or closeChild.",
                        },
                        "childTrajectoryId": {
                            "type": "string",
                            "description": "Child trajectory id for appendChild, advanceChild, or closeChild.",
                        },
                        "rangeStartEventId": {
                            "type": "string",
                            "description": "First event id in the same-lane continuous interval for packRange.",
                        },
                        "rangeEndEventId": {
                            "type": "string",
                            "description": "Last event id in the same-lane continuous interval for packRange.",
                        },
                        "packRanges": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "lane_id": {"type": "string"},
                                    "laneId": {"type": "string"},
                                    "range_start_event_id": {"type": "string"},
                                    "rangeStartEventId": {"type": "string"},
                                    "range_end_event_id": {"type": "string"},
                                    "rangeEndEventId": {"type": "string"},
                                },
                            },
                            "description": "Lane-local continuous ranges for packSubgraph.",
                        },
                        "anchorLaneId": {
                            "type": "string",
                            "description": "Selected anchor lane id for packSubgraph. Defaults to laneId or the first selected range lane.",
                        },
                        "sourceEndpointTrajectoryId": {
                            "type": "string",
                            "description": "Precise source endpoint trajectory id for cross-compound relate.",
                        },
                        "sourceEndpointEventId": {
                            "type": "string",
                            "description": "Precise source endpoint event id for cross-compound relate.",
                        },
                        "sourceEndpointParentEventId": {
                            "type": "string",
                            "description": "Immediate source compound parent event id for cross-compound relate.",
                        },
                        "sourceEndpointCompoundPath": {
                            "type": "string",
                            "description": "Slash-separated source compound path for cross-compound relate.",
                        },
                        "targetEndpointTrajectoryId": {
                            "type": "string",
                            "description": "Precise target endpoint trajectory id for cross-compound relate.",
                        },
                        "targetEndpointEventId": {
                            "type": "string",
                            "description": "Precise target endpoint event id for cross-compound relate.",
                        },
                        "targetEndpointParentEventId": {
                            "type": "string",
                            "description": "Immediate target compound parent event id for cross-compound relate.",
                        },
                        "targetEndpointCompoundPath": {
                            "type": "string",
                            "description": "Slash-separated target compound path for cross-compound relate.",
                        },
                        "sourceGraphId": {
                            "type": "string",
                            "description": "Global progress graph id for start or setAnchor. Provide with sourceNodeId, or omit both to start unanchored / clear the anchor.",
                        },
                        "sourceNodeId": {
                            "type": "string",
                            "description": "Global progress graph node id for start or setAnchor. Provide with sourceGraphId, or omit both to start unanchored / clear the anchor.",
                        },
                        "callerRole": {
                            "type": "string",
                            "enum": [
                                "leader",
                                "main",
                                "supervisor",
                                "guide",
                                "worker",
                                "subagent",
                                "lane_worker",
                                "bounded_worker",
                            ],
                            "description": "Optional caller role. Omitted preserves leader/main compatibility. Worker/subagent roles are rejected and must use Subagent Report.trajectory_update instead; see docs/worker-trajectory-update-reporting.md.",
                        },
                    },
                    "required": ["action"],
                },
            ),
            Tool(
                name="consumeWorkerTrajectoryReport",
                description=(
                    "Leader/main/supervisor-side consumer for a worker "
                    "Subagent Report.trajectory_update section. Reads one report "
                    "JSON file, validates it against docs/specs/subagent-report.schema.json, "
                    "and maps only the safe first-version suggested actions "
                    "append, advance, block, wait, resume, close, or none into "
                    "leader-owned Local Work Trajectory mutation. Worker/subagent "
                    "caller roles are denied; workers must write the report field "
                    "described in docs/worker-trajectory-update-reporting.md. This "
                    "does not run providers, mutate scheduler state, or consume "
                    "ExchangeArtifact lifecycle state."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "reportPath": {
                            "type": "string",
                            "description": "Path to a worker Subagent Report JSON file. Relative paths resolve under the MCP project root.",
                        },
                        "callerRole": {
                            "type": "string",
                            "enum": [
                                "leader",
                                "main",
                                "supervisor",
                                "guide",
                                "worker",
                                "subagent",
                                "lane_worker",
                                "bounded_worker",
                            ],
                            "description": "Caller role. Leader/main/supervisor/guide roles may consume. Worker/subagent roles are rejected and must use Subagent Report.trajectory_update only.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Leader/supervisor actor recorded in the audit payload.",
                        },
                        "currentEventId": {
                            "type": "string",
                            "description": "Optional existing trajectory event id for advance/block/wait/resume/close.",
                        },
                        "title": {
                            "type": "string",
                            "description": "Optional event title for append/start. Defaults to trajectory_update.task_id.",
                        },
                        "eventKind": {
                            "type": "string",
                            "enum": [
                                "start",
                                "task",
                                "decision",
                                "review",
                                "wait",
                                "validation",
                                "writeback",
                                "handoff",
                                "compound",
                                "merge",
                                "close",
                            ],
                            "description": "Event kind for append/start. Defaults to task.",
                        },
                        "startIfMissing": {
                            "type": "boolean",
                            "description": "When true, append creates a minimal Local Work Trajectory if none exists. Default true.",
                        },
                        "trajectoryTitle": {
                            "type": "string",
                            "description": "Trajectory title when append starts a missing trajectory.",
                        },
                        "guideContext": {
                            "type": "string",
                            "description": "Guide context stored when append starts a missing trajectory.",
                        },
                    },
                    "required": ["reportPath"],
                },
            ),
            Tool(
                name="trajectoryTeamContinuity",
                description=(
                    "Leader/operator-owned surface for Trajectory Team Continuity. "
                    "Uses one shared runtime dispatcher to inspect or update the "
                    "trajectory team roster, continuous worker binding, lane "
                    "ownership, and team audit event log. Mutating actions require "
                    "callerRole leader/main/supervisor/guide; worker/subagent roles "
                    "are rejected and must use the worker report path described in "
                    "docs/worker-trajectory-update-reporting.md. This tool does not "
                    "run providers, mutate scheduler task state, or mutate Local "
                    "Work Trajectory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "inspect",
                                "resolve",
                                "assign",
                                "activate",
                                "suspend",
                                "resume",
                                "transfer",
                                "fork",
                                "release",
                                "noContinuity",
                            ],
                            "description": "Trajectory team continuity action.",
                        },
                        "callerRole": {
                            "type": "string",
                            "enum": [
                                "leader",
                                "main",
                                "supervisor",
                                "guide",
                                "worker",
                                "subagent",
                                "lane_worker",
                                "bounded_worker",
                            ],
                            "description": "Caller role. Mutating actions require leader/main/supervisor/guide.",
                        },
                        "trajectoryId": {
                            "type": "string",
                            "description": "Local Work Trajectory id for the team roster.",
                        },
                        "laneId": {
                            "type": "string",
                            "description": "Lane id to inspect, resolve, or mutate.",
                        },
                        "leaderId": {"type": "string"},
                        "workerId": {"type": "string"},
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider label: fake, qoder, codex, or opencode.",
                        },
                        "bindingId": {"type": "string"},
                        "ownershipId": {"type": "string"},
                        "replacementBindingId": {"type": "string"},
                        "newBindingId": {"type": "string"},
                        "sourceBindingId": {"type": "string"},
                        "noContinuityReason": {"type": "string"},
                        "taskId": {"type": "string"},
                        "deliveryId": {"type": "string"},
                        "timestamp": {"type": "string"},
                        "reason": {"type": "string"},
                        "bindingLedgerPath": {
                            "type": "string",
                            "description": "Optional binding ledger path. Relative paths resolve under the MCP project root.",
                        },
                        "bindingEventLogPath": {
                            "type": "string",
                            "description": "Optional binding event JSONL path.",
                        },
                        "ownershipLedgerPath": {
                            "type": "string",
                            "description": "Optional lane ownership ledger path.",
                        },
                        "ownershipEventLogPath": {
                            "type": "string",
                            "description": "Optional lane ownership event JSONL path.",
                        },
                        "leaseLedgerPath": {
                            "type": "string",
                            "description": "Optional delivery lease ledger path used for active lease readback.",
                        },
                        "teamEventLogPath": {
                            "type": "string",
                            "description": "Optional trajectory team continuity event JSONL path.",
                        },
                        "schedulerEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler event log path for audit-only continuity events.",
                        },
                        "attachUrl": {"type": "string"},
                        "sessionId": {"type": "string"},
                        "continueSession": {"type": "boolean"},
                        "forkSession": {"type": "boolean"},
                        "compactContextRef": {"type": "string"},
                        "mailboxCursorRef": {"type": "string"},
                        "workerReportRefs": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "auditRefs": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "includeInactive": {
                            "type": "boolean",
                            "description": "Include inactive binding/ownership rows in readback. Default true.",
                        },
                    },
                    "required": ["action"],
                },
            ),
            Tool(
                name="schedulerProjection",
                description=(
                    "Write a scheduler-derived Local Work Trajectory projection artifact. "
                    "Reads a scheduler snapshot plus optional scheduler/merge-gate JSONL "
                    "history logs, then writes .dbc/progress-graph/scheduler-work-trajectory.json "
                    "by default. This is a read-only projection path and does not mutate "
                    "the agent-owned local-work-trajectory.json lifecycle artifact."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "schedulerEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler task event JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "mergeGateEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler merge-gate event JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "outputPath": {
                            "type": "string",
                            "description": "Optional output JSON path. Defaults to .dbc/progress-graph/scheduler-work-trajectory.json.",
                        },
                        "trajectoryId": {
                            "type": "string",
                            "description": "Optional projected trajectory id.",
                        },
                        "title": {
                            "type": "string",
                            "description": "Optional projected trajectory title.",
                        },
                        "guideContext": {
                            "type": "string",
                            "description": "Optional guide context stored on the projected trajectory.",
                        },
                        "sourceGraphId": {
                            "type": "string",
                            "description": "Optional owning progress graph id for the projection.",
                        },
                        "sourceNodeId": {
                            "type": "string",
                            "description": "Optional owning progress graph node id for the projection.",
                        },
                    },
                    "required": ["snapshotPath"],
                },
            ),
            Tool(
                name="schedulerSubmitTasks",
                description=(
                    "Submit structured scheduler task contracts into the scheduler-owned "
                    "snapshot and scheduler event log. This wraps the existing "
                    "scheduler_task_batch_submission ExchangeArtifact intake, appends "
                    "task_submitted events, and writes the scheduler snapshot. It does "
                    "not run tasks, refresh projection artifacts, or mutate the "
                    "agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. If missing, submission starts from an empty SchedulerState. Relative paths resolve under the MCP project root.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Scheduler task event JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "batch": {
                            "type": "object",
                            "description": (
                                "Optional scheduler_task_batch_submission payload using "
                                "scheduler_submission keys. CamelCase aliases are accepted."
                            ),
                        },
                        "batchId": {
                            "type": "string",
                            "description": "Batch id used when batch.batch_id is omitted.",
                        },
                        "tasks": {
                            "type": "array",
                            "description": (
                                "Task submission payloads. Each task uses the existing "
                                "scheduler_submission contract; camelCase aliases such as "
                                "taskId, contextScope, runtimeProvider, and outputArtifactId "
                                "are accepted."
                            ),
                            "items": {"type": "object"},
                        },
                        "title": {
                            "type": "string",
                            "description": "Optional batch title.",
                        },
                        "summary": {
                            "type": "string",
                            "description": "Optional batch summary.",
                        },
                        "artifactId": {
                            "type": "string",
                            "description": "Optional source ExchangeArtifact id for this submission.",
                        },
                        "artifactVersion": {
                            "type": "string",
                            "description": "Optional source ExchangeArtifact version. Defaults to v1.",
                        },
                        "producer": {
                            "type": "string",
                            "description": "Producer stored on the source ExchangeArtifact. Defaults to schedulerSubmitTasks.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for the source log part and task_submitted events.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Whether submitted tasks may replace existing tasks with the same task_id. Default false.",
                        },
                    },
                    "required": ["snapshotPath", "eventLogPath"],
                },
            ),
            Tool(
                name="admitExchangeArtifact",
                description=(
                    "Admit one exact stored ExchangeArtifact scheduler submission into "
                    "scheduler snapshot/event-log state while recording the durable "
                    "admission ledger. Reuses the exact-version admission path and rejects "
                    "duplicate artifact/version admission by default before scheduler "
                    "mutation. This does not run providers, refresh scheduler projection, "
                    "mark exchange artifacts consumed by default, or mutate agent-owned "
                    "local-work-trajectory.json. Set markConsumedOnSuccess=true to mark "
                    "the exact admitted artifact version consumed only after successful "
                    "admission."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "artifactId": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact id to admit.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact version to admit.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Scheduler task event JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional admission ledger path. Defaults to .dbc/orchestration/exchange-artifact-admissions.json.",
                        },
                        "allowDuplicateAdmission": {
                            "type": "boolean",
                            "description": "Explicitly allow re-admitting an already admitted exact artifact/version. Default false.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Whether admitted scheduler tasks may replace existing task ids. Separate from duplicate admission policy. Default false.",
                        },
                        "markConsumedOnSuccess": {
                            "type": "boolean",
                            "description": "If true, mark the exact admitted ExchangeArtifact version consumed after successful admission. Default false.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Actor recorded in the admission ledger. Defaults to mcp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for scheduler task_submitted events.",
                        },
                    },
                    "required": ["artifactId", "version", "snapshotPath", "eventLogPath"],
                },
            ),
            Tool(
                name="schedulerBindingReferenceInspect",
                description=(
                    "Read-only inspection for supervisor storage binding artifact "
                    "references in one exact stored scheduler submission artifact. "
                    "Reads the ExchangeArtifact store, validates binding refs, and "
                    "returns per-task status without admitting tasks, mutating "
                    "scheduler state, writing admission ledgers, reading raw evidence "
                    "JSON, refreshing projection, or mutating agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "artifactId": {
                            "type": "string",
                            "description": "Exact scheduler submission ExchangeArtifact id to inspect.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact version to inspect.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                    },
                    "required": ["artifactId", "version"],
                },
            ),
            Tool(
                name="agentExchangeMailbox",
                description=(
                    "Read one agent's ExchangeArtifact mailbox as a compact inbox, "
                    "outbox, related, and actionable read model. Reads only the local "
                    "ExchangeArtifact store; does not mutate scheduler state, exchange "
                    "artifact lifecycle, admission ledgers, projections, runtimes, or "
                    "agent-owned local-work-trajectory.json. Sensitive/redaction-required "
                    "artifacts remain discoverable but omit raw preview payload content."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agentId": {
                            "type": "string",
                            "description": "Agent id whose mailbox should be inspected, for example agent:client.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "includeArchived": {
                            "type": "boolean",
                            "description": "Whether archived ExchangeArtifact versions should be included. Default false.",
                        },
                    },
                    "required": ["agentId"],
                },
            ),
            Tool(
                name="agentExchangeHistory",
                description=(
                    "Read compact ExchangeArtifact communication history over causality "
                    "and log parts. Supports optional agentId/correlationId filters. "
                    "Reads only the local ExchangeArtifact store; does not expose raw "
                    "sensitive payload content and does not mutate scheduler state, "
                    "exchange artifacts, admission ledgers, projections, runtimes, or "
                    "agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agentId": {
                            "type": "string",
                            "description": "Optional agent id filter, for example agent:client.",
                        },
                        "correlationId": {
                            "type": "string",
                            "description": "Optional causality correlation id filter.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "includeArchived": {
                            "type": "boolean",
                            "description": "Whether archived ExchangeArtifact versions should be included. Default false.",
                        },
                    },
                },
            ),
            Tool(
                name="agentExchangeActionCandidates",
                description=(
                    "Read-only action-candidate bridge over ExchangeArtifacts. Classifies "
                    "scheduler submission, review, handoff, blocker, and merge candidates "
                    "with structured reasons and clues. It does not mutate scheduler state, "
                    "review state, handoffs, exchange artifacts, admission ledgers, "
                    "projections, runtimes, or agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agentId": {
                            "type": "string",
                            "description": "Optional agent id filter, for example agent:client.",
                        },
                        "candidateType": {
                            "type": "string",
                            "description": (
                                "Optional candidate type filter: scheduler_submission_candidate, "
                                "review_candidate, handoff_candidate, blocker_candidate, or merge_candidate."
                            ),
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact admission ledger path.",
                        },
                        "includeArchived": {
                            "type": "boolean",
                            "description": "Whether archived ExchangeArtifact versions should be included. Default false.",
                        },
                    },
                },
            ),
            Tool(
                name="agentExchangeActionCandidateDecide",
                description=(
                    "Write one coordination-product ExchangeArtifact that records the "
                    "disposition for an existing action candidate. This may mutate only "
                    "the local ExchangeArtifact store by adding the disposition artifact; "
                    "it does not admit scheduler tasks, open review state, write handoffs, "
                    "resolve merge gates, mutate the source artifact, run providers, "
                    "refresh projections, or mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "candidateId": {
                            "type": "string",
                            "description": "Exact action candidate id from agentExchangeActionCandidates.",
                        },
                        "dispositionArtifactId": {
                            "type": "string",
                            "description": "ExchangeArtifact id for the disposition product to create.",
                        },
                        "dispositionVersion": {
                            "type": "string",
                            "description": "Disposition artifact version. Default v1.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Agent/operator recording the disposition.",
                        },
                        "disposition": {
                            "type": "string",
                            "enum": ["accept", "reject", "defer", "supersede"],
                            "description": "Disposition to record for the candidate.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "Compact reason for the disposition.",
                        },
                        "targetSurface": {
                            "type": "string",
                            "description": "Required for accept; downstream surface expected to consume this decision.",
                        },
                        "replacementArtifactId": {
                            "type": "string",
                            "description": "Required for supersede; replacement coordination artifact id.",
                        },
                        "replacementVersion": {
                            "type": "string",
                            "description": "Replacement coordination artifact version.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for the disposition artifact/log.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace an existing exact disposition artifact/version. Default false.",
                        },
                    },
                    "required": [
                        "candidateId",
                        "dispositionArtifactId",
                        "actor",
                        "disposition",
                    ],
                },
            ),
            Tool(
                name="agentExchangeAcceptedSchedulerCandidateConsume",
                description=(
                    "Consume one accepted scheduler_submission_candidate disposition by "
                    "calling the existing exact-version admission helper. This may write "
                    "scheduler snapshot/event-log state and the admission ledger. It does "
                    "not open reviews, write handoffs, resolve merge gates, run providers, "
                    "refresh projections, or mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dispositionArtifactId": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact id.",
                        },
                        "dispositionVersion": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact version.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler snapshot path to write.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Scheduler event JSONL path to append.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact admission ledger path.",
                        },
                        "allowDuplicateAdmission": {
                            "type": "boolean",
                            "description": "Allow duplicate exact artifact/version admission. Default false.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace existing scheduler task contracts. Default false.",
                        },
                        "validateBindingArtifactRefs": {
                            "type": "boolean",
                            "description": "Validate supervisor storage binding artifact refs before admission. Default false.",
                        },
                        "markConsumedOnSuccess": {
                            "type": "boolean",
                            "description": "Mark the admitted source artifact consumed only after successful admission. Default false.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Admission actor. Default mcp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for admission/event records.",
                        },
                    },
                    "required": [
                        "dispositionArtifactId",
                        "dispositionVersion",
                        "snapshotPath",
                        "eventLogPath",
                    ],
                },
            ),
            Tool(
                name="agentExchangeAcceptedReviewCandidateConsume",
                description=(
                    "Consume one accepted review_candidate disposition by dispatching "
                    "a review intake payload to the existing review intake adapter. "
                    "This may mutate review intake state in the configured adapter. "
                    "It does not admit scheduler tasks, write handoffs, resolve merge "
                    "gates, run providers, refresh projections, or mutate "
                    "agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dispositionArtifactId": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact id.",
                        },
                        "dispositionVersion": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact version.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Agent/operator consuming the accepted review candidate. Default mcp.",
                        },
                    },
                    "required": [
                        "dispositionArtifactId",
                        "dispositionVersion",
                    ],
                },
            ),
            Tool(
                name="agentExchangeAcceptedHandoffCandidateConsume",
                description=(
                    "Consume one accepted handoff_candidate disposition by dispatching "
                    "a schema-valid Handoff payload to the existing handoff delivery "
                    "adapter. This may write a handoff payload through the configured "
                    "handoff consumer. It does not admit scheduler tasks, open reviews, "
                    "resolve merge gates, run providers, refresh projections, or mutate "
                    "agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dispositionArtifactId": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact id.",
                        },
                        "dispositionVersion": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact version.",
                        },
                        "handoffDir": {
                            "type": "string",
                            "description": "Directory where the configured file handoff consumer writes handoff JSON.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Agent/operator consuming the accepted handoff candidate. Default mcp.",
                        },
                    },
                    "required": [
                        "dispositionArtifactId",
                        "dispositionVersion",
                        "handoffDir",
                    ],
                },
            ),
            Tool(
                name="agentExchangeAcceptedMergeCandidateConsume",
                description=(
                    "Consume one accepted merge_candidate disposition by resolving "
                    "an explicit scheduler merge gate. The caller must provide the "
                    "exact gateId and approved boolean; the tool does not infer a "
                    "gate from ExchangeArtifact relations. This may write scheduler "
                    "snapshot state and merge-gate event log state. It does not "
                    "admit scheduler tasks, open reviews, write handoffs, run "
                    "providers, refresh projections, or mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dispositionArtifactId": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact id.",
                        },
                        "dispositionVersion": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact version.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler snapshot path to update.",
                        },
                        "gateId": {
                            "type": "string",
                            "description": "Exact scheduler merge gate id to resolve.",
                        },
                        "approved": {
                            "type": "boolean",
                            "description": "Whether the explicit merge gate decision approves the merge.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "mergeGateEventLogPath": {
                            "type": "string",
                            "description": "Optional merge-gate event JSONL path to append.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "Compact reason for the merge gate decision.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Agent/operator consuming the accepted merge candidate. Default mcp.",
                        },
                        "resolvedAt": {
                            "type": "string",
                            "description": "Optional merge gate resolved_at timestamp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional event timestamp.",
                        },
                    },
                    "required": [
                        "dispositionArtifactId",
                        "dispositionVersion",
                        "snapshotPath",
                        "gateId",
                        "approved",
                    ],
                },
            ),
            Tool(
                name="agentExchangeAcceptedBlockerCandidateConsume",
                description=(
                    "Consume one accepted blocker_candidate disposition by blocking "
                    "an explicit scheduler task. The caller must provide the exact "
                    "taskId and reason; the tool does not infer a task from "
                    "ExchangeArtifact relations. This may write scheduler snapshot "
                    "state and scheduler event log state. It does not admit scheduler "
                    "tasks, open reviews, write handoffs, resolve merge gates, run "
                    "providers, refresh projections, or mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dispositionArtifactId": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact id.",
                        },
                        "dispositionVersion": {
                            "type": "string",
                            "description": "Exact disposition ExchangeArtifact version.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler snapshot path to update.",
                        },
                        "taskId": {
                            "type": "string",
                            "description": "Exact scheduler task id to block.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "Required blocker reason to store on the task.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler event JSONL path to append.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Agent/operator consuming the accepted blocker candidate. Default mcp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional event timestamp.",
                        },
                    },
                    "required": [
                        "dispositionArtifactId",
                        "dispositionVersion",
                        "snapshotPath",
                        "taskId",
                        "reason",
                    ],
                },
            ),
            Tool(
                name="agentExchangeReply",
                description=(
                    "Create one exact-version reply ExchangeArtifact in the local "
                    "ExchangeArtifact store. The reply records causality to the source "
                    "artifact version and adds a compact log part. This does not admit "
                    "scheduler tasks, run providers, write admission ledgers, refresh "
                    "projections, or mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "sourceArtifactId": {
                            "type": "string",
                            "description": "Exact source ExchangeArtifact id being replied to.",
                        },
                        "sourceVersion": {
                            "type": "string",
                            "description": "Exact source ExchangeArtifact version being replied to.",
                        },
                        "replyArtifactId": {
                            "type": "string",
                            "description": "Exact reply ExchangeArtifact id to create.",
                        },
                        "replyVersion": {
                            "type": "string",
                            "description": "Reply ExchangeArtifact version. Default v1.",
                        },
                        "producer": {
                            "type": "string",
                            "description": "Agent id producing the reply.",
                        },
                        "text": {
                            "type": "string",
                            "description": "Optional reply text payload.",
                        },
                        "structured": {
                            "type": "object",
                            "description": "Optional structured reply payload.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "kind": {
                            "type": "string",
                            "description": "Reply artifact kind. Default message.",
                        },
                        "intent": {
                            "type": "string",
                            "description": "Reply artifact intent. Default inform.",
                        },
                        "audience": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Optional explicit reply audience. Defaults to the source artifact producer.",
                        },
                        "createdAt": {
                            "type": "string",
                            "description": "Optional created_at timestamp.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace an existing exact reply artifact/version. Default false.",
                        },
                    },
                    "required": ["sourceArtifactId", "sourceVersion", "replyArtifactId", "producer"],
                },
            ),
            Tool(
                name="agentExchangeTransition",
                description=(
                    "Transition one exact stored ExchangeArtifact version to accepted, "
                    "rejected, consumed, superseded, or archived, appending a compact "
                    "log part. This mutates only the local ExchangeArtifact store and "
                    "does not admit scheduler tasks, run providers, write admission "
                    "ledgers, refresh projections, or mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "artifactId": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact id to transition.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact version to transition.",
                        },
                        "targetState": {
                            "type": "string",
                            "enum": ["accepted", "rejected", "consumed", "superseded", "archived"],
                            "description": "Target lifecycle state for this first-slice transition.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Actor recorded on the lifecycle log part.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "reason": {
                            "type": "string",
                            "description": "Optional lifecycle transition reason.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional transition timestamp.",
                        },
                    },
                    "required": ["artifactId", "version", "targetState", "actor"],
                },
            ),
            Tool(
                name="schedulerStorageBindingArtifactPublish",
                description=(
                    "Publish one durable supervisor storage binding evidence summary "
                    "as a compact exact-version ExchangeArtifact. Mutates only the "
                    "local ExchangeArtifact store; does not admit scheduler tasks, "
                    "run providers, create agent home or scratch directories, write "
                    "scratch manifests, refresh projections, read raw binding payloads "
                    "into exchange artifacts, or mutate agent-owned Local Work "
                    "Trajectory / local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "evidencePath": {
                            "type": "string",
                            "description": "Durable supervisor storage binding evidence JSON path.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults to .dbc/orchestration/exchange-artifacts.json.",
                        },
                        "artifactId": {
                            "type": "string",
                            "description": "Optional output ExchangeArtifact id. Defaults from the evidence id.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Output ExchangeArtifact exact version. Default v1.",
                        },
                        "producer": {
                            "type": "string",
                            "description": "Optional producer id. Defaults from the evidence summary.",
                        },
                        "audience": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Optional artifact audience list. Defaults to scheduler and workspace-registration.",
                        },
                        "createdAt": {
                            "type": "string",
                            "description": "Optional artifact created_at timestamp. Defaults from the evidence summary.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace an existing exact artifact/version. Default false.",
                        },
                    },
                    "required": ["evidencePath"],
                },
            ),
            Tool(
                name="schedulerRunOnceAndProject",
                description=(
                    "Run one bounded persisted scheduler pass with the built-in fake runtime "
                    "adapter, write the updated scheduler snapshot, and refresh the "
                    "scheduler-derived Local Work Trajectory projection. runtimeProvider "
                    "is accepted for forward compatibility but currently only 'fake' is "
                    "allowed; qoder and other real providers return a clear error until "
                    "host permission and adapter registry wiring are explicit. Requires "
                    "snapshotPath and eventLogPath; this does not mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Scheduler task event JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "mergeGateEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler merge-gate event JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "outputPath": {
                            "type": "string",
                            "description": "Optional scheduler projection output JSON path. Defaults to .dbc/progress-graph/scheduler-work-trajectory.json.",
                        },
                        "maxRuns": {
                            "type": "number",
                            "description": "Optional bounded maximum number of ready tasks to run.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp used for scheduler lifecycle events and fake runtime events.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": (
                                "Optional runtime provider selector. Defaults to 'fake'. "
                                "Current MCP smoke path only accepts 'fake'; values such as "
                                "'qoder' are rejected with a provider guard error."
                            ),
                        },
                        "guideContext": {
                            "type": "string",
                            "description": "Optional guide context stored on the projected trajectory.",
                        },
                        "sourceGraphId": {
                            "type": "string",
                            "description": "Optional owning progress graph id for the projection.",
                        },
                        "sourceNodeId": {
                            "type": "string",
                            "description": "Optional owning progress graph node id for the projection.",
                        },
                    },
                    "required": ["snapshotPath", "eventLogPath"],
                },
            ),
            Tool(
                name="schedulerAuthorizationReadback",
                description=(
                    "Read-only scheduler authorization diagnostics over edit lease "
                    "declarations, scheduler-owned edit lease lifecycle records, and "
                    "metadata-only shared-process sandbox mount authorization. Reads "
                    "a scheduler snapshot plus optional scheduler event log recovery; "
                    "does not run providers, mutate scheduler state, refresh projection, "
                    "or mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "schedulerEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler task event JSONL path. Relative paths resolve under the MCP project root and is replayed through the existing recovery path.",
                        },
                        "strict": {
                            "type": "boolean",
                            "description": "Whether event-log replay should reject unknown task events. Default true.",
                        },
                        "workspaceRoot": {
                            "type": "string",
                            "description": "Optional workspace root recorded in sandbox metadata readback. Defaults to the MCP project root.",
                        },
                        "scratchRoot": {
                            "type": "string",
                            "description": "Optional scratch root used only to compute readback scratch paths. Defaults to .dbc/scratch.",
                        },
                    },
                    "required": ["snapshotPath"],
                },
            ),
            Tool(
                name="schedulerCleanupReceipts",
                description=(
                    "Explicitly clean cleanup-required git-worktree sandbox "
                    "allocations recorded in one durable sandbox allocation receipt "
                    "evidence artifact. Writes updated receipt evidence and returns "
                    "cleanup command receipt summaries. This does not mutate scheduler "
                    "state, run host tasks, refresh projection, start a daemon, or "
                    "mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "inputEvidencePath": {
                            "type": "string",
                            "description": "Input sandbox_allocation_receipt_evidence JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "outputEvidencePath": {
                            "type": "string",
                            "description": "Optional output evidence path. Relative paths resolve under the MCP project root.",
                        },
                        "outputEvidenceId": {
                            "type": "string",
                            "description": "Optional output evidence id. Defaults to '<input evidence id>:cleanup'.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for the cleanup evidence.",
                        },
                        "gitExecutable": {
                            "type": "string",
                            "description": "Optional git executable path/name. Defaults to git.",
                        },
                    },
                    "required": ["inputEvidencePath"],
                },
            ),
            Tool(
                name="schedulerOperatorWorkflow",
                description=(
                    "Run the explicit shared scheduler operator workflow: inspect "
                    "ExchangeArtifact scheduler-admission candidates, optionally inspect "
                    "supervisor storage binding refs for one exact artifact version, "
                    "optionally admit that exact artifact version, optionally run a "
                    "bounded fake-runtime scheduler loop with durable evidence, "
                    "optionally refresh the scheduler-derived projection, then read "
                    "Host Evidence presentation. Mutating steps are opt-in via "
                    "admit/runLoop/refreshProjection; markConsumedOnSuccess can "
                    "mark the exact admitted ExchangeArtifact version consumed "
                    "after successful admission; "
                    "this does not mutate agent-owned Local Work Trajectory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "artifactId": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact id to admit when admit=true.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Exact ExchangeArtifact version to admit when admit=true.",
                        },
                        "admit": {
                            "type": "boolean",
                            "description": "Whether to admit the exact artifact/version. Default false.",
                        },
                        "inspectBindingRefs": {
                            "type": "boolean",
                            "description": (
                                "Whether to run read-only supervisor storage binding "
                                "reference inspection before admission. Default false."
                            ),
                        },
                        "runLoop": {
                            "type": "boolean",
                            "description": "Whether to run a bounded fake scheduler loop. Default false.",
                        },
                        "refreshProjection": {
                            "type": "boolean",
                            "description": "Whether to refresh scheduler-derived trajectory projection. Default false.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional admission ledger path.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Optional scheduler snapshot path. Defaults under .dbc/scheduler.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler event log path. Defaults under .dbc/scheduler.",
                        },
                        "mergeGateEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler merge-gate event log path.",
                        },
                        "projectionOutputPath": {
                            "type": "string",
                            "description": "Optional scheduler projection output path.",
                        },
                        "evidenceId": {
                            "type": "string",
                            "description": "Optional scheduler-loop evidence id when runLoop=true.",
                        },
                        "evidencePath": {
                            "type": "string",
                            "description": "Optional scheduler-loop evidence output path.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Current workflow only supports 'fake'.",
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "Bounded loop max ticks. Default 3.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "Bounded loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "Runtime failure stop threshold. Default 1.",
                        },
                        "allowDuplicateAdmission": {
                            "type": "boolean",
                            "description": "Allow duplicate exact artifact/version admission. Default false.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Allow admitted scheduler tasks to replace existing task ids. Default false.",
                        },
                        "markConsumedOnSuccess": {
                            "type": "boolean",
                            "description": "If true, mark the exact admitted ExchangeArtifact version consumed after successful admission. Default false.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Actor recorded in admission ledger. Defaults to mcp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for scheduler and evidence events.",
                        },
                        "guideContext": {
                            "type": "string",
                            "description": "Optional guide context stored on the projection.",
                        },
                        "sourceGraphId": {
                            "type": "string",
                            "description": "Optional owning progress graph id for projection.",
                        },
                        "sourceNodeId": {
                            "type": "string",
                            "description": "Optional owning progress graph node id for projection.",
                        },
                    },
                },
            ),
            Tool(
                name="schedulerOperatorDogfoodClosure",
                description=(
                    "Run the deterministic fake-runtime scheduler operator dogfood "
                    "closure: seed a fixture, inspect binding refs when applicable, "
                    "admit the exact artifact/version, mark it consumed after "
                    "successful admission by default, run a bounded fake scheduler "
                    "loop with durable evidence, refresh scheduler projection, and "
                    "read Host Evidence presentation. Defaults to the "
                    "binding-consumer fixture. This does not run real providers, "
                    "start a daemon service, run cleanup, create agent home or "
                    "scratch directories, or mutate agent-owned Local Work Trajectory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "fixture": {
                            "type": "string",
                            "description": (
                                "Fixture selector: binding-consumer, simple, or "
                                "multilane. Default binding-consumer."
                            ),
                        },
                        "artifactId": {
                            "type": "string",
                            "description": "Optional artifact id override for the seeded fixture.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Optional fixture artifact version override.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional admission ledger path.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Optional scheduler snapshot path. Defaults under .dbc/scheduler.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler event log path. Defaults under .dbc/scheduler.",
                        },
                        "mergeGateEventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler merge-gate event log path.",
                        },
                        "projectionOutputPath": {
                            "type": "string",
                            "description": "Optional scheduler projection output path.",
                        },
                        "evidenceId": {
                            "type": "string",
                            "description": "Optional scheduler-loop evidence id.",
                        },
                        "evidencePath": {
                            "type": "string",
                            "description": "Optional scheduler-loop evidence output path.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": (
                                "Runtime provider selector. Current closure only "
                                "supports 'fake'; real providers require a separate "
                                "live-runtime planning gate."
                            ),
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "Bounded loop max ticks. Default 3.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "Bounded loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "Runtime failure stop threshold. Default 1.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace existing seeded fixture artifacts. Default false.",
                        },
                        "inspectBindingRefs": {
                            "type": "boolean",
                            "description": (
                                "Whether to inspect supervisor storage binding refs. "
                                "Default true; binding-consumer forces inspection."
                            ),
                        },
                        "markConsumedOnSuccess": {
                            "type": "boolean",
                            "description": (
                                "Whether to mark the exact admitted ExchangeArtifact "
                                "version consumed after successful admission. Default true."
                            ),
                        },
                        "actor": {
                            "type": "string",
                            "description": "Actor recorded in admission/consumption logs. Defaults to mcp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for scheduler and evidence events.",
                        },
                        "createdAt": {
                            "type": "string",
                            "description": "Optional timestamp for seeded fixture artifacts.",
                        },
                        "guideContext": {
                            "type": "string",
                            "description": "Optional guide context stored on the projection.",
                        },
                        "sourceGraphId": {
                            "type": "string",
                            "description": "Optional owning progress graph id for projection.",
                        },
                        "sourceNodeId": {
                            "type": "string",
                            "description": "Optional owning progress graph node id for projection.",
                        },
                    },
                },
            ),
            Tool(
                name="schedulerGuideWorkerLocalOrchestration",
                description=(
                    "Run the fake-runtime guide-worker local trajectory "
                    "orchestration helper through MCP. A guide creates structured "
                    "worker instructions and a scheduler batch, exact admission "
                    "persists scheduler state, and bounded scheduling waves select "
                    "at most one ready worker task per lane. This reports scheduling "
                    "parallelism only: no real providers, no process/thread pool, no "
                    "agent home or scratch directory creation, no projection refresh, "
                    "and no mutation of agent-owned Local Work Trajectory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Defaults under .dbc/orchestration.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact admission ledger path. Defaults under .dbc/orchestration.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Optional scheduler snapshot path for this workflow.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler event log path for this workflow.",
                        },
                        "trajectoryId": {
                            "type": "string",
                            "description": "Local Work Trajectory id recorded in ExchangeArtifact scope.",
                        },
                        "guideAgentId": {
                            "type": "string",
                            "description": "Guide agent id. Must differ from workerAgentId.",
                        },
                        "workerAgentId": {
                            "type": "string",
                            "description": "Default worker agent id used when an instruction omits workerAgentId.",
                        },
                        "artifactIdPrefix": {
                            "type": "string",
                            "description": "Artifact id prefix for guide instruction and worker batch artifacts.",
                        },
                        "workerInstructions": {
                            "type": "array",
                            "description": (
                                "Structured worker instructions. If omitted, the "
                                "runtime helper can derive instructions from "
                                "guideTask/plannerLaneSpecs, or fall back to a "
                                "deterministic two-lane split."
                            ),
                            "items": {
                                "type": "object",
                                "properties": {
                                    "taskId": {
                                        "type": "string",
                                        "description": "Unique scheduler task id.",
                                    },
                                    "title": {
                                        "type": "string",
                                        "description": "Short worker task title.",
                                    },
                                    "instruction": {
                                        "type": "string",
                                        "description": "Concrete instruction for the worker agent.",
                                    },
                                    "laneId": {
                                        "type": "string",
                                        "description": "Local trajectory lane id used for scheduling-wave separation.",
                                    },
                                    "contextId": {
                                        "type": "string",
                                        "description": "Optional scheduler context id.",
                                    },
                                    "workerAgentId": {
                                        "type": "string",
                                        "description": "Optional per-task worker agent id.",
                                    },
                                    "workerRuntimeProvider": {
                                        "type": "string",
                                        "description": (
                                            "Optional per-task runtime provider. "
                                            "Runtime helper supports host-injected "
                                            "fake, qoder, or codex adapters, but this MCP "
                                            "surface still registers only fake unless "
                                            "a separate host-authorized wrapper is used."
                                        ),
                                    },
                                    "allowedArtifacts": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                        "description": "Optional lease-scoped writable artifact/path hints.",
                                    },
                                    "acceptance": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                        "description": "Observable acceptance criteria for the worker task.",
                                    },
                                    "dependsOnTaskIds": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                        "description": "Earlier task ids this instruction depends on.",
                                    },
                                    "outputArtifactId": {
                                        "type": "string",
                                        "description": "Optional expected worker result artifact id.",
                                    },
                                    "sandboxProfile": {
                                        "type": "object",
                                        "description": (
                                            "Optional sandbox profile for the worker task. "
                                            "Defaults to shared-process; host-owned wrappers "
                                            "can opt into git-worktree."
                                        ),
                                        "properties": {
                                            "profileId": {"type": "string"},
                                            "profileKind": {
                                                "type": "string",
                                                "description": "none, shared-process, git-worktree, docker, or remote-vm.",
                                            },
                                            "networkPolicy": {"type": "string"},
                                            "secretPolicy": {"type": "string"},
                                            "mountPolicy": {"type": "string"},
                                        },
                                    },
                                },
                            },
                        },
                        "guideTask": {
                            "type": "object",
                            "description": (
                                "High-level guide task used by the deterministic "
                                "planner when workerInstructions are omitted."
                            ),
                            "properties": {
                                "title": {
                                    "type": "string",
                                    "description": "Short high-level task title.",
                                },
                                "summary": {
                                    "type": "string",
                                    "description": "Task context copied into worker instructions.",
                                },
                            },
                        },
                        "plannerLaneSpecs": {
                            "type": "array",
                            "description": (
                                "Lane specs used by the deterministic guide planner "
                                "to generate concrete workerInstructions."
                            ),
                            "items": {
                                "type": "object",
                                "properties": {
                                    "laneId": {
                                        "type": "string",
                                        "description": "Local trajectory lane id.",
                                    },
                                    "label": {
                                        "type": "string",
                                        "description": "Worker task title for this lane.",
                                    },
                                    "focus": {
                                        "type": "string",
                                        "description": "Concrete lane focus for the worker instruction.",
                                    },
                                    "allowedArtifacts": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                        "description": "Optional edit lease artifact/path hints.",
                                    },
                                    "acceptance": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                        "description": "Optional acceptance criteria for this lane.",
                                    },
                                    "dependsOnLaneIds": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                        "description": "Optional earlier lane ids this lane depends on.",
                                    },
                                    "workerAgentId": {
                                        "type": "string",
                                        "description": "Optional per-lane worker agent id.",
                                    },
                                    "workerRuntimeProvider": {
                                        "type": "string",
                                        "description": "Optional per-lane worker runtime provider.",
                                    },
                                    "sandboxProfile": {
                                        "type": "object",
                                        "description": (
                                            "Optional sandbox profile copied into generated "
                                            "workerInstructions. Defaults to shared-process."
                                        ),
                                        "properties": {
                                            "profileId": {"type": "string"},
                                            "profileKind": {
                                                "type": "string",
                                                "description": "none, shared-process, git-worktree, docker, or remote-vm.",
                                            },
                                            "networkPolicy": {"type": "string"},
                                            "secretPolicy": {"type": "string"},
                                            "mountPolicy": {"type": "string"},
                                        },
                                    },
                                },
                            },
                        },
                        "maxParallelLanes": {
                            "type": "integer",
                            "description": "Maximum lane-distinct worker tasks in one scheduling wave. Default 2.",
                        },
                        "maxWaves": {
                            "type": "integer",
                            "description": "Maximum bounded scheduling waves to execute. Default 1.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace existing artifacts/tasks when ids already exist. Default false.",
                        },
                        "allowDuplicateAdmission": {
                            "type": "boolean",
                            "description": "Allow duplicate exact artifact/version admission. Default false.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional deterministic timestamp for artifacts and scheduler events.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Current MCP surface only supports 'fake'.",
                        },
                        "waveExecutionMode": {
                            "type": "string",
                            "description": (
                                "Wave executor mode: serial or threaded. Threaded "
                                "attempts concurrent runtime invocation for one "
                                "lane-distinct fake-runtime wave, then merges "
                                "scheduler state deterministically. Default serial."
                            ),
                        },
                        "workspaceRoot": {
                            "type": "string",
                            "description": "Optional workspace root recorded in sandbox metadata readback.",
                        },
                        "scratchRoot": {
                            "type": "string",
                            "description": "Optional scratch root used only to compute readback scratch paths.",
                        },
                    },
                },
            ),
            Tool(
                name="schedulerSandboxReceiptWorkflow",
                description=(
                    "Run the host sandbox receipt workflow: host allocation, durable "
                    "sandbox allocation receipt evidence readback, optional explicit "
                    "cleanup, and post-cleanup Host Evidence readback. Supports "
                    "run-once and daemon-loop modes over fake runtime wiring. Cleanup "
                    "runs only when cleanup=true. This does not refresh projection, "
                    "start a daemon service, run real providers, mutate "
                    "ExchangeArtifact/admission ledger state, or mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "mode": {
                            "type": "string",
                            "description": "Workflow mode: run-once or daemon-loop.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Scheduler event log JSONL path. Relative paths resolve under the MCP project root.",
                        },
                        "workspaceRoot": {
                            "type": "string",
                            "description": "Source git repository root for git-worktree allocation. Relative paths resolve under the MCP project root.",
                        },
                        "gitWorktreeSandboxRoot": {
                            "type": "string",
                            "description": "Git-worktree sandbox root. Relative paths resolve under the MCP project root.",
                        },
                        "allocationEvidenceId": {
                            "type": "string",
                            "description": "Required sandbox_allocation_receipt_evidence id.",
                        },
                        "allocationEvidencePath": {
                            "type": "string",
                            "description": "Optional allocation evidence output path.",
                        },
                        "cleanup": {
                            "type": "boolean",
                            "description": "Whether to run explicit cleanup. Default false.",
                        },
                        "cleanupEvidenceId": {
                            "type": "string",
                            "description": "Optional cleanup evidence id. Requires cleanup=true.",
                        },
                        "cleanupEvidencePath": {
                            "type": "string",
                            "description": "Optional cleanup evidence output path. Requires cleanup=true.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Current tool only supports fake.",
                        },
                        "maxRuns": {
                            "type": "integer",
                            "description": "run-once max runs. Default 1.",
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "daemon-loop max ticks. Default 1.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "daemon-loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "daemon-loop runtime failure stop threshold. Default 1.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for scheduler and evidence events.",
                        },
                        "gitExecutable": {
                            "type": "string",
                            "description": "Optional git executable path/name. Defaults to git.",
                        },
                    },
                    "required": [
                        "mode",
                        "snapshotPath",
                        "eventLogPath",
                        "workspaceRoot",
                        "gitWorktreeSandboxRoot",
                        "allocationEvidenceId",
                    ],
                },
            ),
            Tool(
                name="schedulerLifecycleControl",
                description=(
                    "Read or mutate the scheduler daemon lifecycle control file. "
                    "Actions are deterministic control-file operations only: inspect, "
                    "start, heartbeat, pause, resume, cancel, shutdown, and mark_stale. "
                    "This does not run providers, refresh scheduler projection, mutate "
                    "ExchangeArtifact/admission ledger state, or mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "description": "Lifecycle action: inspect, start, heartbeat, pause, resume, cancel, shutdown, or mark_stale.",
                        },
                        "controlPath": {
                            "type": "string",
                            "description": "Scheduler daemon lifecycle control JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Scheduler state snapshot JSON path. Required for action=start.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Scheduler task event JSONL path. Required for action=start.",
                        },
                        "daemonId": {
                            "type": "string",
                            "description": "Daemon owner id. Required for action=start.",
                        },
                        "runId": {
                            "type": "string",
                            "description": "Optional lifecycle run id stored in the control file.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for lifecycle transitions.",
                        },
                        "staleAfterSeconds": {
                            "type": "integer",
                            "description": "Optional heartbeat stale threshold in seconds.",
                        },
                        "nowEpochSeconds": {
                            "type": "integer",
                            "description": "Optional deterministic current epoch seconds for stale inspection.",
                        },
                    },
                    "required": ["action", "controlPath"],
                },
            ),
            Tool(
                name="schedulerLifecycleRunOnce",
                description=(
                    "Run one lifecycle-gated bounded scheduler daemon loop using the "
                    "built-in fake runtime only. The lifecycle control must already be "
                    "running; paused/cancelled/stopped/stale controls skip scheduler "
                    "mutation, and cancellation is consumed before provider execution. "
                    "This does not refresh scheduler projection, mutate ExchangeArtifact/"
                    "admission ledger state, or mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "controlPath": {
                            "type": "string",
                            "description": "Scheduler daemon lifecycle control JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Defaults to 'fake'; only 'fake' is accepted in this MCP surface.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for the lifecycle-gated run.",
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "Bounded loop max ticks. Default 1.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "Bounded loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "Runtime failure stop threshold. Default 1.",
                        },
                    },
                    "required": ["controlPath"],
                },
            ),
            Tool(
                name="schedulerLifecycleHarness",
                description=(
                    "Run the policy-controlled bounded scheduler lifecycle harness "
                    "using the built-in fake runtime only. Supports explicit "
                    "cancelled/deadline preflight and retry over listed harness stop "
                    "reasons. This does not start a daemon service, refresh scheduler "
                    "projection, run cleanup, mutate ExchangeArtifact/admission ledger "
                    "state, or mutate agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "controlPath": {
                            "type": "string",
                            "description": "Scheduler daemon lifecycle control JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Defaults to 'fake'; only 'fake' is accepted in this MCP surface.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for lifecycle-gated harness attempts.",
                        },
                        "maxCycles": {
                            "type": "integer",
                            "description": "Bounded harness max cycles per policy attempt. Default 1.",
                        },
                        "maxLoopFailures": {
                            "type": "integer",
                            "description": "Maximum loop failure stop reasons before the harness attempt stops. Default 1.",
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "Bounded loop max ticks for each lifecycle run-once. Default 1.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "Bounded loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "Runtime failure stop threshold. Default 1.",
                        },
                        "staleAfterSeconds": {
                            "type": "integer",
                            "description": "Optional heartbeat stale threshold in seconds for lifecycle inspection.",
                        },
                        "nowEpochSeconds": {
                            "type": "integer",
                            "description": "Optional deterministic current epoch seconds for deadline and stale inspection.",
                        },
                        "policyCancelled": {
                            "type": "boolean",
                            "description": "If true, stop before reading or mutating scheduler state.",
                        },
                        "deadlineEpochSeconds": {
                            "type": "integer",
                            "description": "Optional deadline epoch seconds. Requires nowEpochSeconds.",
                        },
                        "maxAttempts": {
                            "type": "integer",
                            "description": "Maximum policy attempts. Default 1.",
                        },
                        "retryStopReasons": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Harness stop reasons that should be retried until maxAttempts.",
                        },
                    },
                    "required": ["controlPath"],
                },
            ),
            Tool(
                name="schedulerDaemonSupervisorStep",
                description=(
                    "Run one host-managed daemon supervisor step over the "
                    "policy-controlled bounded scheduler lifecycle harness using "
                    "the built-in fake runtime only. Returns host/session/run "
                    "identity, cancellation-source metadata, lifecycle status "
                    "readback, and harness policy result. This does not start a "
                    "daemon service, refresh scheduler projection, run cleanup, "
                    "mutate ExchangeArtifact/admission ledger state, or mutate "
                    "agent-owned local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "supervisorId": {
                            "type": "string",
                            "description": "Required host-owned supervisor identity.",
                        },
                        "controlPath": {
                            "type": "string",
                            "description": "Scheduler daemon lifecycle control JSON path. Relative paths resolve under the MCP project root.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Defaults to 'fake'; only 'fake' is accepted in this MCP surface.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional timestamp for lifecycle-gated harness attempts.",
                        },
                        "sessionId": {
                            "type": "string",
                            "description": "Optional host-owned supervisor session identity.",
                        },
                        "runId": {
                            "type": "string",
                            "description": "Optional host-owned supervisor run identity.",
                        },
                        "hostId": {
                            "type": "string",
                            "description": "Optional host identity for readback.",
                        },
                        "requestedBy": {
                            "type": "string",
                            "description": "Optional actor/requester identity.",
                        },
                        "statusReadbackAt": {
                            "type": "string",
                            "description": "Optional deterministic timestamp label for supervisor status readback.",
                        },
                        "cancellationSource": {
                            "type": "string",
                            "description": "Optional source label when policyCancelled is true.",
                        },
                        "cancellationReason": {
                            "type": "string",
                            "description": "Optional reason when policyCancelled is true.",
                        },
                        "maxCycles": {
                            "type": "integer",
                            "description": "Bounded harness max cycles per policy attempt. Default 1.",
                        },
                        "maxLoopFailures": {
                            "type": "integer",
                            "description": "Maximum loop failure stop reasons before the harness attempt stops. Default 1.",
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "Bounded loop max ticks for each lifecycle run-once. Default 1.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "Bounded loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "Runtime failure stop threshold. Default 1.",
                        },
                        "staleAfterSeconds": {
                            "type": "integer",
                            "description": "Optional heartbeat stale threshold in seconds for lifecycle inspection.",
                        },
                        "nowEpochSeconds": {
                            "type": "integer",
                            "description": "Optional deterministic current epoch seconds for deadline and stale inspection.",
                        },
                        "policyCancelled": {
                            "type": "boolean",
                            "description": "If true, supervisor stops before lifecycle control readback or scheduler mutation.",
                        },
                        "deadlineEpochSeconds": {
                            "type": "integer",
                            "description": "Optional deadline epoch seconds. Requires nowEpochSeconds.",
                        },
                        "maxAttempts": {
                            "type": "integer",
                            "description": "Maximum policy attempts. Default 1.",
                        },
                        "retryStopReasons": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Harness stop reasons that should be retried until maxAttempts.",
                        },
                    },
                    "required": ["supervisorId", "controlPath"],
                },
            ),
            Tool(
                name="schedulerSupervisorDogfoodWorkflow",
                description=(
                    "Run the deterministic fake-runtime supervisor dogfood "
                    "workflow: seed a scheduler fixture, admit it, start "
                    "lifecycle control, execute one host-managed supervisor "
                    "step, and read final scheduler/supervisor facts. This "
                    "does not start a daemon service, refresh scheduler "
                    "projection, run cleanup, or mutate agent-owned "
                    "local-work-trajectory.json."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "fixture": {
                            "type": "string",
                            "description": "Fixture selector: simple or multilane. Default simple.",
                        },
                        "artifactId": {
                            "type": "string",
                            "description": "Optional artifact id override for the seeded fixture.",
                        },
                        "version": {
                            "type": "string",
                            "description": "Optional fixture artifact version override.",
                        },
                        "artifactStorePath": {
                            "type": "string",
                            "description": "Optional ExchangeArtifact store path. Relative paths resolve under the MCP project root.",
                        },
                        "admissionLedgerPath": {
                            "type": "string",
                            "description": "Optional admission ledger path. Relative paths resolve under the MCP project root.",
                        },
                        "snapshotPath": {
                            "type": "string",
                            "description": "Optional scheduler snapshot path. Relative paths resolve under the MCP project root.",
                        },
                        "eventLogPath": {
                            "type": "string",
                            "description": "Optional scheduler event log path. Relative paths resolve under the MCP project root.",
                        },
                        "controlPath": {
                            "type": "string",
                            "description": "Optional scheduler daemon lifecycle control path. Relative paths resolve under the MCP project root.",
                        },
                        "runtimeProvider": {
                            "type": "string",
                            "description": "Runtime provider selector. Defaults to 'fake'; only 'fake' is accepted.",
                        },
                        "maxCycles": {
                            "type": "integer",
                            "description": "Bounded harness max cycles. Default 1.",
                        },
                        "maxLoopFailures": {
                            "type": "integer",
                            "description": "Maximum loop failure stop reasons before the harness attempt stops. Default 1.",
                        },
                        "maxTicks": {
                            "type": "integer",
                            "description": "Bounded loop max ticks. Default 3.",
                        },
                        "maxRunsPerTick": {
                            "type": "integer",
                            "description": "Bounded loop max task runs per tick. Default 1.",
                        },
                        "maxRuntimeFailures": {
                            "type": "integer",
                            "description": "Runtime failure stop threshold. Default 1.",
                        },
                        "maxAttempts": {
                            "type": "integer",
                            "description": "Maximum supervisor policy attempts. Default 1.",
                        },
                        "retryStopReasons": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Harness stop reasons that should be retried until maxAttempts.",
                        },
                        "allowDuplicateAdmission": {
                            "type": "boolean",
                            "description": "Allow duplicate exact artifact admission.",
                        },
                        "replaceExisting": {
                            "type": "boolean",
                            "description": "Replace an existing fixture artifact version in the store.",
                        },
                        "actor": {
                            "type": "string",
                            "description": "Admission actor label. Default mcp.",
                        },
                        "timestamp": {
                            "type": "string",
                            "description": "Optional deterministic timestamp for workflow steps.",
                        },
                        "createdAt": {
                            "type": "string",
                            "description": "Optional fixture artifact created_at timestamp.",
                        },
                        "daemonId": {
                            "type": "string",
                            "description": "Optional lifecycle daemon id.",
                        },
                        "lifecycleRunId": {
                            "type": "string",
                            "description": "Optional lifecycle run id.",
                        },
                        "supervisorId": {
                            "type": "string",
                            "description": "Optional host-owned supervisor identity.",
                        },
                        "sessionId": {
                            "type": "string",
                            "description": "Optional host-owned supervisor session identity.",
                        },
                        "runId": {
                            "type": "string",
                            "description": "Optional host-owned supervisor run identity.",
                        },
                        "hostId": {
                            "type": "string",
                            "description": "Optional host identity for readback.",
                        },
                        "requestedBy": {
                            "type": "string",
                            "description": "Optional actor/requester identity.",
                        },
                        "statusReadbackAt": {
                            "type": "string",
                            "description": "Optional deterministic timestamp label for supervisor status readback.",
                        },
                    },
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        import json

        if name == "governance_decide":
            result = tools.governance_decide(
                arguments["input_text"],
                scope_path=arguments.get("scope_path", ""),
                action_type=arguments.get("action_type", ""),
            )
        elif name == "check_constraints":
            result = tools.check_constraints()
        elif name == "get_next_action":
            result = tools.get_next_action()
        elif name == "workspaceDbcCommand":
            result = tools.workspace_dbc_command(
                arguments.get("argv"),
                mode=arguments.get("mode", "read"),
                timeout_seconds=arguments.get("timeoutSeconds", 30),
            )
        elif name == "readbackInspect":
            result = tools.readback_inspect(
                kind=arguments.get("kind", ""),
                path=arguments.get("path", ""),
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                source_kind=arguments.get("sourceKind", ""),
                latest_limit=arguments.get("latestLimit", 20),
                actor=arguments.get("actor", "readback-inspection-mcp"),
                timestamp=arguments.get("timestamp", ""),
            )
        elif name == "readbackTimelineInspect":
            result = tools.readback_timeline_inspect(
                sources=arguments.get("sources", []),
            )
        elif name == "writeback_notify":
            result = tools.writeback_notify(arguments["phase_description"])
        elif name == "get_pack_info":
            result = tools.get_info(
                scope_path=arguments.get("scope_path", ""),
                level=arguments.get("level", "manifest"),
            )
        elif name == "governance_override":
            action = arguments.get("action", "")
            result = tools.governance_override(
                action,
                constraint=arguments.get("constraint", ""),
                reason=arguments.get("reason", ""),
                scope=arguments.get("scope", "session"),
                override_id=arguments.get("override_id", ""),
            )
        elif name == "query_decision_logs":
            result = tools.query_decision_logs(
                trace_id=arguments.get("trace_id", ""),
                decision=arguments.get("decision", ""),
                intent=arguments.get("intent", ""),
                has_merge_conflicts=arguments.get("has_merge_conflicts"),
                limit=arguments.get("limit", 50),
            )
        elif name == "impact_analysis":
            result = tools.impact_analysis(
                changed_files=arguments.get("changed_files"),
                changed_symbols=arguments.get("changed_symbols"),
                max_depth=arguments.get("max_depth", 2),
            )
        elif name == "coupling_check":
            result = tools.coupling_check(
                changed_files=arguments.get("changed_files"),
                changed_symbols=arguments.get("changed_symbols"),
            )
        elif name == "analyze_changes":
            result = tools.analyze_changes(
                changed_files=arguments.get("changed_files"),
                changed_symbols=arguments.get("changed_symbols"),
                max_depth=arguments.get("max_depth", 2),
            )
        elif name == "promote_dogfood_evidence":
            result = tools.promote_dogfood_evidence(
                symptoms=arguments.get("symptoms", []),
                existing_issue_ids=arguments.get("existing_issue_ids"),
                date=arguments.get("date", ""),
                judgment=arguments.get("judgment", ""),
                next_step_implication=arguments.get("next_step_implication", ""),
                confidence=arguments.get("confidence", "medium"),
                non_goals=arguments.get("non_goals"),
                supersedes=arguments.get("supersedes"),
                auto_writeback=arguments.get("auto_writeback", False),
                active_gate_path=arguments.get("active_gate_path"),
            )
        elif name == "workflow_interrupt":
            result = tools.workflow_interrupt(
                reason=arguments["reason"],
                discovered_item=arguments["discovered_item"],
                current_scope_ref=arguments.get("current_scope_ref", ""),
            )
        elif name == "update_user_config":
            from ..pack.user_config import save_user_config
            from ..workflow.pipeline import _user_global_base_dir

            try:
                user_dir = _user_global_base_dir()
                result = save_user_config(
                    user_dir,
                    field=arguments["field"],
                    value=arguments["value"],
                )
            except (ValueError, OSError) as exc:
                result = {"error": str(exc)}
        elif name == "pack_lock":
            result = tools.pack_lock(pack_name=arguments.get("pack_name", ""))
        elif name == "pack_unlock":
            result = tools.pack_unlock(pack_name=arguments["pack_name"])
        elif name == "pack_verify":
            result = tools.pack_verify(pack_name=arguments.get("pack_name", ""))
        elif name == "check_reply_progression":
            from ..workflow.reply_progression import check_reply_progression
            result = check_reply_progression(arguments["reply_text"]).to_dict()
        elif name == "localTrajectory":
            result = tools.local_trajectory(
                arguments["action"],
                lane_label=arguments.get("laneLabel", ""),
                first_event_title=arguments.get("firstEventTitle", ""),
                title=arguments.get("title", ""),
                event_kind=arguments.get("eventKind", ""),
                summary=arguments.get("summary", ""),
                guide_context=arguments.get("guideContext", ""),
                current_event_id=arguments.get("currentEventId", ""),
                reason=arguments.get("reason", ""),
                lane_id=arguments.get("laneId", ""),
                lanes=arguments.get("lanes"),
                source_event_id=arguments.get("sourceEventId", ""),
                source_lane_id=arguments.get("sourceLaneId", ""),
                target_lane_id=arguments.get("targetLaneId", ""),
                target_event_id=arguments.get("targetEventId", ""),
                relation_kind=arguments.get("relationKind", ""),
                first_child_event_title=arguments.get("firstChildEventTitle", ""),
                child_lane_label=arguments.get("childLaneLabel", ""),
                range_start_event_id=arguments.get("rangeStartEventId", ""),
                range_end_event_id=arguments.get("rangeEndEventId", ""),
                pack_ranges=arguments.get("packRanges"),
                anchor_lane_id=arguments.get("anchorLaneId", ""),
                parent_event_id=arguments.get("parentEventId", ""),
                child_trajectory_id=arguments.get("childTrajectoryId", ""),
                source_endpoint_trajectory_id=arguments.get("sourceEndpointTrajectoryId", ""),
                source_endpoint_event_id=arguments.get("sourceEndpointEventId", ""),
                source_endpoint_parent_event_id=arguments.get("sourceEndpointParentEventId", ""),
                source_endpoint_compound_path=arguments.get("sourceEndpointCompoundPath", ""),
                target_endpoint_trajectory_id=arguments.get("targetEndpointTrajectoryId", ""),
                target_endpoint_event_id=arguments.get("targetEndpointEventId", ""),
                target_endpoint_parent_event_id=arguments.get("targetEndpointParentEventId", ""),
                target_endpoint_compound_path=arguments.get("targetEndpointCompoundPath", ""),
                source_graph_id=arguments.get("sourceGraphId", ""),
                source_node_id=arguments.get("sourceNodeId", ""),
                caller_role=arguments.get("callerRole", ""),
            )
        elif name == "consumeWorkerTrajectoryReport":
            result = tools.consume_worker_trajectory_report(
                report_path=arguments.get("reportPath", ""),
                caller_role=arguments.get("callerRole", "leader"),
                actor=arguments.get("actor", "leader"),
                current_event_id=arguments.get("currentEventId", ""),
                title=arguments.get("title", ""),
                event_kind=arguments.get("eventKind", "task"),
                start_if_missing=arguments.get("startIfMissing", True),
                trajectory_title=arguments.get("trajectoryTitle", "Local Work Trajectory"),
                guide_context=arguments.get("guideContext", "worker-trajectory-report-consumer"),
            )
        elif name == "trajectoryTeamContinuity":
            result = tools.trajectory_team_continuity(
                action=arguments.get("action", ""),
                caller_role=arguments.get("callerRole", "leader"),
                trajectory_id=arguments.get("trajectoryId", ""),
                lane_id=arguments.get("laneId", ""),
                leader_id=arguments.get("leaderId", "agent:guide"),
                worker_id=arguments.get("workerId", ""),
                runtime_provider=arguments.get("runtimeProvider", "opencode"),
                binding_id=arguments.get("bindingId", ""),
                ownership_id=arguments.get("ownershipId", ""),
                replacement_binding_id=arguments.get("replacementBindingId", ""),
                new_binding_id=arguments.get("newBindingId", ""),
                source_binding_id=arguments.get("sourceBindingId", ""),
                no_continuity_reason=arguments.get("noContinuityReason", ""),
                task_id=arguments.get("taskId", ""),
                delivery_id=arguments.get("deliveryId", ""),
                timestamp=arguments.get("timestamp", ""),
                reason=arguments.get("reason", ""),
                binding_ledger_path=arguments.get("bindingLedgerPath", ""),
                binding_event_log_path=arguments.get("bindingEventLogPath", ""),
                ownership_ledger_path=arguments.get("ownershipLedgerPath", ""),
                ownership_event_log_path=arguments.get("ownershipEventLogPath", ""),
                lease_ledger_path=arguments.get("leaseLedgerPath", ""),
                team_event_log_path=arguments.get("teamEventLogPath", ""),
                scheduler_event_log_path=arguments.get("schedulerEventLogPath", ""),
                attach_url=arguments.get("attachUrl", ""),
                session_id=arguments.get("sessionId", ""),
                continue_session=arguments.get("continueSession", False),
                fork_session=arguments.get("forkSession", False),
                compact_context_ref=arguments.get("compactContextRef", ""),
                mailbox_cursor_ref=arguments.get("mailboxCursorRef", ""),
                worker_report_refs=arguments.get("workerReportRefs"),
                audit_refs=arguments.get("auditRefs"),
                include_inactive=arguments.get("includeInactive", True),
            )
        elif name == "schedulerProjection":
            result = tools.scheduler_projection(
                snapshot_path=arguments.get("snapshotPath", ""),
                scheduler_event_log_path=arguments.get("schedulerEventLogPath", ""),
                merge_gate_event_log_path=arguments.get("mergeGateEventLogPath", ""),
                output_path=arguments.get("outputPath", ""),
                trajectory_id=arguments.get("trajectoryId", ""),
                title=arguments.get("title", ""),
                guide_context=arguments.get("guideContext", ""),
                source_graph_id=arguments.get("sourceGraphId", ""),
                source_node_id=arguments.get("sourceNodeId", ""),
            )
        elif name == "schedulerSubmitTasks":
            result = tools.scheduler_submit_tasks(
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                batch=arguments.get("batch"),
                batch_id=arguments.get("batchId", ""),
                tasks=arguments.get("tasks"),
                title=arguments.get("title", ""),
                summary=arguments.get("summary", ""),
                artifact_id=arguments.get("artifactId", ""),
                artifact_version=arguments.get("artifactVersion", "v1"),
                producer=arguments.get("producer", "schedulerSubmitTasks"),
                timestamp=arguments.get("timestamp", ""),
                replace_existing=arguments.get("replaceExisting", False),
            )
        elif name == "admitExchangeArtifact":
            result = tools.admit_exchange_artifact(
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                allow_duplicate_admission=arguments.get("allowDuplicateAdmission", False),
                replace_existing=arguments.get("replaceExisting", False),
                mark_consumed_on_success=arguments.get("markConsumedOnSuccess", False),
                actor=arguments.get("actor", "mcp"),
                timestamp=arguments.get("timestamp", ""),
            )
        elif name == "schedulerBindingReferenceInspect":
            result = tools.scheduler_binding_reference_inspect(
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
            )
        elif name == "agentExchangeMailbox":
            result = tools.agent_exchange_mailbox(
                agent_id=arguments.get("agentId", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                include_archived=arguments.get("includeArchived", False),
            )
        elif name == "agentExchangeHistory":
            result = tools.agent_exchange_history(
                agent_id=arguments.get("agentId", ""),
                correlation_id=arguments.get("correlationId", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                include_archived=arguments.get("includeArchived", False),
            )
        elif name == "agentExchangeActionCandidates":
            result = tools.agent_exchange_action_candidates(
                agent_id=arguments.get("agentId", ""),
                candidate_type=arguments.get("candidateType", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                include_archived=arguments.get("includeArchived", False),
            )
        elif name == "agentExchangeActionCandidateDecide":
            result = tools.agent_exchange_action_candidate_decide(
                candidate_id=arguments.get("candidateId", ""),
                disposition_artifact_id=arguments.get("dispositionArtifactId", ""),
                disposition_version=arguments.get("dispositionVersion", "v1"),
                actor=arguments.get("actor", ""),
                disposition=arguments.get("disposition", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                reason=arguments.get("reason", ""),
                target_surface=arguments.get("targetSurface", ""),
                replacement_artifact_id=arguments.get("replacementArtifactId", ""),
                replacement_version=arguments.get("replacementVersion", ""),
                timestamp=arguments.get("timestamp", ""),
                replace_existing=arguments.get("replaceExisting", False),
            )
        elif name == "agentExchangeAcceptedSchedulerCandidateConsume":
            result = tools.agent_exchange_accepted_scheduler_candidate_consume(
                disposition_artifact_id=arguments.get("dispositionArtifactId", ""),
                disposition_version=arguments.get("dispositionVersion", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                allow_duplicate_admission=arguments.get("allowDuplicateAdmission", False),
                replace_existing=arguments.get("replaceExisting", False),
                validate_binding_artifact_refs=arguments.get("validateBindingArtifactRefs", False),
                mark_consumed_on_success=arguments.get("markConsumedOnSuccess", False),
                actor=arguments.get("actor", "mcp"),
                timestamp=arguments.get("timestamp", ""),
            )
        elif name == "agentExchangeAcceptedReviewCandidateConsume":
            result = tools.agent_exchange_accepted_review_candidate_consume(
                disposition_artifact_id=arguments.get("dispositionArtifactId", ""),
                disposition_version=arguments.get("dispositionVersion", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                actor=arguments.get("actor", "mcp"),
            )
        elif name == "agentExchangeAcceptedHandoffCandidateConsume":
            result = tools.agent_exchange_accepted_handoff_candidate_consume(
                disposition_artifact_id=arguments.get("dispositionArtifactId", ""),
                disposition_version=arguments.get("dispositionVersion", ""),
                handoff_dir=arguments.get("handoffDir", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                actor=arguments.get("actor", "mcp"),
            )
        elif name == "agentExchangeAcceptedMergeCandidateConsume":
            result = tools.agent_exchange_accepted_merge_candidate_consume(
                disposition_artifact_id=arguments.get("dispositionArtifactId", ""),
                disposition_version=arguments.get("dispositionVersion", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                gate_id=arguments.get("gateId", ""),
                approved=arguments.get("approved"),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                merge_gate_event_log_path=arguments.get("mergeGateEventLogPath", ""),
                reason=arguments.get("reason", ""),
                actor=arguments.get("actor", "mcp"),
                resolved_at=arguments.get("resolvedAt", ""),
                timestamp=arguments.get("timestamp", ""),
            )
        elif name == "agentExchangeAcceptedBlockerCandidateConsume":
            result = tools.agent_exchange_accepted_blocker_candidate_consume(
                disposition_artifact_id=arguments.get("dispositionArtifactId", ""),
                disposition_version=arguments.get("dispositionVersion", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                task_id=arguments.get("taskId", ""),
                reason=arguments.get("reason", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                actor=arguments.get("actor", "mcp"),
                timestamp=arguments.get("timestamp", ""),
            )
        elif name == "agentExchangeReply":
            result = tools.agent_exchange_reply(
                source_artifact_id=arguments.get("sourceArtifactId", ""),
                source_version=arguments.get("sourceVersion", ""),
                reply_artifact_id=arguments.get("replyArtifactId", ""),
                reply_version=arguments.get("replyVersion", "v1"),
                producer=arguments.get("producer", ""),
                text=arguments.get("text", ""),
                structured=arguments.get("structured"),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                kind=arguments.get("kind", "message"),
                intent=arguments.get("intent", "inform"),
                audience=tuple(arguments.get("audience", ()))
                if arguments.get("audience")
                else (),
                created_at=arguments.get("createdAt", ""),
                replace_existing=arguments.get("replaceExisting", False),
            )
        elif name == "agentExchangeTransition":
            result = tools.agent_exchange_transition(
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                target_state=arguments.get("targetState", ""),
                actor=arguments.get("actor", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                reason=arguments.get("reason", ""),
                timestamp=arguments.get("timestamp", ""),
            )
        elif name == "schedulerStorageBindingArtifactPublish":
            result = tools.scheduler_storage_binding_artifact_publish(
                evidence_path=arguments.get("evidencePath", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", "v1"),
                producer=arguments.get("producer", ""),
                audience=tuple(arguments.get("audience", ()))
                if arguments.get("audience")
                else ("scheduler", "workspace-registration"),
                created_at=arguments.get("createdAt", ""),
                replace_existing=arguments.get("replaceExisting", False),
            )
        elif name == "schedulerRunOnceAndProject":
            result = tools.scheduler_run_once_and_project(
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                merge_gate_event_log_path=arguments.get("mergeGateEventLogPath", ""),
                output_path=arguments.get("outputPath", ""),
                max_runs=arguments.get("maxRuns"),
                timestamp=arguments.get("timestamp", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                guide_context=arguments.get("guideContext", ""),
                source_graph_id=arguments.get("sourceGraphId", ""),
                source_node_id=arguments.get("sourceNodeId", ""),
            )
        elif name == "schedulerAuthorizationReadback":
            result = tools.scheduler_authorization_readback(
                snapshot_path=arguments.get("snapshotPath", ""),
                scheduler_event_log_path=arguments.get("schedulerEventLogPath", ""),
                strict=arguments.get("strict", True),
                workspace_root=arguments.get("workspaceRoot", ""),
                scratch_root=arguments.get("scratchRoot", ".dbc/scratch"),
            )
        elif name == "schedulerCleanupReceipts":
            result = tools.scheduler_cleanup_receipts(
                input_evidence_path=arguments.get("inputEvidencePath", ""),
                output_evidence_path=arguments.get("outputEvidencePath", ""),
                output_evidence_id=arguments.get("outputEvidenceId", ""),
                timestamp=arguments.get("timestamp", ""),
                git_executable=arguments.get("gitExecutable", "git"),
            )
        elif name == "schedulerOperatorWorkflow":
            result = tools.scheduler_operator_workflow(
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                admit=arguments.get("admit", False),
                run_loop=arguments.get("runLoop", False),
                refresh_projection=arguments.get("refreshProjection", False),
                inspect_binding_refs=arguments.get("inspectBindingRefs", False),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                merge_gate_event_log_path=arguments.get("mergeGateEventLogPath", ""),
                projection_output_path=arguments.get("projectionOutputPath", ""),
                evidence_id=arguments.get("evidenceId", ""),
                evidence_path=arguments.get("evidencePath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                max_ticks=arguments.get("maxTicks", 3),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
                allow_duplicate_admission=arguments.get("allowDuplicateAdmission", False),
                replace_existing=arguments.get("replaceExisting", False),
                mark_consumed_on_success=arguments.get("markConsumedOnSuccess", False),
                actor=arguments.get("actor", "mcp"),
                timestamp=arguments.get("timestamp", ""),
                guide_context=arguments.get("guideContext", ""),
                source_graph_id=arguments.get("sourceGraphId", ""),
                source_node_id=arguments.get("sourceNodeId", ""),
            )
        elif name == "schedulerOperatorDogfoodClosure":
            result = tools.scheduler_operator_dogfood_closure(
                fixture=arguments.get("fixture", "binding-consumer"),
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                merge_gate_event_log_path=arguments.get("mergeGateEventLogPath", ""),
                projection_output_path=arguments.get("projectionOutputPath", ""),
                evidence_id=arguments.get("evidenceId", ""),
                evidence_path=arguments.get("evidencePath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                max_ticks=arguments.get("maxTicks", 3),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
                replace_existing=arguments.get("replaceExisting", False),
                inspect_binding_refs=arguments.get("inspectBindingRefs", True),
                mark_consumed_on_success=arguments.get("markConsumedOnSuccess", True),
                actor=arguments.get("actor", "mcp"),
                timestamp=arguments.get("timestamp", ""),
                created_at=arguments.get("createdAt", ""),
                guide_context=arguments.get("guideContext", ""),
                source_graph_id=arguments.get("sourceGraphId", ""),
                source_node_id=arguments.get("sourceNodeId", ""),
            )
        elif name == "schedulerGuideWorkerLocalOrchestration":
            result = tools.scheduler_guide_worker_local_orchestration(
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                trajectory_id=arguments.get("trajectoryId", "local-work:current"),
                guide_agent_id=arguments.get("guideAgentId", "agent:guide"),
                worker_agent_id=arguments.get("workerAgentId", "agent:worker"),
                artifact_id_prefix=arguments.get("artifactIdPrefix", ""),
                worker_instructions=arguments.get("workerInstructions"),
                guide_task=arguments.get("guideTask"),
                planner_lane_specs=arguments.get("plannerLaneSpecs"),
                max_parallel_lanes=arguments.get("maxParallelLanes", 2),
                max_waves=arguments.get("maxWaves", 1),
                replace_existing=arguments.get("replaceExisting", False),
                allow_duplicate_admission=arguments.get("allowDuplicateAdmission", False),
                timestamp=arguments.get("timestamp", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                workspace_root=arguments.get("workspaceRoot", ""),
                scratch_root=arguments.get("scratchRoot", ".dbc/scratch"),
                wave_execution_mode=arguments.get("waveExecutionMode", "serial"),
            )
        elif name == "schedulerSandboxReceiptWorkflow":
            result = tools.scheduler_sandbox_receipt_workflow(
                mode=arguments.get("mode", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                workspace_root=arguments.get("workspaceRoot", ""),
                git_worktree_sandbox_root=arguments.get("gitWorktreeSandboxRoot", ""),
                allocation_evidence_id=arguments.get("allocationEvidenceId", ""),
                allocation_evidence_path=arguments.get("allocationEvidencePath", ""),
                cleanup=arguments.get("cleanup", False),
                cleanup_evidence_id=arguments.get("cleanupEvidenceId", ""),
                cleanup_evidence_path=arguments.get("cleanupEvidencePath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                max_runs=arguments.get("maxRuns", 1),
                max_ticks=arguments.get("maxTicks", 1),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
                timestamp=arguments.get("timestamp", ""),
                git_executable=arguments.get("gitExecutable", "git"),
            )
        elif name == "schedulerLifecycleControl":
            result = tools.scheduler_lifecycle_control(
                action=arguments.get("action", ""),
                control_path=arguments.get("controlPath", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                daemon_id=arguments.get("daemonId", ""),
                run_id=arguments.get("runId", ""),
                timestamp=arguments.get("timestamp", ""),
                stale_after_seconds=arguments.get("staleAfterSeconds"),
                now_epoch_seconds=arguments.get("nowEpochSeconds"),
            )
        elif name == "schedulerLifecycleRunOnce":
            result = tools.scheduler_lifecycle_run_once(
                control_path=arguments.get("controlPath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                timestamp=arguments.get("timestamp", ""),
                max_ticks=arguments.get("maxTicks", 1),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
            )
        elif name == "schedulerLifecycleHarness":
            result = tools.scheduler_lifecycle_harness(
                control_path=arguments.get("controlPath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                timestamp=arguments.get("timestamp", ""),
                max_cycles=arguments.get("maxCycles", 1),
                max_loop_failures=arguments.get("maxLoopFailures", 1),
                max_ticks=arguments.get("maxTicks", 1),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
                stale_after_seconds=arguments.get("staleAfterSeconds"),
                now_epoch_seconds=arguments.get("nowEpochSeconds"),
                policy_cancelled=arguments.get("policyCancelled", False),
                deadline_epoch_seconds=arguments.get("deadlineEpochSeconds"),
                max_attempts=arguments.get("maxAttempts", 1),
                retry_stop_reasons=arguments.get("retryStopReasons"),
            )
        elif name == "schedulerDaemonSupervisorStep":
            result = tools.scheduler_daemon_supervisor_step(
                supervisor_id=arguments.get("supervisorId", ""),
                control_path=arguments.get("controlPath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                timestamp=arguments.get("timestamp", ""),
                session_id=arguments.get("sessionId", ""),
                run_id=arguments.get("runId", ""),
                host_id=arguments.get("hostId", ""),
                requested_by=arguments.get("requestedBy", ""),
                status_readback_at=arguments.get("statusReadbackAt", ""),
                cancellation_source=arguments.get("cancellationSource", ""),
                cancellation_reason=arguments.get("cancellationReason", ""),
                max_cycles=arguments.get("maxCycles", 1),
                max_loop_failures=arguments.get("maxLoopFailures", 1),
                max_ticks=arguments.get("maxTicks", 1),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
                stale_after_seconds=arguments.get("staleAfterSeconds"),
                now_epoch_seconds=arguments.get("nowEpochSeconds"),
                policy_cancelled=arguments.get("policyCancelled", False),
                deadline_epoch_seconds=arguments.get("deadlineEpochSeconds"),
                max_attempts=arguments.get("maxAttempts", 1),
                retry_stop_reasons=arguments.get("retryStopReasons"),
            )
        elif name == "schedulerSupervisorDogfoodWorkflow":
            result = tools.scheduler_supervisor_dogfood_workflow(
                fixture=arguments.get("fixture", "simple"),
                artifact_id=arguments.get("artifactId", ""),
                version=arguments.get("version", ""),
                artifact_store_path=arguments.get("artifactStorePath", ""),
                admission_ledger_path=arguments.get("admissionLedgerPath", ""),
                snapshot_path=arguments.get("snapshotPath", ""),
                event_log_path=arguments.get("eventLogPath", ""),
                control_path=arguments.get("controlPath", ""),
                runtime_provider=arguments.get("runtimeProvider", "fake"),
                max_cycles=arguments.get("maxCycles", 1),
                max_loop_failures=arguments.get("maxLoopFailures", 1),
                max_ticks=arguments.get("maxTicks", 3),
                max_runs_per_tick=arguments.get("maxRunsPerTick", 1),
                max_runtime_failures=arguments.get("maxRuntimeFailures", 1),
                max_attempts=arguments.get("maxAttempts", 1),
                retry_stop_reasons=arguments.get("retryStopReasons"),
                allow_duplicate_admission=arguments.get("allowDuplicateAdmission", False),
                replace_existing=arguments.get("replaceExisting", False),
                actor=arguments.get("actor", "mcp"),
                timestamp=arguments.get("timestamp", ""),
                created_at=arguments.get("createdAt", ""),
                daemon_id=arguments.get("daemonId", ""),
                lifecycle_run_id=arguments.get("lifecycleRunId", ""),
                supervisor_id=arguments.get("supervisorId", ""),
                session_id=arguments.get("sessionId", ""),
                run_id=arguments.get("runId", ""),
                host_id=arguments.get("hostId", ""),
                requested_by=arguments.get("requestedBy", ""),
                status_readback_at=arguments.get("statusReadbackAt", ""),
            )
        else:
            result = {"error": f"Unknown tool: {name}"}

        text = json.dumps(result, indent=2, ensure_ascii=False, default=str)
        return [TextContent(type="text", text=text)]

    # ── Prompts ────────────────────────────────────────────────────────

    @server.list_prompts()
    async def list_prompts() -> list[Prompt]:
        prompt_list = tools.list_prompts()
        return [
            Prompt(
                name=p["name"],
                description=p.get("description", ""),
                arguments=[],
            )
            for p in prompt_list
        ]

    @server.get_prompt()
    async def get_prompt(name: str, arguments: dict[str, str] | None = None) -> GetPromptResult:
        content = tools.get_prompt(name)
        if content is None:
            return GetPromptResult(
                description=f"Prompt '{name}' not found",
                messages=[
                    PromptMessage(
                        role="user",
                        content=TextContent(type="text", text=f"Prompt '{name}' not found."),
                    )
                ],
            )
        return GetPromptResult(
            description=f"Pack prompt: {name}",
            messages=[
                PromptMessage(
                    role="user",
                    content=TextContent(type="text", text=content),
                )
            ],
        )

    # ── Resources ──────────────────────────────────────────────────────

    @server.list_resources()
    async def list_resources() -> list[Resource]:
        resource_list = tools.list_resources()
        return [
            Resource(
                uri=r["uri"],
                name=r.get("name", r["uri"]),
                description=r.get("description", ""),
                mimeType=r.get("mimeType", "text/plain"),
            )
            for r in resource_list
        ]

    @server.read_resource()
    async def read_resource(uri: str) -> str | bytes:
        content = tools.read_resource(str(uri))
        if content is None:
            return f"Resource '{uri}' not found."
        return content

    return server


async def run_stdio(project_root: Path, *, dry_run: bool = True) -> None:
    """Run MCP server over stdio transport."""
    server = create_server(project_root, dry_run=dry_run)
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> None:
    parser = argparse.ArgumentParser(description="Doc-based-coding governance MCP server")
    parser.add_argument(
        "--project", type=str, default=None,
        help="Project root directory (auto-detected if not set)",
    )
    parser.add_argument(
        "--dry-run", action="store_true", default=True,
        help="Run in dry-run mode (no file writes, default)",
    )
    parser.add_argument(
        "--no-dry-run", action="store_true", default=False,
        help="Run in live mode (file writes enabled)",
    )
    args = parser.parse_args()

    project_root = Path(args.project) if args.project else _find_project_root()
    dry_run = not args.no_dry_run

    import asyncio
    asyncio.run(run_stdio(project_root, dry_run=dry_run))


if __name__ == "__main__":
    main()
