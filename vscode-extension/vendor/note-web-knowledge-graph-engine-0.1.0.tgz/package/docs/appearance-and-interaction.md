# Appearance And Interaction API

This document describes the product-facing customization contract for `Canvas2DRenderer`.

The preferred API is:

```js
const renderer = new Canvas2DRenderer({
  canvas,
  model,
  getAppearance: () => appearance,
  interaction,
  events
});
```

Legacy options such as `theme`, `getTheme`, `getDisplayOptions`, `onNodeClick`, and `onNodeSelect` are still supported for compatibility, but new integrations should prefer `appearance`, `interaction`, and `events`.

## Appearance

`appearance` controls visual styling, hit testing, viewport behavior, and optional per-item style hooks.

```js
const appearance = {
  display: {
    showArrows: true,
    textFade: 0.6,
    nodeSize: 1,
    linkThickness: 1
  },
  hitTest: {
    minRadius: 9,
    padding: 4
  },
  viewport: {
    fitPadding: 64,
    minScale: 0.18,
    maxScale: 3.6,
    zoomStep: 1.2
  },
  labelPolicy: {
    mode: "density",
    density: 0.7,
    priority: "degree",
    textFade: 0.6
  },
  nodeSizePolicy: {
    mode: "metric",
    priority: "degree",
    minScale: 1,
    maxScale: 1.9,
    strength: 0.32
  },
  theme: {
    canvas: {
      background: "#101318"
    },
    node: {
      fill: "#7dd3fc",
      stroke: "rgba(255,255,255,0.16)",
      hoverFill: "#ffd166",
      hoverStroke: "#fff4c2",
      selectedFill: "#f8fafc",
      selectedStroke: "#38bdf8",
      dimmedFill: "rgba(74, 86, 103, 0.2)",
      dimmedStroke: "rgba(255,255,255,0.05)",
      accentRingColor: "#38bdf8",
      accentRingWidth: 2,
      accentByStatus: {
        blocked: "#ef4444",
        done: "#22c55e",
        running: "#38bdf8"
      }
    },
    link: {
      defaultColor: "rgba(120, 138, 160, 0.28)",
      activeColor: "rgba(82, 169, 255, 0.78)",
      dimmedColor: "rgba(93, 107, 124, 0.08)",
      byKind: {
        blocks: "rgba(251, 113, 133, 0.52)"
      }
    },
    label: {
      color: "rgba(247, 249, 251, 0.96)",
      dimmedColor: "rgba(247, 249, 251, 0.18)",
      font: "",
      fontFamily: "-apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
      fontSize: 12,
      fontStyle: "normal",
      fontWeight: 400,
      density: 1
    }
  }
};
```

Use `getAppearance` when controls can change at runtime:

```js
const renderer = new Canvas2DRenderer({
  canvas,
  model,
  getAppearance: () => ({
    ...appearance,
    display: currentDisplayOptions
  })
});
```

## Style Hooks

Style hooks let the host customize individual nodes, links, and labels without forking the renderer.

```js
const appearance = {
  hooks: {
    getNodeStyle({ node, flags, style }) {
      if (node.colorGroupId === "bound") {
        return { ...style, stroke: "#c4b5fd", strokeWidth: 2.4 };
      }
      return style;
    },
    getLinkStyle({ link, flags, style }) {
      if (link.kind === "blocks") {
        return { ...style, width: 2 };
      }
      return style;
    },
    getLabelStyle({ node, flags, style }) {
      if (flags.isSelected) {
        return { ...style, color: "#ffffff" };
      }
      return style;
    }
  }
};
```

`flags` can include:

- `isSelected`
- `isHovered`
- `isMatch`
- `dimmed`
- `active`
- `alpha`

## Label Policy

Labels are controlled through `appearance.labelPolicy` and `appearance.theme.label`.

```js
const appearance = {
  labelPolicy: {
    mode: "density",
    density: 0.5,
    priority: "degree",
    textFade: 0.6
  },
  theme: {
    label: {
      fontSize: 13,
      fontWeight: 600,
      fontFamily: "Inter, Segoe UI, sans-serif",
      color: "rgba(247, 249, 251, 0.96)"
    }
  }
};
```

`mode` supports:

| Mode | Behavior |
| --- | --- |
| `"density"` | Draw sampled normal labels; selected, hovered, and highlighted labels are always drawn. |
| `"all"` | Draw all labels. |
| `"none"` | Draw no labels. |
| `"active-neighborhood"` | Draw only selected, hovered, or highlighted labels. |

Empty search query means no search highlight; it does not mark every node as matched. This keeps density sampling predictable when no query is active.

`textFade` and `density` are independent:

- `textFade` hides normal labels below a zoom threshold.
- `density` samples normal labels when labels are otherwise allowed.
- selected, hovered, and highlighted labels bypass both controls.

Density sampling is stable and count-linear. The renderer assigns each normal
label candidate a priority order, then allocates a linear label budget from
`density * candidateCount`. Increasing `density` gradually adds labels in that
order; the boundary label fades in when the budget has a fractional part.

`priority` controls which normal labels receive the budget first:

| Priority | Behavior |
| --- | --- |
| `"degree"` | Default. Nodes with more incident links receive labels first; ties use stable identity rank. |
| `"stable"` | Use only stable identity rank from node `id` or `label`. |
| `(node, context) => number` | Custom score; higher scores receive labels first. `context.degree` contains the node's incident link count. |

## Node Size Policy

Node size is controlled by the node's base `radius`, `appearance.display.nodeSize`, and `appearance.nodeSizePolicy`.

```js
const appearance = {
  display: {
    nodeSize: 1.2
  },
  nodeSizePolicy: {
    mode: "metric",
    priority: "degree",
    minScale: 1,
    maxScale: 1.9,
    strength: 0.32
  }
};
```

Default behavior is degree-based: nodes with more incident links are drawn larger. The renderer applies the same resolved radius to drawing, hit testing, arrow placement, label offset, and viewport fitting, so the visual node and interactive node stay bound together.

`mode` supports:

| Mode | Behavior |
| --- | --- |
| `"metric"` | Scale each node by a metric. This is the default. |
| `"fixed"` | Do not apply metric scaling; only use `node.radius * display.nodeSize`. |

`priority` supports:

| Priority | Behavior |
| --- | --- |
| `"degree"` | Default. Use incident link count as the size metric. |
| `"none"` | Equivalent to zero metric; useful when keeping the policy object but disabling scaling. |
| `(node, context) => number` | Custom score; higher scores draw larger. `context.degree` contains the node's incident link count. |

The multiplier is computed with a damped logarithmic curve and clamped between `minScale` and `maxScale`, so hubs stand out without overwhelming the graph.

## Canvas Font Safety

The renderer builds a canvas-safe `ctx.font` from `appearance.theme.label`.

```js
import { resolveCanvasFont } from "@note-web/knowledge-graph-engine";

resolveCanvasFont({
  fontSize: 14,
  fontWeight: 600,
  fontFamily: "Inter, Segoe UI, sans-serif"
});
```

If `label.font` is a valid canvas shorthand, it is used first. If it is invalid, or if `fontFamily` contains CSS variables or unsafe fragments, the renderer falls back to the default canvas-safe font family.

Read the resolved label options for diagnostics:

```js
const resolved = renderer.getResolvedAppearance();
console.log(resolved.label.font, resolved.label.mode, resolved.label.density);
```

`events.onStatus` also receives `resolvedAppearance`:

```js
events: {
  onStatus({ statusText, resolvedAppearance }) {
    console.log(statusText, resolvedAppearance.label);
  }
}
```

## Interaction

`interaction` controls behavior policy.

```js
const interaction = {
  selectedNodeId: "selection",
  hoveredNodeId: null,
  selectOnClick: true,
  openOn: "double-click",
  clearSelectionOnCanvasClick: true,
  hover: true,
  dragNodes: true,
  panCanvas: true,
  zoomCanvas: true
};
```

`openOn` supports:

| Value | Behavior |
| --- | --- |
| `"legacy"` | Backward-compatible behavior. Single click opens when no structured click/select callback is installed. |
| `"click"` | Single click emits open. |
| `"double-click"` | Double-click emits open. |
| `"none"` | Open is disabled. |

Update controlled selection or hover with:

```js
renderer.setInteractionState({
  selectedNodeId: "preview",
  hoveredNodeId: null
});
```

## Events

Use `events` for standardized payloads:

```js
const events = {
  onNodeClick(event) {},
  onNodeDoubleClick(event) {},
  onNodeSelect(event) {},
  onNodeHover(event) {},
  onNodeDrag(event) {},
  onNodeRelease(event) {},
  onNodeOpen(event) {},
  onStatus(event) {}
};
```

Node event payload:

```ts
type GraphRendererEvent = {
  type: string;
  node: GraphNode | null;
  nodeId: string | null;
  model: GraphModel;
  renderer: Canvas2DRenderer;
  sourceEvent: Event | null;
  worldPoint: { x: number; y: number } | null;
  viewport: {
    scale: number;
    panX: number;
    panY: number;
  };
};
```

Drag payload also includes:

```ts
{
  point: { x: number; y: number };
  alpha: number;
}
```

Open payload includes:

```ts
{
  trigger: "click" | "double-click";
}
```

Status payload includes:

```ts
{
  statusText: string;
}
```

## Recommended Product Pattern

For product integrations such as a VS Code webview preview:

```js
const renderer = new Canvas2DRenderer({
  canvas,
  model,
  getAppearance: () => ({
    theme: currentTheme,
    display: currentDisplayOptions,
    viewport: currentViewportOptions,
    hooks: productStyleHooks
  }),
  interaction: {
    selectedNodeId,
    hoveredNodeId,
    selectOnClick: true,
    openOn: "double-click"
  },
  events: {
    onNodeSelect({ nodeId }) {
      selectedNodeId = nodeId;
      renderDetails(nodeId);
      renderer.setInteractionState({ selectedNodeId });
    },
    onNodeHover({ nodeId }) {
      hoveredNodeId = nodeId;
      renderer.setInteractionState({ hoveredNodeId }, { render: false });
    },
    onNodeOpen({ node }) {
      openNode(node);
    }
  }
});
```

This keeps visual design, behavior policy, and host-specific actions outside the renderer core while still giving the renderer enough structure to provide consistent interaction.
