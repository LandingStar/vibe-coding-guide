# 关系图谱组件使用指南

本文档说明如何在浏览器应用中使用 `knowledge-graph-engine` 组件，实现资料关系图谱的构建、布局、渲染和交互。

## 1. 组件能力

当前组件提供四个主要能力：

| API | 作用 |
| --- | --- |
| `buildLibraryGraph` | 将资料列表转换为图谱数据 |
| `GraphModel` | 管理节点、边、坐标和搜索高亮 |
| `SimulationClient` | 启动和控制 Web Worker 力导向布局 |
| `Canvas2DRenderer` | 在 Canvas 上渲染图谱并处理交互 |
| `normalizeGraph` | 标准化通用 `{ nodes, links }` 输入 |
| `createSimulationClient` | 创建布局客户端，便于宿主约定 worker lifecycle |
| `resolveColorGroupColor` | 按 Obsidian Graph Groups 风格查询解析节点颜色 |
| `applyColorGroupsToGraph` | 批量应用颜色组到图节点 |

最小集成流程是：

1. 准备资料数据。
2. 调用 `buildLibraryGraph` 构建图。
3. 用 `GraphModel` 包装图数据。
4. 创建 `SimulationClient` 启动布局 worker。
5. 创建 `Canvas2DRenderer` 渲染画布。
6. 在页面卸载或重建图谱时调用 `dispose()`。

## 2. 本地运行示例

在 `knowledge-graph-engine` 目录下运行：

```powershell
npm run dev:example
```

然后打开：

```text
http://127.0.0.1:4173/examples/vanilla/
```

示例代码位置：

| 文件 | 说明 |
| --- | --- |
| `examples/vanilla/index.html` | 页面结构 |
| `examples/vanilla/app.js` | 组件集成逻辑 |
| `examples/vanilla/styles.css` | 示例样式 |

## 3. 导入组件

源码包内可以这样导入：

```js
import {
  buildLibraryGraph,
  Canvas2DRenderer,
  defaultDisplayOptions,
  defaultGraphOptions,
  GraphModel,
  SimulationClient
} from "../../src/index.js";
```

如果作为包安装到其他项目，建议使用：

```js
import {
  buildLibraryGraph,
  Canvas2DRenderer,
  createSimulationClient,
  GraphModel,
  normalizeGraph,
  applyColorGroupsToGraph,
  resolveColorGroupColor,
  SimulationClient
} from "@note-web/knowledge-graph-engine";
```

worker URL 推荐写法：

```js
const workerUrl = new URL("@note-web/knowledge-graph-engine/worker", import.meta.url);
```

在当前源码示例中，因为没有经过包安装，所以使用相对路径：

```js
const workerUrl = new URL("../../src/layout/force-worker.js", import.meta.url);
```

## 4. 准备数据

非资料库场景可以直接使用通用图输入：

```js
const graph = normalizeGraph({
  nodes: [
    { id: "plan", label: "Planning Gate", kind: "gate", status: "done" },
    { id: "preview", label: "Progress Preview", kind: "view", status: "running" }
  ],
  links: [
    { source: "plan", target: "preview", kind: "unlocks", directed: true }
  ]
});
```

颜色组可以在渲染前批量应用：

```js
const coloredGraph = applyColorGroupsToGraph(graph, [
  { id: "blocked", query: "status:blocked OR tag:risk", color: "#fb7185" },
  { id: "running-renderer", query: "kind:renderer status:running", color: "#38bdf8" },
  { id: "bound", query: "bound:true", color: "#a78bfa" }
], {
  fallbackColor: (context) => context.node.color,
  getContext: (node) => ({
    node,
    content: node.summary,
    properties: {
      bound: node.data?.hasRuntimeBinding,
      kind: node.kind,
      status: node.status,
      tags: node.tags
    }
  })
});
```

颜色组按数组顺序求值，首个命中的 enabled group 获胜。查询支持空白 AND、`OR`、`-term`、括号、短语、正则，以及 `tag:`、`kind:`、`status:`、`label:`、`summary:`、`bound:`、`file:`、`path:`、`content:`、`match-case:`、`ignore-case:` 和 `[property:value]`。

资料库场景仍然可以使用 `buildLibraryGraph`。

`buildLibraryGraph` 默认接收资料列表：

```js
const files = [
  {
    id: "eigen",
    title: "Eigenvalues explained",
    type: "PDF",
    course: "Linear Algebra",
    author: "Ada",
    tags: ["matrix", "eigenvalue", "diagonalization"],
    references: 5
  },
  {
    id: "review-slides",
    title: "Final review slides",
    type: "PPTX",
    course: "Linear Algebra",
    author: "Grace",
    tags: ["review", "slides"],
    references: 2
  }
];
```

字段说明：

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `id` | 是 | 资料唯一标识 |
| `title` | 建议 | 资料节点显示名 |
| `type` | 否 | 文件类型，例如 `PDF`、`MD`、`PPTX` |
| `course` | 否 | 课程名，会生成课程节点 |
| `author` | 否 | 作者名，会生成作者节点 |
| `tags` | 否 | 标签数组，会生成标签节点 |
| `references` | 否 | 引用数量，用于影响资料节点半径 |

## 5. 构建图谱数据

```js
const graph = buildLibraryGraph({
  files,
  focusFileId: "eigen",
  options: {
    depth: 2,
    showTags: true,
    showAttachments: true,
    showNeighborLinks: true,
    showOrphans: true
  }
});
```

`focusFileId` 用于局部图谱模式。传入资料 id 后，图谱会以该资料为中心，按 `depth` 展开邻居。传空字符串则显示全量图谱。

构图选项：

| 选项 | 默认值 | 说明 |
| --- | --- | --- |
| `depth` | `2` | 聚焦模式下的展开深度 |
| `showNeighborLinks` | `true` | 是否显示非焦点节点之间的邻接关系 |
| `showForelinks` | `true` | 是否显示资料到属性节点的正向边 |
| `showBacklinks` | `true` | 是否显示属性节点到资料的反向边 |
| `showTags` | `true` | 是否生成标签节点 |
| `showAttachments` | `true` | 是否生成文件类型节点 |
| `showOrphans` | `true` | 是否保留孤立节点 |
| `groups` | `[]` | 根据节点 label 关键字覆盖节点颜色 |

颜色分组示例：

```js
const graph = buildLibraryGraph({
  files,
  options: {
    groups: [
      { query: "graph", color: "#38bdf8" },
      { query: "review", color: "#f59e0b" }
    ]
  }
});
```

## 6. 创建模型

```js
const model = new GraphModel(graph);
```

`GraphModel` 会生成：

- `model.nodes`：可渲染节点数组。
- `model.links`：带节点对象引用的边数组。
- `model.nodeById`：节点 id 到节点对象的 Map。
- `model.linkIds`：worker 使用的轻量边列表。

常用方法：

```js
model.resetPositions();
model.makeWorkerNodes();
model.applyPositions(ids, coords);
model.highlightedNodes("review");
```

一般情况下，宿主应用只需要直接创建模型；坐标更新由 `SimulationClient` 自动调用。

## 7. 启动布局

```js
const simulation = createSimulationClient({
  workerUrl: new URL("../../src/layout/force-worker.js", import.meta.url),
  model,
  motionController: {
    onTick(metrics) {
      if (metrics.edgeAngleDelta < 0.002 && metrics.edgeLengthDelta < 0.25) {
        return { damp: 0.1 };
      }
    }
  },
  onTick: (metrics) => {
    console.log(metrics);
    renderer.render();
  }
});

simulation.start({
  centerStrength: 0.08,
  linkStrength: 1,
  linkDistance: 145,
  repelStrength: 420
});
```

力参数说明：

| 参数 | 说明 |
| --- | --- |
| `centerStrength` | 图谱向中心收拢的力度 |
| `linkStrength` | 相连节点之间的吸引力度 |
| `linkDistance` | 相连节点的目标距离 |
| `repelStrength` | 节点之间的排斥力度 |

动态更新力参数：

```js
simulation.updateForces({
  centerStrength: 0.08,
  linkStrength: 1.2,
  linkDistance: 160,
  repelStrength: 500
});
```

`onTick(metrics)` 会收到布局指标：

| 指标 | 说明 |
| --- | --- |
| `averageMovement` | 节点平均位移 |
| `maxMovement` | 节点最大位移 |
| `alpha` / `energy` | 布局能量 |
| `edgeLengthDelta` | 边长度平均变化 |
| `edgeAngleDelta` | 边角度平均变化 |
| `stopped` | 是否已停止 |

重启布局：

```js
model.resetPositions();
simulation.start(forceOptions, 1);
```

## 8. 创建 Canvas 渲染器

HTML 中准备画布：

```html
<canvas id="graph-canvas"></canvas>
```

创建渲染器：

```js
const renderer = new Canvas2DRenderer({
  canvas: document.querySelector("#graph-canvas"),
  model,
  selectedNodeId,
  hoveredNodeId,
  getQuery: () => query,
  getDisplayOptions: () => displayOptions,
  getHighlightedNodes: (activeNodeId) => new Set([activeNodeId]),
  getHighlightedLinks: (activeNodeId) =>
    model.links.filter((link) => link.sourceId === activeNodeId || link.targetId === activeNodeId),
  getTheme: () => ({
    canvas: { background: "#101318" },
    link: { byKind: { blocks: "rgba(251, 113, 133, 0.52)" } }
  }),
  onNodeClick: (node) => console.log("click", node),
  onNodeDoubleClick: (node) => console.log("double click", node),
  onNodeSelect: (node) => {
    selectedNodeId = node?.id || null;
    renderer.setInteractionState({ selectedNodeId });
  },
  onNodeDrag: (node, point, alpha) => simulation.pinNode(node.id, point, alpha),
  onNodeRelease: (node) => simulation.releaseNode(node.id),
  onNodeOpen: (node) => {
    if (node.fileId) {
      openFile(node.fileId);
    } else {
      search(node.label);
    }
  },
  onStatus: (text) => {
    statusElement.textContent = text;
  }
});
```

受控 selection / hover 更新：

```js
renderer.setInteractionState({
  selectedNodeId: "preview",
  hoveredNodeId: null
});
```

显示选项：

```js
const displayOptions = {
  showArrows: true,
  textFade: 0.6,
  nodeSize: 1,
  linkThickness: 1
};
```

选项说明：

| 选项 | 说明 |
| --- | --- |
| `showArrows` | 是否绘制边箭头 |
| `textFade` | 缩小时标签淡出阈值 |
| `nodeSize` | 节点大小倍率 |
| `linkThickness` | 连线粗细倍率 |

标签策略建议放在 `appearance.labelPolicy` 中：

```js
const appearance = {
  labelPolicy: {
    mode: "density",
    density: 0.7,
    priority: "degree",
    textFade: 0.6
  },
  theme: {
    label: {
      fontSize: 13,
      fontWeight: 600,
      fontFamily: "Inter, Segoe UI, sans-serif"
    }
  }
};
```

`density` 按当前普通标签候选数量做线性预算；默认 `priority: "degree"` 会让连线更多的节点先获得标签，同度数节点再按 `id` 或 `label` 的稳定排序渐进增减。可改为 `priority: "stable"`，也可以传入函数返回自定义分数；预算小数部分会让边界标签淡入，而不是按数组下标重新洗牌。

节点大小策略建议放在 `appearance.nodeSizePolicy` 中：

```js
const appearance = {
  display: {
    nodeSize: 1.15
  },
  nodeSizePolicy: {
    mode: "metric",
    priority: "degree",
    minScale: 1,
    maxScale: 1.9,
    strength: 0.32
  }
};
```

默认 `priority: "degree"` 会让连接边数更多的节点更大；组件会把同一个解析后半径用于绘制、命中测试、箭头避让、标签位置和视口适配。若宿主希望所有节点只使用基础半径，可设置 `mode: "fixed"`。

重置缩放和平移，使所有已有坐标的节点适配当前画布：

```js
renderer.resetZoom({ padding: 64 });
```

`resetZoom` 会按节点坐标和节点半径计算图谱边界，然后更新渲染器内部的 `scale`、`panX` 和 `panY`。它适合放在“重置视图”按钮中，也可以在首次挂载图谱后调用一次。

注意：如果布局由 worker 计算，首次自动适配应放在 worker 第一次回传坐标之后。示例中的做法是在第一个 `onTick` 内调用：

```js
let fitOnNextTick = true;

const simulation = new SimulationClient({
  workerUrl,
  model,
  onTick: () => {
    if (fitOnNextTick) {
      fitOnNextTick = false;
      renderer.resetZoom({ padding: 64 });
      return;
    }
    renderer.render();
  }
});
```

## 9. 搜索和高亮

渲染器通过 `getQuery` 获取搜索词：

```js
let query = "";

queryInput.addEventListener("input", () => {
  query = queryInput.value.trim();
  renderer.render();
});
```

搜索逻辑在 `GraphModel.highlightedNodes(query)` 中：

- 匹配节点 `label`。
- 命中的节点会高亮。
- 命中节点的一跳邻居也会高亮。
- 其他节点会降低视觉权重。

## 10. 节点交互

渲染器内置以下交互：

| 操作 | 行为 |
| --- | --- |
| 拖拽空白区域 | 平移画布 |
| 滚轮 | 缩放画布 |
| 拖拽节点 | 固定节点并重新布局 |
| 释放节点 | 取消固定节点 |
| 点击节点 | 触发 `onNodeOpen` |
| hover 节点 | 改变节点颜色和鼠标样式 |

`onNodeOpen` 推荐处理方式：

```js
function handleNodeOpen(node) {
  if (node.fileId) {
    focusFileId = node.fileId;
    mountGraph();
    return;
  }

  query = node.label || "";
  renderer.render();
}
```

资料节点会带有 `fileId`；课程、标签、作者、类型等属性节点没有 `fileId`，通常可作为搜索词处理。

## 11. 重建和销毁

当筛选条件、聚焦文件或构图选项变化时，建议销毁旧实例后重建：

```js
function mountGraph() {
  simulation?.dispose();
  renderer?.dispose();

  const graph = buildLibraryGraph({ files, focusFileId, options: graphOptions });
  model = new GraphModel(graph);

  simulation = new SimulationClient({
    workerUrl,
    model,
    onTick: () => renderer?.render()
  });

  renderer = new Canvas2DRenderer({
    canvas,
    model,
    getQuery: () => query,
    getDisplayOptions: () => displayOptions
  });

  simulation.start(forceOptions, 1);
}
```

销毁很重要：

- `simulation.dispose()` 会终止 worker。
- `renderer.dispose()` 会移除 resize、pointer、wheel 事件监听。

页面卸载时也应调用：

```js
window.addEventListener("beforeunload", () => {
  simulation?.dispose();
  renderer?.dispose();
});
```

## 12. 在宿主应用中的推荐集成方式

建议宿主应用负责：

- 页面布局和控制面板。
- 路由切换。
- toast、弹窗、详情面板。
- 搜索跳转。
- 打开资料详情。
- 数据加载和权限控制。

图谱组件只负责：

- 接收数据。
- 生成图结构。
- 计算布局。
- 渲染和基础交互。

推荐的页面结构：

```text
GraphPage
  state:
    files
    focusFileId
    query
    graphOptions
    displayOptions
    forceOptions

  lifecycle:
    mountGraph()
    disposeGraph()

  callbacks:
    onNodeOpen()
    onSearch()
    onOpenFile()
```

这种方式可以避免把某个具体应用的 UI 和状态管理耦合进图谱库。

## 13. 常见问题

### 13.1 页面打开后没有布局

检查 worker URL 是否能访问。源码示例中应能访问：

```text
http://127.0.0.1:4173/src/layout/force-worker.js
```

如果使用构建工具，请优先使用：

```js
new URL("@note-web/knowledge-graph-engine/worker", import.meta.url)
```

### 13.2 Canvas 是空白

检查：

- `<canvas>` 是否有可见宽高。
- 是否已经调用 `simulation.start()`。
- `onTick` 中是否调用了 `renderer.render()`。
- 输入数据是否生成了节点。

### 13.3 筛选后事件变多或拖拽异常

重建图谱前需要调用：

```js
simulation?.dispose();
renderer?.dispose();
```

### 13.4 节点太密集

可以调整：

```js
simulation.updateForces({
  linkDistance: 180,
  repelStrength: 650
});
```

也可以在构图时使用焦点和深度裁剪：

```js
buildLibraryGraph({
  files,
  focusFileId: "eigen",
  options: { depth: 1 }
});
```

## 14. 最小完整示例

```js
import {
  buildLibraryGraph,
  Canvas2DRenderer,
  GraphModel,
  SimulationClient
} from "@note-web/knowledge-graph-engine";

const files = [
  {
    id: "eigen",
    title: "Eigenvalues explained",
    type: "PDF",
    course: "Linear Algebra",
    author: "Ada",
    tags: ["matrix", "eigenvalue"],
    references: 5
  }
];

let query = "";
const forceOptions = {
  centerStrength: 0.08,
  linkStrength: 1,
  linkDistance: 145,
  repelStrength: 420
};

const graph = buildLibraryGraph({ files });
const model = new GraphModel(graph);
let renderer;

const simulation = new SimulationClient({
  workerUrl: new URL("@note-web/knowledge-graph-engine/worker", import.meta.url),
  model,
  onTick: () => renderer.render()
});

renderer = new Canvas2DRenderer({
  canvas: document.querySelector("#graph-canvas"),
  model,
  getQuery: () => query,
  onNodeDrag: (node, point, alpha) => simulation.pinNode(node.id, point, alpha),
  onNodeRelease: (node) => simulation.releaseNode(node.id),
  onNodeOpen: (node) => console.log(node)
});

simulation.start(forceOptions, 1);
renderer.resetZoom({ padding: 64 });
```

对应 HTML：

```html
<canvas id="graph-canvas" style="width: 100%; height: 600px"></canvas>
```
