# Color Groups API

`knowledge-graph-engine` provides renderer-independent color group helpers inspired by Obsidian Graph Groups.

## API

```js
import {
  applyColorGroupsToGraph,
  compileColorGroupQuery,
  evaluateColorGroupQuery,
  resolveColorGroupColor
} from "@note-web/knowledge-graph-engine";
```

## Query Examples

```text
status:blocked OR tag:active
kind:task -status:completed
"planning gate" OR /handoff/i
[status:blocked]
bound:true
match-case:Gate
```

Supported semantics:

- Empty query matches nothing.
- Whitespace means implicit AND.
- `OR` is case-insensitive.
- `(...)` groups expressions.
- `-term` negates a term.
- `"quoted phrase"` matches a phrase.
- `/pattern/flags` runs a regular expression. Invalid regex returns diagnostics and evaluates to false.
- Supported scopes include `file:`, `path:`, `content:`, `tag:`, `kind:`, `status:`, `label:`, `summary:`, `bound:`, `match-case:`, `ignore-case:`, `task:`, `task-todo:`, and `task-done:`.
- Property brackets support `[property]` and `[property:value]`.

## Resolve One Node

```js
const result = resolveColorGroupColor(
  {
    node,
    nodeId: node.id,
    content: node.summary,
    properties: {
      kind: node.kind,
      status: node.status,
      tags: node.tags,
      bound: node.hasRuntimeBinding
    }
  },
  colorGroups,
  {
    fallbackColor: (context) => context.node.color
  }
);

node.color = result.color;
```

## Apply To A Graph

```js
const coloredGraph = applyColorGroupsToGraph(graph, colorGroups, {
  fallbackColor: (context) => context.node.color,
  getContext: (node) => ({
    node,
    content: node.summary,
    properties: {
      bound: node.data?.hasRuntimeBinding,
      tags: node.tags
    }
  })
});
```

The first enabled group that matches wins. Disabled groups and empty queries are skipped. If no group matches, `fallbackColor` is used.
