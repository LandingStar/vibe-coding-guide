# 关系图谱独立库封装方案

## 当前来源

- 已克隆源码：`../source-note-web`
- 来源仓库：`https://github.com/JieteXue/note_web/tree/codex/graph-integration`
- 当前源码提交：`abb6274`
- 核心实现目录：`apps/web/src/graph`
- 应用集成入口：`apps/web/src/pages/graph-page.js`、`apps/web/src/app.js`
- 样式入口：`apps/web/src/styles/library-content.css` 中 `.graph-*` 相关规则

## 可直接提取的核心

1. 图数据构建

   原文件：`apps/web/src/graph/library-graph.js`

   职责：

   - 把资料列表转换为 `{ nodes, links, focusFile }`。
   - 生成资料、课程、标签、格式、作者节点。
   - 支持正向链接、反向链接、同课程邻接链接、局部深度裁剪、孤立点过滤和简单颜色分组。

   建议在独立库中作为 `src/adapters/library-graph.js` 保留，但明确它是“业务适配器”，不是通用图内核。

2. 图运行时模型

   原文件：`apps/web/src/graph/graph-model.js`

   职责：

   - 复制节点，建立 `nodeById`。
   - 将 link id 映射成节点对象引用。
   - 管理节点位置、worker payload 和搜索高亮邻域。

   建议作为 `src/core/graph-model.js`，并让它接受数组 link 和对象 link 两种输入，方便未来接外部图数据。

3. 力导向布局 worker

   原文件：`apps/web/src/graph/graph-worker.js`

   职责：

   - 在 Web Worker 中执行中心力、连线力、斥力和积分。
   - 用 transferable `ArrayBuffer` 回传坐标。
   - 支持拖拽固定节点和动态更新力参数。

   建议作为 `src/layout/force-worker.js` 导出，并通过 package `exports["./worker"]` 暴露。

4. worker 客户端

   原文件：`apps/web/src/graph/simulation-client.js`

   职责：

   - 封装 worker 消息协议。
   - 启动布局、更新力参数、固定/释放节点、销毁 worker。

   建议作为 `src/layout/simulation-client.js`。

5. Canvas 2D 渲染器

   原文件：`apps/web/src/graph/renderers/canvas-2d-renderer.js`

   职责：

   - 绘制背景、边、箭头、节点、标签。
   - 支持缩放、平移、拖拽节点、点击节点、搜索高亮。

   建议作为 `src/renderers/canvas-2d-renderer.js`。渲染器不应该负责页面布局、筛选面板或中文文案。

## 不建议进入核心库的部分

- `apps/web/src/pages/graph-page.js`：这是原应用页面胶水，包含 HTML 模板、控制面板、搜索面板、toast/路由回调以及应用文案。
- `apps/web/src/app.js` 中的 `graphFocusFileId`、`switchView("graph")`、`selectedFileId`：这是宿主应用状态管理。
- `.graph-page-shell`、`.graph-workspace`、`.graph-sidebar` 等整页样式：适合移动到示例应用或可选 CSS，不适合作为核心 API。
- `escapeHtml`：属于页面模板安全工具，不属于图谱引擎。

## 建议库结构

```text
knowledge-graph-engine/
  package.json
  README.md
  src/
    index.js
    core/
      graph-model.js
    adapters/
      library-graph.js
    layout/
      simulation-client.js
      force-worker.js
    renderers/
      canvas-2d-renderer.js
  test/
    library-graph.test.mjs
  docs/
    extraction-plan.md
```

## 公共 API 建议

```js
import {
  buildLibraryGraph,
  GraphModel,
  SimulationClient,
  Canvas2DRenderer
} from "@note-web/knowledge-graph-engine";
```

建议保持三层 API：

- `adapter`：将业务数据转为通用图数据，例如 `buildLibraryGraph({ files, focusFileId, options })`。
- `core/layout`：与业务无关的图状态和布局，例如 `GraphModel`、`SimulationClient`。
- `renderer`：浏览器渲染能力，例如 `Canvas2DRenderer`。

## 输入数据契约

第一阶段可以沿用 note_web 的资料对象：

```ts
type LibraryFile = {
  id: string;
  title: string;
  type?: string;
  course?: string;
  author?: string;
  tags?: string[];
  references?: number;
};
```

图数据输出建议稳定为：

```ts
type GraphNode = {
  id: string;
  label: string;
  kind: "note" | "course" | "tag" | "type" | "author" | string;
  radius: number;
  color: string;
  fileId?: string;
  x?: number;
  y?: number;
};

type GraphLink = [sourceId: string, targetId: string, kind?: string];
```

第二阶段应新增通用 builder，例如 `buildGraph({ nodes, links })` 或 `createGraphModel(rawGraph)`，让非资料库场景不用经过 `LibraryFile`。

## 封装步骤

1. 先以源码包形式发布内部版本，不引入构建工具。
2. 补齐独立测试，覆盖构图、局部裁剪、分组染色、隐藏标签、`GraphModel` link 映射。
3. 把原应用 `graph-page.js` 改为依赖包 API，而不是相对导入 `../graph/*`。
4. 抽出一个 `examples/vanilla` 页面，承载控制面板和 CSS，验证 worker 路径在浏览器里可用。
5. 再决定是否增加 TypeScript 声明、打包产物和主题 CSS。

## 当前示例

已新增 `examples/vanilla`，用于验证独立库在无框架浏览器页面中的最小集成：

- `examples/vanilla/index.html`：页面结构和控制面板。
- `examples/vanilla/app.js`：示例数据、构图、worker 布局、Canvas 渲染和控制事件。
- `examples/vanilla/styles.css`：示例层样式，不属于核心库 API。
- `scripts/serve-example.mjs`：零依赖静态服务器。

运行方式：

```powershell
npm run dev:example
```

## 风险和改造点

- worker URL 在不同打包器中的解析方式不同，需要文档约定 `new URL("@note-web/knowledge-graph-engine/worker", import.meta.url)`，同时在示例里验证。
- 当前力导向斥力是 O(n^2)，大图会遇到性能瓶颈。后续可引入 Barnes-Hut、分层抽样或切换到成熟布局库。
- 当前 `buildLibraryGraph` 的关系类型偏固定，还没有真实引用关系、评论、GitHub PR、本地文件等边类型。建议把这些作为额外 adapters 增量加入。
- 当前 Canvas 渲染器颜色和背景较硬编码，后续应接受 theme/options。
- 页面源码中存在中文显示异常，独立库不应携带这些文案；UI 文案应留在宿主应用或示例层。
