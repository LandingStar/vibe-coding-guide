# Progress Preview Integration Notes

This document maps the progress preview requirements to the public API now exposed by `knowledge-graph-engine`.

## Implemented API Surface

| Requirement | API |
| --- | --- |
| R1 generic graph input | `normalizeGraph({ nodes, links })` |
| R2 controlled selection / hover | `selectedNodeId`, `hoveredNodeId`, `setInteractionState`, `onNodeSelect`, `onNodeHover` |
| R2 neighborhood highlight | `getHighlightedNodes(activeNodeId)`, `getHighlightedLinks(activeNodeId)` |
| R3 theme options | `theme` or `getTheme`, plus `defaultRendererTheme` |
| R4 click semantics | `onNodeClick`, `onNodeDoubleClick`, `onNodeOpen`, `onNodeSelect` |
| R5 motion metrics | `onTick(metrics)`, `onSettled(metrics)`, `motionController.onTick(metrics)` |
| R6 worker lifecycle | `createSimulationClient({ workerUrl, WorkerClass, ... })` |

## VS Code Webview Worker URL Pattern

In a VS Code extension, create the worker URI in the extension host with `webview.asWebviewUri`, then pass it into the webview DOM:

```html
<canvas id="graph-canvas" data-worker-url="${workerUri}"></canvas>
```

In webview JavaScript:

```js
const workerUrl = document.querySelector("#graph-canvas").dataset.workerUrl;

const simulation = createSimulationClient({
  workerUrl,
  model,
  onTick: (metrics) => {
    renderer.render();
    updateMetrics(metrics);
  }
});
```

`WorkerClass` remains injectable for tests.

## Progress Preview Example

The vanilla example now uses the generic API rather than `buildLibraryGraph`:

- `examples/vanilla/app.js`
- `examples/vanilla/index.html`
- `examples/vanilla/styles.css`

It demonstrates controlled selection, hover callbacks, custom neighborhood highlight, theme overrides, click vs double-click semantics, motion metrics, and reset zoom.
