# 关系图谱功能技术栈分析

本文档分析 `knowledge-graph-engine` 当前提取版本中关系图谱功能使用的技术栈、模块边界、运行机制和后续演进方向。

## 1. 技术栈总览

当前实现采用零运行时依赖的前端原生技术栈：

| 层级 | 技术 | 对应文件 | 职责 |
| --- | --- | --- | --- |
| 模块系统 | ESM | `src/index.js` | 统一导出图谱构建、模型、布局和渲染能力 |
| 数据适配 | JavaScript 纯函数 | `src/adapters/library-graph.js` | 将业务资料数据转换为图节点和边 |
| 图模型 | JavaScript Class / Map / Set | `src/core/graph-model.js` | 管理节点索引、边引用、坐标和搜索高亮 |
| 布局计算 | Web Worker + 自研力导向算法 | `src/layout/force-worker.js` | 在后台线程计算节点位置 |
| 布局通信 | Worker postMessage | `src/layout/simulation-client.js` | 封装主线程与 worker 的消息协议 |
| 可视化渲染 | Canvas 2D API | `src/renderers/canvas-2d-renderer.js` | 绘制节点、边、箭头、标签和交互状态 |
| 示例应用 | 原生 HTML/CSS/JS | `examples/vanilla` | 验证无框架集成方式 |
| 本地服务 | Node.js `http` | `scripts/serve-example.mjs` | 提供零依赖静态服务 |
| 测试 | Node.js `assert` | `test/library-graph.test.mjs` | 覆盖构图和模型基础行为 |

这个技术栈的核心特点是轻量、可移植、便于先作为源码包复用。它没有依赖 D3、Cytoscape、vis-network、Sigma.js 等图可视化库。

## 2. 架构分层

当前组件可以拆成四层。

### 2.1 数据适配层

文件：`src/adapters/library-graph.js`

这一层负责把业务数据转换成通用图数据。当前内置的是资料库场景适配器 `buildLibraryGraph`。

输入数据是资料对象：

```ts
type LibraryFile = {
  id: string;
  title: string;
  type?: string;
  course?: string;
  author?: string;
  tags?: string[];
  references?: number;
};
```

输出数据是：

```ts
type LibraryGraph = {
  nodes: GraphNode[];
  links: GraphLink[];
  focusFile: LibraryFile | null;
};
```

它会生成以下节点类型：

| 节点类型 | 来源字段 | 说明 |
| --- | --- | --- |
| `note` | `file.id`, `file.title` | 资料本体节点 |
| `course` | `file.course` | 课程节点 |
| `tag` | `file.tags` | 标签节点 |
| `type` | `file.type` | 文件类型节点 |
| `author` | `file.author` | 作者节点 |

它会生成以下边类型：

| 边类型 | 说明 |
| --- | --- |
| `outgoing` | 资料指向课程、标签、类型、作者 |
| `incoming` | 课程、标签、类型、作者反向指向资料 |
| `neighbor` | 同课程资料之间的邻接关系 |
| `related` | 默认关系类型，当前主要作为兜底 |

这一层带有业务语义，因此建议继续放在 `adapters` 目录，而不是混入核心图模型。

### 2.2 图模型层

文件：`src/core/graph-model.js`

`GraphModel` 是渲染和布局之间的共享运行时状态。它的主要职责是：

- 复制节点，避免直接修改原始输入数据。
- 建立 `nodeById`，方便通过 id 查找节点。
- 将 `[sourceId, targetId, kind]` 边转换为 `{ source, target, kind }` 对象引用。
- 生成 worker 初始坐标 payload。
- 接收 worker 回传坐标并写入节点对象。
- 根据搜索词返回匹配节点及其一跳邻居。

这一层与业务无关，可以复用于任何图数据，只要输入满足基本节点和边契约。

### 2.3 布局计算层

文件：

- `src/layout/force-worker.js`
- `src/layout/simulation-client.js`

布局计算运行在 Web Worker 中，避免主线程在计算节点位置时阻塞交互和绘制。

当前力导向算法包含：

| 力 | 作用 |
| --- | --- |
| center force | 将节点整体拉回画布中心 |
| link force | 让相连节点靠近目标连线长度 |
| repel force | 让节点互相排斥，减少重叠 |
| velocity decay | 速度衰减，让布局逐渐稳定 |

主线程和 worker 的通信流程：

1. `SimulationClient.start()` 发送节点初始坐标、边列表、力参数和 alpha。
2. worker 在定时 tick 中更新坐标。
3. worker 使用 transferable `ArrayBuffer` 回传所有节点坐标。
4. `GraphModel.applyPositions()` 将坐标写回节点。
5. `Canvas2DRenderer.render()` 使用最新坐标重绘。

当前斥力计算是 O(n^2)。对几十到几百个节点足够直接，但大图场景需要后续优化。

### 2.4 渲染交互层

文件：`src/renderers/canvas-2d-renderer.js`

渲染器基于 Canvas 2D API，负责：

- 绘制深色背景。
- 绘制边和可选箭头。
- 绘制节点圆点、hover 状态和拖拽高亮。
- 绘制节点标签。
- 处理缩放、平移、节点拖拽、点击打开节点。
- 根据搜索词降低非相关节点的视觉权重。

Canvas 方案的优点：

- 节点和边数量较多时比 DOM/SVG 更轻。
- 绘制完全可控，适合做高频布局刷新。
- 不依赖第三方渲染库。

代价是：

- 可访问性能力弱于 DOM。
- 节点不是独立 DOM 元素，tooltip、菜单等需要额外实现。
- 复杂图形样式需要手写绘制逻辑。

## 3. 浏览器 API 依赖

当前库依赖以下浏览器能力：

| API | 使用位置 | 说明 |
| --- | --- | --- |
| `Worker` | `SimulationClient` | 后台运行布局计算 |
| `postMessage` | `SimulationClient` / worker | 主线程与 worker 通信 |
| `ArrayBuffer` / `Float32Array` | worker 坐标传输 | 高效传递节点坐标 |
| `CanvasRenderingContext2D` | `Canvas2DRenderer` | 绘制图谱 |
| Pointer Events | `Canvas2DRenderer` | 节点拖拽和画布平移 |
| Wheel Event | `Canvas2DRenderer` | 缩放 |
| `devicePixelRatio` | `Canvas2DRenderer` | 高清屏适配 |

因此，核心渲染和布局部分主要面向浏览器环境。构图和图模型部分可以在 Node.js 中运行。

## 4. 包形态

当前包采用源码级 ESM 暴露：

```json
{
  "type": "module",
  "exports": {
    ".": "./src/index.js",
    "./worker": "./src/layout/force-worker.js"
  }
}
```

这意味着：

- 现代构建工具可以直接导入 `@note-web/knowledge-graph-engine`。
- worker 可以通过子路径 `@note-web/knowledge-graph-engine/worker` 暴露。
- 现阶段没有生成 CommonJS、UMD 或压缩产物。

如果需要正式发布到 npm，建议后续补充：

- TypeScript 类型声明。
- `files` 白名单。
- 构建产物，例如 ESM bundle。
- worker 打包兼容性验证。

## 5. 与原项目的关系

原项目中的关系图谱功能分布如下：

| 原项目位置 | 提取策略 |
| --- | --- |
| `apps/web/src/graph/library-graph.js` | 提取为业务适配器 |
| `apps/web/src/graph/graph-model.js` | 提取为核心模型 |
| `apps/web/src/graph/graph-worker.js` | 提取为布局 worker |
| `apps/web/src/graph/simulation-client.js` | 提取为 worker 客户端 |
| `apps/web/src/graph/renderers/canvas-2d-renderer.js` | 提取为 Canvas 渲染器 |
| `apps/web/src/pages/graph-page.js` | 不进入核心库，作为宿主页面胶水参考 |
| `apps/web/src/styles/library-content.css` 的 `.graph-*` | 不进入核心库，可进入示例或可选样式 |
| `apps/web/src/app.js` 的 view/state 逻辑 | 不进入核心库，由宿主应用负责 |

这种拆法可以让图谱能力独立复用，同时避免把原应用的路由、toast、页面文案和状态管理带入库。

## 6. 性能特点

当前实现适合中小规模图谱。

优势：

- 布局计算放入 worker，主线程主要负责绘制和交互。
- 坐标使用 `Float32Array` 回传，传输成本较低。
- Canvas 单画布绘制，不创建大量 DOM 节点。
- 支持焦点深度裁剪，可以降低可视节点数量。

限制：

- 斥力是 O(n^2)，节点数增长后计算成本明显上升。
- 每次 worker tick 会回传所有节点坐标。
- 渲染器每次重绘遍历全部节点和边。
- 当前没有视口裁剪边、空间索引、标签避让或聚合节点。

大图优化方向：

- 使用 Barnes-Hut 或网格近似优化斥力。
- 增加节点聚合、按层加载或按深度懒加载。
- 只回传变更坐标或降低 tick 频率。
- 对命中测试增加空间索引。
- 支持 WebGL 渲染器作为可选后端。

## 7. 可扩展点

推荐优先扩展以下方向：

1. 通用图数据适配器

   新增 `buildGraph({ nodes, links })` 或 `normalizeGraph(rawGraph)`，让调用方可以绕开 `LibraryFile` 业务结构。

2. 更多业务关系

   在资料库场景中增加真实引用关系、共同参考文献、评论、GitHub PR、本地文件路径等边类型。

3. 主题系统

   将背景色、边颜色、字体、节点颜色和 hover 样式从渲染器中抽成 `theme` 配置。

4. 交互扩展

   增加 tooltip、右键菜单、框选、多选、固定节点状态、导出 PNG 等能力。

5. 类型和构建

   补 TypeScript 声明，明确 API 契约，减少宿主应用集成成本。

## 8. 技术选型结论

当前技术栈适合这个阶段的目标：从原项目中快速、低成本、低依赖地抽离可复用关系图谱能力。

它的核心价值是：

- 图构建、布局、渲染、页面集成边界清楚。
- 原生浏览器 API 足以支撑当前交互。
- 没有第三方依赖，迁移和调试成本低。
- 后续可以逐步替换布局算法或渲染后端，而不影响业务适配器和图模型 API。

短期建议保持这个轻量栈；当节点规模、交互复杂度或图算法需求明显上升时，再引入成熟图布局库或 WebGL 渲染方案。
