import assert from "node:assert/strict";

import {
  applyColorGroupsToGraph,
  compileColorGroupQuery,
  evaluateColorGroupQuery,
  resolveColorGroupColor
} from "../src/index.js";

const context = {
  node: {
    id: "task-1",
    label: "Planning Gate",
    kind: "task",
    status: "blocked",
    summary: "Handoff validation is active",
    tags: ["active", "#risk"],
    color: "#aaaaaa",
    data: {
      owner: "Preview",
      hasRuntimeBinding: true
    }
  },
  content: "Planning Gate handoff validation is active",
  file: "planning.md",
  path: "docs/planning.md",
  properties: {
    bound: true,
    status: "blocked",
    tags: ["active", "risk"]
  }
};

assert.equal(evaluateColorGroupQuery("", context), false);
assert.equal(evaluateColorGroupQuery("planning active", context), true);
assert.equal(evaluateColorGroupQuery("planning missing", context), false);
assert.equal(evaluateColorGroupQuery("missing OR status:blocked", context), true);
assert.equal(evaluateColorGroupQuery("kind:task -status:completed", context), true);
assert.equal(evaluateColorGroupQuery("(kind:task status:blocked) OR kind:note", context), true);
assert.equal(evaluateColorGroupQuery("\"Planning Gate\"", context), true);
assert.equal(evaluateColorGroupQuery("/handoff/i", context), true);
assert.equal(evaluateColorGroupQuery("tag:#risk", context), true);
assert.equal(evaluateColorGroupQuery("tag:risk", context), true);
assert.equal(evaluateColorGroupQuery("status:blocked", context), true);
assert.equal(evaluateColorGroupQuery("kind:task", context), true);
assert.equal(evaluateColorGroupQuery("label:Gate", context), true);
assert.equal(evaluateColorGroupQuery("summary:handoff", context), true);
assert.equal(evaluateColorGroupQuery("bound:true", context), true);
assert.equal(evaluateColorGroupQuery("bound:false", context), false);
assert.equal(evaluateColorGroupQuery("match-case:gate", context), false);
assert.equal(evaluateColorGroupQuery("ignore-case:planning", context), true);
assert.equal(evaluateColorGroupQuery("[status]", context), true);
assert.equal(evaluateColorGroupQuery("[status:blocked]", context), true);
assert.equal(evaluateColorGroupQuery("[tags:risk]", context), true);
assert.equal(evaluateColorGroupQuery("task:handoff", context), true);
assert.equal(evaluateColorGroupQuery("task-todo:handoff", context), true);
assert.equal(evaluateColorGroupQuery("task-done:handoff", context), false);

const badRegex = compileColorGroupQuery("/[bad/");
assert.equal(badRegex.ok, false);
assert.equal(evaluateColorGroupQuery(badRegex, context), false);
assert.equal(badRegex.diagnostics.some((diagnostic) => diagnostic.severity === "error"), true);

const colorResult = resolveColorGroupColor(context, [
  { id: "disabled", query: "status:blocked", color: "#111111", enabled: false },
  { id: "first", query: "status:blocked", color: "#222222" },
  { id: "second", query: "tag:risk", color: "#333333" }
]);
assert.deepEqual(colorResult, { color: "#222222", groupId: "first" });

const fallbackResult = resolveColorGroupColor(context, [{ id: "none", query: "missing", color: "#111111" }], {
  fallbackColor: "#999999"
});
assert.deepEqual(fallbackResult, { color: "#999999", groupId: null });

const applied = applyColorGroupsToGraph({
  nodes: [
    context.node,
    { id: "free", label: "Free node", kind: "note", status: "done", color: "#abcdef" }
  ]
}, [
  { id: "blocked", query: "status:blocked", color: "#ff0000" }
], {
  fallbackColor: (item) => item.node.color
});

assert.equal(applied.nodes[0].color, "#ff0000");
assert.equal(applied.nodes[0].colorGroupId, "blocked");
assert.equal(applied.nodes[1].color, "#abcdef");
assert.equal(applied.matches.get("free").groupId, null);
