import assert from "node:assert/strict";

import { buildLibraryGraph, GraphModel, normalizeGraph } from "../src/index.js";

const files = [
  {
    id: "eigen",
    title: "Eigenvalues explained",
    type: "PDF",
    course: "Linear Algebra",
    author: "Ada",
    tags: ["eigenvalue", "matrix"],
    references: 5
  },
  {
    id: "review",
    title: "Final review slides",
    type: "PPTX",
    course: "Linear Algebra",
    author: "Grace",
    tags: ["review", "slides"],
    references: 2
  }
];

const graph = buildLibraryGraph({ files, focusFileId: "eigen" });

assert.equal(graph.focusFile.id, "eigen");
assert.equal(graph.nodes[0].id, "file:eigen");
assert.ok(graph.nodes.some((node) => node.id === "course:Linear Algebra"));
assert.ok(graph.nodes.some((node) => node.id === "tag:eigenvalue"));
assert.ok(graph.links.some(([source, target]) => source === "file:eigen" && target === "course:Linear Algebra"));
assert.ok(graph.links.some(([source, target]) => source === "file:eigen" && target === "file:review"));

const noTagsGraph = buildLibraryGraph({ files, options: { showTags: false } });
assert.equal(noTagsGraph.nodes.some((node) => node.kind === "tag"), false);

const groupedGraph = buildLibraryGraph({
  files,
  options: { groups: [{ query: "review", color: "#f59e0b" }] }
});
assert.equal(groupedGraph.nodes.find((node) => node.id === "file:review").color, "#f59e0b");

const shallowLocalGraph = buildLibraryGraph({ files, focusFileId: "eigen", options: { depth: 1 } });
assert.ok(shallowLocalGraph.nodes.every((node) => node.id !== "type:PPTX"));

const model = new GraphModel(graph);
assert.ok(model.links.every((link) => link.kind));
assert.ok(model.highlightedNodes("review").has(model.nodeById.get("file:eigen")));

const genericGraph = normalizeGraph({
  nodes: [
    { id: "a", label: "Planning", status: "done" },
    { id: "b", label: "Preview", status: "running" }
  ],
  links: [{ source: "a", target: "b", kind: "depends", directed: false }]
});
const genericModel = new GraphModel(genericGraph);
assert.equal(genericGraph.nodes[0].kind, "node");
assert.equal(genericModel.links[0].id, "a->b:depends");
assert.equal(genericModel.links[0].directed, false);
