import assert from "node:assert/strict";

globalThis.window = {
  devicePixelRatio: 1,
  addEventListener() {},
  removeEventListener() {}
};

const { Canvas2DRenderer, GraphModel, resolveCanvasFont } = await import("../src/index.js");

const calls = [];
const fillTextCalls = [];
const arcCalls = [];
const context = {
  setTransform() {},
  clearRect() {},
  fillRect() {},
  save() {},
  restore() {},
  translate() {},
  scale() {},
  rotate() {},
  beginPath() {},
  moveTo() {},
  lineTo() {},
  stroke() {},
  closePath() {},
  fill() {},
  arc(...args) {
    arcCalls.push(args);
  },
  fillText(...args) {
    fillTextCalls.push(args);
  },
  set fillStyle(value) {
    calls.push(["fillStyle", value]);
  },
  set strokeStyle(value) {
    calls.push(["strokeStyle", value]);
  },
  set lineWidth(value) {
    calls.push(["lineWidth", value]);
  },
  set font(value) {
    calls.push(["font", value]);
  },
  set textAlign(value) {
    calls.push(["textAlign", value]);
  },
  set textBaseline(value) {
    calls.push(["textBaseline", value]);
  }
};

const canvas = {
  width: 0,
  height: 0,
  classList: {
    add() {},
    remove() {},
    toggle() {}
  },
  addEventListener() {},
  removeEventListener() {},
  getBoundingClientRect() {
    return { width: 800, height: 600, left: 0, top: 0 };
  },
  getContext() {
    return context;
  }
};

const model = new GraphModel({
  nodes: [
    { id: "left", label: "Left", kind: "note", radius: 10, color: "#fff", x: -100, y: -50 },
    { id: "right", label: "Right", kind: "note", radius: 10, color: "#fff", x: 100, y: 50 }
  ],
  links: [["left", "right", "related"]]
});

let selected = null;
let payloadSelected = null;
const renderer = new Canvas2DRenderer({
  appearance: {
    hooks: {
      getNodeStyle({ node, style }) {
        return node.id === "right" ? { ...style, fill: "#00ff00" } : style;
      }
    },
    viewport: {
      fitPadding: 50,
      maxScale: 10
    },
    labelPolicy: {
      density: 0,
      mode: "density",
      textFade: 0
    },
    theme: {
      label: {
        fontFamily: "var(--bad-font)",
        fontSize: 15,
        fontWeight: "700"
      }
    }
  },
  canvas,
  model,
  getHighlightedNodes: (activeNodeId) => new Set([activeNodeId]),
  interaction: {
    openOn: "double-click",
    selectedNodeId: "left",
    selectOnClick: true
  },
  theme: {
    canvas: { background: "#000" },
    link: { byKind: { related: "#123456" } }
  },
  events: {
    onNodeSelect(payload) {
      payloadSelected = payload;
    }
  },
  onNodeSelect: (node) => {
    selected = node?.id || null;
  }
});
const fitted = renderer.resetZoom();

assert.equal(fitted, true);
assert.equal(canvas.width, 800);
assert.equal(canvas.height, 600);
assert.ok(renderer.state.scale > 0);
assert.equal(renderer.getSelectedNode().id, "left");

renderer.setInteractionState({ selectedNodeId: "right" }, { render: false });
assert.equal(renderer.getSelectedNode().id, "right");
renderer.selectNode(model.nodeById.get("left"), {});
assert.equal(selected, "left");
assert.equal(payloadSelected.nodeId, "left");
assert.equal(payloadSelected.type, "node:select");
assert.ok(payloadSelected.viewport.scale > 0);
assert.equal(resolveCanvasFont({ fontFamily: "var(--font)", fontSize: 14 }), "normal 400 14px -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif");
assert.equal(resolveCanvasFont({ font: "italic 700 16px Arial" }), "italic 700 16px Arial");
assert.ok(renderer.getResolvedAppearance().label.font.includes("15px"));
assert.equal(renderer.getResolvedAppearance().nodeSize.priority, "degree");

fillTextCalls.length = 0;
renderer.setInteractionState({ selectedNodeId: null }, { render: false });
renderer.render();
assert.equal(fillTextCalls.length, 0);

fillTextCalls.length = 0;
renderer.setInteractionState({ selectedNodeId: "left" }, { render: false });
renderer.render();
assert.equal(fillTextCalls.length, 1);

for (const node of model.nodes) {
  const position = renderer.worldToScreen(node);
  const radius = node.radius * renderer.state.scale;
  assert.ok(position.x - radius >= 49.99);
  assert.ok(position.x + radius <= 750.01);
  assert.ok(position.y - radius >= 49.99);
  assert.ok(position.y + radius <= 550.01);
}

renderer.dispose();

const densityModel = new GraphModel({
  nodes: Array.from({ length: 36 }, (_, index) => ({
    id: `node-${String(index).padStart(2, "0")}`,
    label: `Node ${index}`,
    radius: 6,
    x: (index % 9) * 32,
    y: Math.floor(index / 9) * 32
  })),
  links: []
});

const makeDensityRenderer = (density, options = {}) => {
  const instance = new Canvas2DRenderer({
    appearance: {
      labelPolicy: {
        density,
        mode: "density",
        ...(options.labelPolicy || {}),
        textFade: 0
      }
    },
    canvas,
    model: options.model || densityModel
  });
  instance.state.scale = 1;
  fillTextCalls.length = 0;
  instance.render();
  const labels = fillTextCalls.map((call) => call[0]);
  instance.dispose();
  return labels;
};

const labelsAtLowDensity = makeDensityRenderer(0.24);
const labelsAtLowDensityAgain = makeDensityRenderer(0.24);
const labelsAtHigherDensity = makeDensityRenderer(0.32);
const labelsAtQuarterDensity = makeDensityRenderer(0.25);
const labelsAtHalfDensity = makeDensityRenderer(0.5);
const labelsAtFullDensity = makeDensityRenderer(1);

assert.deepEqual(labelsAtLowDensityAgain, labelsAtLowDensity);
assert.ok(labelsAtLowDensity.length > 0);
assert.ok(labelsAtHigherDensity.length >= labelsAtLowDensity.length);
assert.equal(labelsAtQuarterDensity.length, 9);
assert.equal(labelsAtHalfDensity.length, 18);
assert.equal(labelsAtFullDensity.length, 36);
for (const label of labelsAtLowDensity) {
  assert.ok(labelsAtHigherDensity.includes(label));
}

assert.equal(makeDensityRenderer(4 / 36).length, 4);
assert.equal(makeDensityRenderer(0.125).length, 5);

const degreeModel = new GraphModel({
  nodes: [
    { id: "hub", label: "Hub", radius: 6, x: -90, y: 0 },
    { id: "mid", label: "Mid", radius: 6, x: -30, y: 0 },
    { id: "leaf-a", label: "Leaf A", radius: 6, x: 30, y: 0 },
    { id: "leaf-b", label: "Leaf B", radius: 6, x: 90, y: 0 }
  ],
  links: [
    ["hub", "mid", "related"],
    ["hub", "leaf-a", "related"],
    ["hub", "leaf-b", "related"],
    ["mid", "leaf-a", "related"]
  ]
});

assert.equal(makeDensityRenderer(0.25, { model: degreeModel })[0], "Hub");
assert.notEqual(
  makeDensityRenderer(0.25, { model: degreeModel, labelPolicy: { priority: "stable" } })[0],
  "Hub"
);

const makeNodeRadiusSnapshot = (appearance = {}) => {
  const instance = new Canvas2DRenderer({
    appearance,
    canvas,
    model: degreeModel
  });
  instance.state.scale = 1;
  arcCalls.length = 0;
  calls.length = 0;
  instance.render();
  const radii = new Map();
  for (const call of arcCalls) {
    const [, , radius] = call;
    const node = degreeModel.nodes.find((item) => item.x === call[0] && item.y === call[1]);
    if (node && !radii.has(node.id)) radii.set(node.id, radius);
  }
  const fillStyles = calls.filter((call) => call[0] === "fillStyle").map((call) => call[1]);
  instance.dispose();
  return { fillStyles, radii };
};

const degreeRadiusSnapshot = makeNodeRadiusSnapshot();
assert.ok(degreeRadiusSnapshot.radii.get("hub") > degreeRadiusSnapshot.radii.get("leaf-b"));
assert.ok(degreeRadiusSnapshot.radii.get("mid") > degreeRadiusSnapshot.radii.get("leaf-b"));
assert.ok(degreeRadiusSnapshot.fillStyles.includes("#7dd3fc"));

degreeModel.nodeById.get("hub").color = "#ffffff";
const coloredRadiusSnapshot = makeNodeRadiusSnapshot();
assert.ok(coloredRadiusSnapshot.fillStyles.includes("#ffffff"));
delete degreeModel.nodeById.get("hub").color;

const fixedRadiusSnapshot = makeNodeRadiusSnapshot({
  nodeSizePolicy: {
    mode: "fixed"
  }
});
assert.equal(fixedRadiusSnapshot.radii.get("hub"), fixedRadiusSnapshot.radii.get("leaf-b"));
