param(
  [int]$Port = 4173,
  [switch]$SkipValidation,
  [switch]$OpenBrowser
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $ScriptDir "..")

Set-Location $ProjectRoot

Write-Host "Knowledge Graph Engine test service" -ForegroundColor Cyan
Write-Host "Project: $ProjectRoot"

if (-not $SkipValidation) {
  Write-Host "`nRunning syntax check..." -ForegroundColor Cyan
  npm run check

  Write-Host "`nRunning unit tests..." -ForegroundColor Cyan
  npm test
}

$url = "http://127.0.0.1:$Port/examples/vanilla/"
Write-Host "`nStarting preview service..." -ForegroundColor Cyan
Write-Host "Requested URL: $url"
Write-Host "Press Ctrl+C to stop."

if ($OpenBrowser) {
  Start-Process $url
}

node scripts/serve-example.mjs --port=$Port
