import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(fileURLToPath(new URL("..", import.meta.url)));
const requestedPort = readPort(process.argv) || 4173;
const host = "127.0.0.1";

const mimeTypes = new Map([
  [".css", "text/css; charset=utf-8"],
  [".html", "text/html; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".map", "application/json; charset=utf-8"],
  [".svg", "image/svg+xml"]
]);

startOnAvailablePort(requestedPort);

function readPort(args) {
  const portArg = args.find((arg) => arg.startsWith("--port="));
  if (!portArg) return null;
  const port = Number(portArg.slice("--port=".length));
  return Number.isInteger(port) && port > 0 ? port : null;
}

function startOnAvailablePort(port, attempts = 20) {
  const server = createServer(handleRequest);

  server.on("error", (error) => {
    if (error.code === "EADDRINUSE" && attempts > 0) {
      startOnAvailablePort(port + 1, attempts - 1);
      return;
    }
    console.error(error);
    process.exitCode = 1;
  });

  server.listen(port, host, () => {
    console.log(`Example server running at http://${host}:${port}/examples/vanilla/`);
  });
}

async function handleRequest(request, response) {
  try {
    const url = new URL(request.url, `http://${request.headers.host}`);
    const pathname = decodeURIComponent(url.pathname);

    if (pathname === "/") {
      response.writeHead(302, { Location: "/examples/vanilla/" });
      response.end();
      return;
    }

    const filePath = await resolveFilePath(pathname);
    const content = await readFile(filePath);
    response.writeHead(200, {
      "Cache-Control": "no-store",
      "Content-Type": mimeTypes.get(path.extname(filePath)) || "application/octet-stream"
    });
    response.end(content);
  } catch (error) {
    const status = error.code === "ENOENT" ? 404 : 500;
    response.writeHead(status, { "Content-Type": "text/plain; charset=utf-8" });
    response.end(status === 404 ? "Not found" : "Server error");
  }
}

async function resolveFilePath(pathname) {
  const normalized = path.normalize(pathname).replace(/^([/\\])+/, "");
  let filePath = path.resolve(root, normalized);

  if (!filePath.startsWith(root)) {
    const error = new Error("Path escapes root");
    error.code = "ENOENT";
    throw error;
  }

  const stats = await stat(filePath);
  if (stats.isDirectory()) {
    filePath = path.join(filePath, "index.html");
  }

  return filePath;
}
