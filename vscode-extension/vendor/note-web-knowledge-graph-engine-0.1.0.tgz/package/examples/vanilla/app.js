import {
  applyColorGroupsToGraph,
  Canvas2DRenderer,
  createSimulationClient,
  defaultDisplayOptions,
  GraphModel,
  normalizeGraph
} from "../../src/index.js";

const colorGroups = [
  { id: "blocked", label: "Blocked", query: "status:blocked OR tag:risk", color: "#fb7185" },
  { id: "running-renderer", label: "Renderer active", query: "kind:renderer status:running", color: "#38bdf8" },
  { id: "done", label: "Done", query: "status:done", color: "#34d399" },
  { id: "bound", label: "Runtime-bound", query: "bound:true", color: "#a78bfa" }
];

const rawProgressGraph = normalizeGraph({
  nodes: [
    { id: "plan", label: "Planning Gate", kind: "gate", status: "done", radius: 12, tags: ["handoff"], data: { owner: "PM", progress: 100 } },
    { id: "adapter", label: "normalizeGraph API", kind: "api", status: "done", radius: 10, tags: ["api"], data: { owner: "Engine", progress: 100 } },
    { id: "selection", label: "Selection + Hover", kind: "renderer", status: "running", radius: 11, tags: ["active"], data: { owner: "Preview", progress: 78 } },
    { id: "theme", label: "Theme Contract", kind: "renderer", status: "running", radius: 10, tags: ["active"], data: { owner: "Design", progress: 72 } },
    { id: "clicks", label: "Click Semantics", kind: "renderer", status: "done", radius: 10, tags: ["api"], data: { owner: "Preview", progress: 100, hasRuntimeBinding: true } },
    { id: "metrics", label: "Motion Metrics", kind: "layout", status: "waiting", radius: 10, data: { owner: "Layout", progress: 46 } },
    { id: "worker", label: "Worker URL Helper", kind: "layout", status: "done", radius: 9, tags: ["webview"], data: { owner: "Extension", progress: 100, hasRuntimeBinding: true } },
    { id: "webview", label: "VS Code Webview", kind: "host", status: "waiting", radius: 12, data: { owner: "Host", progress: 55 } },
    { id: "docs", label: "Integration Docs", kind: "docs", status: "running", radius: 9, data: { owner: "Docs", progress: 63 } },
    { id: "release", label: "Preview Release", kind: "milestone", status: "blocked", radius: 12, tags: ["risk"], data: { owner: "All", progress: 20 } }
  ],
  links: [
    { id: "plan-adapter", source: "plan", target: "adapter", kind: "unlocks" },
    { id: "plan-selection", source: "plan", target: "selection", kind: "unlocks" },
    { id: "selection-theme", source: "selection", target: "theme", kind: "depends" },
    { id: "selection-clicks", source: "selection", target: "clicks", kind: "depends" },
    { id: "metrics-selection", source: "metrics", target: "selection", kind: "observes" },
    { id: "worker-metrics", source: "worker", target: "metrics", kind: "feeds" },
    { id: "adapter-webview", source: "adapter", target: "webview", kind: "feeds" },
    { id: "webview-release", source: "webview", target: "release", kind: "blocks" },
    { id: "docs-release", source: "docs", target: "release", kind: "blocks" },
    { id: "theme-webview", source: "theme", target: "webview", kind: "feeds" }
  ]
});

const progressGraph = applyColorGroupsToGraph(rawProgressGraph, colorGroups, {
  fallbackColor: (context) => context.node.color,
  getContext: (node) => ({
    node,
    content: node.summary,
    properties: {
      bound: node.data?.hasRuntimeBinding,
      kind: node.kind,
      status: node.status,
      tags: node.tags
    }
  })
});

const theme = {
  canvas: {
    background: "#101318"
  },
  node: {
    fill: "#7dd3fc",
    selectedFill: "#f8fafc",
    selectedStroke: "#38bdf8",
    hoverFill: "#facc15",
    hoverStroke: "#fde68a",
    accentByStatus: {
      blocked: "#fb7185",
      done: "#34d399",
      running: "#38bdf8",
      waiting: "#f59e0b"
    }
  },
  link: {
    byKind: {
      blocks: "rgba(251, 113, 133, 0.52)",
      depends: "rgba(250, 204, 21, 0.44)",
      feeds: "rgba(56, 189, 248, 0.42)",
      observes: "rgba(167, 139, 250, 0.42)",
      unlocks: "rgba(52, 211, 153, 0.46)"
    }
  },
  label: {
    density: 1,
    fontSize: 12
  }
};

let labelPolicy = {
  density: 1,
  mode: "density",
  textFade: 0.6
};

let labelTheme = {
  fontFamily: "Inter, Segoe UI, sans-serif",
  fontSize: 12,
  fontWeight: "600"
};

const appearance = {
  display: {
    ...defaultDisplayOptions,
    linkThickness: 1.2
  },
  hooks: {
    getNodeStyle({ node, style }) {
      if (node.colorGroupId === "bound") {
        return { ...style, stroke: "#c4b5fd", strokeWidth: 2.4 };
      }
      return style;
    }
  },
  labelPolicy,
  theme,
  viewport: {
    fitPadding: 72,
    maxScale: 3.8,
    minScale: 0.18,
    zoomStep: 1.18
  }
};

const elements = {
  canvas: document.querySelector("#graph-canvas"),
  center: document.querySelector("#center-input"),
  centerValue: document.querySelector("#center-value"),
  detail: document.querySelector("#node-detail"),
  linkDistance: document.querySelector("#link-distance-input"),
  linkDistanceValue: document.querySelector("#link-distance-value"),
  labelDensity: document.querySelector("#label-density-input"),
  labelDensityValue: document.querySelector("#label-density-value"),
  labelMode: document.querySelector("#label-mode-select"),
  labelSize: document.querySelector("#label-size-input"),
  labelSizeValue: document.querySelector("#label-size-value"),
  linkStrength: document.querySelector("#link-strength-input"),
  linkStrengthValue: document.querySelector("#link-strength-value"),
  linkWidth: document.querySelector("#link-width-input"),
  linkWidthValue: document.querySelector("#link-width-value"),
  metrics: document.querySelector("#metrics-panel"),
  nodeSize: document.querySelector("#node-size-input"),
  nodeSizeValue: document.querySelector("#node-size-value"),
  query: document.querySelector("#query-input"),
  repel: document.querySelector("#repel-input"),
  repelValue: document.querySelector("#repel-value"),
  restart: document.querySelector("#restart-button"),
  selected: document.querySelector("#selected-node-select"),
  showArrows: document.querySelector("#show-arrows"),
  status: document.querySelector("#status-bar"),
  textFade: document.querySelector("#text-fade-input"),
  textFadeValue: document.querySelector("#text-fade-value"),
  zoomReset: document.querySelector("#zoom-reset-button")
};

let query = "";
let selectedNodeId = "selection";
let hoveredNodeId = null;
let model = null;
let renderer = null;
let simulation = null;
let latestMetrics = null;

let displayOptions = {
  ...defaultDisplayOptions,
  linkThickness: 1.2
};

let forceOptions = {
  centerStrength: 0.07,
  linkStrength: 1.1,
  linkDistance: 150,
  repelStrength: 520
};

boot();

function boot() {
  renderNodeOptions();
  bindControls();
  mountGraph();
}

function renderNodeOptions() {
  elements.selected.innerHTML = [
    `<option value="">No selection</option>`,
    ...progressGraph.nodes.map((node) => `<option value="${escapeHtml(node.id)}">${escapeHtml(node.label)}</option>`)
  ].join("");
  elements.selected.value = selectedNodeId;
}

function bindControls() {
  elements.selected.addEventListener("change", () => {
    selectedNodeId = elements.selected.value || null;
    syncRendererInteraction();
    renderDetail();
  });

  elements.query.addEventListener("input", () => {
    query = elements.query.value.trim();
    renderer?.render();
  });

  elements.restart.addEventListener("click", () => {
    model?.resetPositions();
    simulation?.start(forceOptions, 1);
  });

  elements.zoomReset.addEventListener("click", () => {
    renderer?.resetZoom({ padding: 72 });
  });

  bindDisplayOption(elements.showArrows, "showArrows", Boolean, null);
  bindDisplayOption(elements.nodeSize, "nodeSize", Number, elements.nodeSizeValue);
  bindDisplayOption(elements.linkWidth, "linkThickness", Number, elements.linkWidthValue);
  bindDisplayOption(elements.textFade, "textFade", Number, elements.textFadeValue, (value) => {
    labelPolicy = { ...labelPolicy, textFade: value };
  });
  elements.labelMode.addEventListener("change", () => {
    labelPolicy = { ...labelPolicy, mode: elements.labelMode.value };
    renderer?.render();
  });
  bindDisplayOption(elements.labelDensity, "labelDensity", Number, elements.labelDensityValue, (value) => {
    labelPolicy = { ...labelPolicy, density: value };
  });
  bindDisplayOption(elements.labelSize, "labelSize", Number, elements.labelSizeValue, (value) => {
    labelTheme = { ...labelTheme, fontSize: value };
  });

  bindForceOption(elements.linkDistance, "linkDistance", Number, elements.linkDistanceValue);
  bindForceOption(elements.repel, "repelStrength", Number, elements.repelValue);
  bindForceOption(elements.linkStrength, "linkStrength", Number, elements.linkStrengthValue);
  bindForceOption(elements.center, "centerStrength", Number, elements.centerValue);
}

function bindDisplayOption(input, key, coerce, output, afterChange) {
  input.addEventListener("input", () => {
    const value = readInput(input, coerce);
    if (key in displayOptions) displayOptions = { ...displayOptions, [key]: value };
    afterChange?.(value);
    if (output) output.value = formatOutput(input.value);
    renderer?.render();
  });
}

function bindForceOption(input, key, coerce, output) {
  input.addEventListener("input", () => {
    forceOptions = { ...forceOptions, [key]: readInput(input, coerce) };
    if (output) output.value = formatOutput(input.value);
    simulation?.updateForces(forceOptions, 0.7);
  });
}

function readInput(input, coerce) {
  if (input.type === "checkbox") return input.checked;
  return coerce(input.value);
}

function mountGraph() {
  simulation?.dispose();
  renderer?.dispose();

  model = new GraphModel(progressGraph);
  let fitOnNextTick = true;
  simulation = createSimulationClient({
    workerUrl: new URL("../../src/layout/force-worker.js", import.meta.url),
    model,
    motionController: {
      onTick(metrics) {
        if (!metrics) return;
        if (metrics.edgeAngleDelta < 0.002 && metrics.edgeLengthDelta < 0.25 && metrics.alpha < 0.12) {
          return { damp: 0.12 };
        }
      }
    },
    onSettled: (metrics) => {
      latestMetrics = metrics;
      renderMetrics();
    },
    onTick: (metrics) => {
      latestMetrics = metrics;
      renderMetrics();
      if (fitOnNextTick) {
        fitOnNextTick = false;
        renderer?.resetZoom({ padding: 72 });
        return;
      }
      renderer?.render();
    }
  });

  renderer = new Canvas2DRenderer({
    canvas: elements.canvas,
    getAppearance: () => ({
      ...appearance,
      display: displayOptions,
      labelPolicy,
      theme: {
        ...theme,
        label: {
          ...theme.label,
          ...labelTheme,
          density: labelPolicy.density
        }
      }
    }),
    model,
    getHighlightedLinks: getHighlightedLinks,
    getHighlightedNodes: getHighlightedNodes,
    getQuery: () => query,
    interaction: {
      hoveredNodeId,
      openOn: "double-click",
      selectedNodeId,
      selectOnClick: true
    },
    events: {
      onNodeDoubleClick: ({ node }) => {
        elements.detail.textContent = node ? `Opened: ${node.label}` : "No node opened";
      },
      onNodeDrag: ({ alpha, node, point }) => simulation.pinNode(node.id, point, alpha),
      onNodeHover: ({ node }) => {
        hoveredNodeId = node?.id || null;
        syncRendererInteraction({ render: false });
      },
      onNodeOpen: ({ node }) => {
        elements.detail.textContent = node ? `Opened: ${node.label}` : "No node opened";
      },
      onNodeRelease: ({ node }) => simulation.releaseNode(node.id),
      onNodeSelect: ({ node }) => {
        selectedNodeId = node?.id || null;
        elements.selected.value = selectedNodeId || "";
        syncRendererInteraction();
        renderDetail();
      },
      onStatus: ({ resolvedAppearance, statusText }) => {
        elements.status.textContent = `${statusText} | labels ${resolvedAppearance.label.mode}/${resolvedAppearance.label.fontSize}px`;
      }
    }
  });

  renderDetail();
  renderMetrics();
  simulation.start(forceOptions, 1);
}

function syncRendererInteraction({ render = true } = {}) {
  renderer?.setInteractionState({ selectedNodeId, hoveredNodeId }, { render });
}

function getHighlightedNodes(activeNodeId) {
  const active = model.nodeById.get(activeNodeId);
  if (!active) return [];
  const nodes = new Set([activeNodeId]);
  for (const link of model.links) {
    if (link.sourceId === activeNodeId) nodes.add(link.targetId);
    if (link.targetId === activeNodeId) nodes.add(link.sourceId);
  }
  return nodes;
}

function getHighlightedLinks(activeNodeId) {
  return model.links
    .filter((link) => link.sourceId === activeNodeId || link.targetId === activeNodeId)
    .map((link) => link.id);
}

function renderDetail() {
  const node = selectedNodeId ? model?.nodeById.get(selectedNodeId) : null;
  if (!node) {
    elements.detail.innerHTML = `<strong>No selection</strong><span>Click a node to inspect it.</span>`;
    return;
  }

  elements.detail.innerHTML = `
    <strong>${escapeHtml(node.label)}</strong>
    <span>${escapeHtml(node.kind)} · ${escapeHtml(node.status || "unknown")}</span>
    <span>Owner: ${escapeHtml(node.data?.owner || "-")}</span>
    <span>Progress: ${escapeHtml(node.data?.progress ?? "-")}%</span>
    <span>Double-click opens; single-click selects.</span>
  `;
}

function renderMetrics() {
  const metrics = latestMetrics;
  elements.metrics.innerHTML = metrics
    ? `
      <span>alpha ${formatMetric(metrics.alpha)}</span>
      <span>move avg ${formatMetric(metrics.averageMovement)}</span>
      <span>move max ${formatMetric(metrics.maxMovement)}</span>
      <span>edge length Δ ${formatMetric(metrics.edgeLengthDelta)}</span>
      <span>edge angle Δ ${formatMetric(metrics.edgeAngleDelta)}</span>
    `
    : `<span>Waiting for layout metrics...</span>`;
}

function formatMetric(value) {
  return Number.isFinite(value) ? value.toFixed(3) : "-";
}

function formatOutput(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return value;
  return Math.abs(numeric) < 10 && !Number.isInteger(numeric) ? numeric.toFixed(2).replace(/0$/, "") : String(numeric);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
