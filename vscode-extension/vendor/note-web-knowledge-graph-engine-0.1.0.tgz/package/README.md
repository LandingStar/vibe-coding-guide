# Knowledge Graph Engine

Reusable graph modules extracted from `JieteXue/note_web` branch `codex/graph-integration`.

This package is intentionally dependency-free for the first extraction pass. It provides:

- `buildLibraryGraph`: transforms note/library records into graph nodes and links.
- `GraphModel`: keeps graph node/link lookup state and search highlighting.
- `SimulationClient`: drives the force layout worker from browser code.
- `Canvas2DRenderer`: renders and interacts with the graph on a `<canvas>`.

## Quick Start

```js
import {
  buildLibraryGraph,
  Canvas2DRenderer,
  GraphModel,
  SimulationClient
} from "@note-web/knowledge-graph-engine";

const graph = buildLibraryGraph({
  files,
  focusFileId: "eigen",
  options: { depth: 2 }
});

const model = new GraphModel(graph);
const workerUrl = new URL("@note-web/knowledge-graph-engine/worker", import.meta.url);

const simulation = new SimulationClient({
  workerUrl,
  model,
  onTick: () => renderer.render()
});

const renderer = new Canvas2DRenderer({
  canvas,
  model,
  getQuery: () => searchText,
  onNodeOpen: (node) => {
    if (node.fileId) openFile(node.fileId);
    else search(node.label);
  }
});

simulation.start({
  centerStrength: 0.08,
  linkStrength: 1,
  linkDistance: 145,
  repelStrength: 420
});

renderer.resetZoom({ padding: 64 });
```

## Local Example

Run the dependency-free vanilla browser example:

```powershell
npm run dev:example
```

Then open `http://127.0.0.1:4173/examples/vanilla/`.

Run validation and then start the test service:

```powershell
npm run dev:test-service
```

Or call the script directly:

```powershell
.\scripts\start-test-service.ps1 -Port 4173 -OpenBrowser
```

## Source Branch

The original project is cloned in `../source-note-web` at commit `abb6274`.
The source files used in this extraction are under:

- `apps/web/src/graph`
- `apps/web/src/pages/graph-page.js`
- `apps/web/src/styles/library-content.css`

See `docs/extraction-plan.md` for the module boundary and packaging proposal.

## Documents

- `docs/extraction-plan.md`: extraction boundary and packaging proposal.
- `docs/appearance-and-interaction.md`: appearance, interaction, and event customization API.
- `docs/color-groups.md`: color group query and resolver API.
- `docs/progress-preview-integration.md`: progress preview integration notes.
- `docs/technical-stack.md`: technical stack and architecture analysis.
- `docs/usage-guide.md`: component usage guide and integration examples.
